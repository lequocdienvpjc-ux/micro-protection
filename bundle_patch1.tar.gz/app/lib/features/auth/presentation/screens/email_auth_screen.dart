import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/router/app_router.dart';
import '../../../../core/utils/validators.dart';
import '../providers/auth_providers.dart';
import '../widgets/auth_widgets.dart';

/// Đăng nhập / Đăng ký bằng Email + mật khẩu (chuyển qua lại bằng SegmentedButton).
class EmailAuthScreen extends ConsumerStatefulWidget {
  const EmailAuthScreen({super.key});
  @override
  ConsumerState<EmailAuthScreen> createState() => _EmailAuthScreenState();
}

class _EmailAuthScreenState extends ConsumerState<EmailAuthScreen> {
  final _form = GlobalKey<FormState>();
  final _email = TextEditingController();
  final _password = TextEditingController();
  final _confirm = TextEditingController();
  bool _isRegister = false;
  bool _obscure = true;

  @override
  void dispose() {
    _email.dispose();
    _password.dispose();
    _confirm.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_form.currentState!.validate()) return;
    final ctrl = ref.read(authControllerProvider.notifier);

    if (_isRegister) {
      final needsConfirm = await ctrl.signUpEmail(_email.text, _password.text);
      if (!mounted) return;
      if (needsConfirm == null) {
        showError(context, ref.read(authControllerProvider).error);
      } else if (needsConfirm) {
        await showDialog<void>(
          context: context,
          builder: (dialogCtx) => AlertDialog(
            title: const Text('Kiểm tra email'),
            content: Text('Chúng tôi đã gửi link xác nhận tới ${_email.text}. '
                'Bấm vào link rồi quay lại đăng nhập.'),
            actions: [
              TextButton(onPressed: () => Navigator.pop(dialogCtx), child: const Text('Đã hiểu')),
            ],
          ),
        );
        if (mounted) setState(() => _isRegister = false);
      }
      // needsConfirm == false: đã có phiên -> router tự chuyển sang KYC
      return;
    }

    final ok = await ctrl.signInEmail(_email.text, _password.text);
    if (!mounted) return;
    if (!ok) showError(context, ref.read(authControllerProvider).error);
  }

  Future<void> _forgotPassword() async {
    final err = Validators.email(_email.text);
    if (err != null) {
      showError(context, 'Nhập email trước khi bấm "Quên mật khẩu"');
      return;
    }
    final ok = await ref.read(authControllerProvider.notifier).resetPassword(_email.text);
    if (!mounted) return;
    if (ok) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Đã gửi email đặt lại mật khẩu.')),
      );
    } else {
      showError(context, ref.read(authControllerProvider).error);
    }
  }

  @override
  Widget build(BuildContext context) {
    final loading = ref.watch(authControllerProvider).isLoading;
    return AuthScaffold(
      title: _isRegister ? 'Tạo tài khoản mới' : 'Đăng nhập',
      subtitle: 'Cùng nhau góp quỹ nhỏ, bảo vệ nhau lúc khó khăn',
      child: Form(
        key: _form,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            SegmentedButton<bool>(
              segments: const [
                ButtonSegment(value: false, label: Text('Đăng nhập')),
                ButtonSegment(value: true, label: Text('Đăng ký')),
              ],
              selected: {_isRegister},
              onSelectionChanged: (s) => setState(() => _isRegister = s.first),
            ),
            const SizedBox(height: 20),
            TextFormField(
              controller: _email,
              keyboardType: TextInputType.emailAddress,
              autofillHints: const [AutofillHints.email],
              decoration: const InputDecoration(
                  labelText: 'Email', prefixIcon: Icon(Icons.email_outlined)),
              validator: Validators.email,
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _password,
              obscureText: _obscure,
              autofillHints: [_isRegister ? AutofillHints.newPassword : AutofillHints.password],
              decoration: InputDecoration(
                labelText: 'Mật khẩu',
                prefixIcon: const Icon(Icons.lock_outline),
                suffixIcon: IconButton(
                  icon: Icon(_obscure ? Icons.visibility : Icons.visibility_off),
                  onPressed: () => setState(() => _obscure = !_obscure),
                ),
              ),
              validator: Validators.password,
            ),
            if (_isRegister) ...[
              const SizedBox(height: 16),
              TextFormField(
                controller: _confirm,
                obscureText: _obscure,
                decoration: const InputDecoration(
                    labelText: 'Nhập lại mật khẩu', prefixIcon: Icon(Icons.lock_outline)),
                validator: (v) => v != _password.text ? 'Mật khẩu không khớp' : null,
              ),
            ],
            const SizedBox(height: 24),
            PrimaryButton(
              label: _isRegister ? 'Tạo tài khoản' : 'Đăng nhập',
              loading: loading,
              onPressed: _submit,
            ),
            if (!_isRegister)
              TextButton(
                onPressed: loading ? null : _forgotPassword,
                child: const Text('Quên mật khẩu?'),
              ),
            const SizedBox(height: 8),
            OutlinedButton.icon(
              icon: const Icon(Icons.phone_iphone),
              label: const Text('Đăng nhập bằng số điện thoại (OTP)'),
              onPressed: loading ? null : () => context.push(Routes.phone),
            ),
          ],
        ),
      ),
    );
  }
}
