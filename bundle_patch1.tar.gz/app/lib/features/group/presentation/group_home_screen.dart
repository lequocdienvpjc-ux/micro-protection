import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/app_theme.dart';
import '../../../core/utils/formatters.dart';
import '../../../core/widgets/common.dart';
import '../../claim/data/claim_repository.dart';
import '../../claim/presentation/claim_widgets.dart';
import '../../claim/presentation/create_claim_screen.dart';
import '../data/group_repository.dart';
import '../domain/entities.dart';
import 'contribute_screen.dart';
import 'fund_report_screen.dart';
import 'join_group_screen.dart';
import 'leader_screen.dart';

/// TRANG CHỦ NHÓM QUỸ: số dư chung, đóng quỹ, yêu cầu hỗ trợ, minh bạch thu–chi.
class GroupHomeScreen extends ConsumerWidget {
  const GroupHomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final groups = ref.watch(myGroupsProvider);
    return AsyncView<List<MyGroup>>(
      value: groups,
      onRetry: () => ref.invalidate(myGroupsProvider),
      data: (list) {
        if (list.isEmpty) return const JoinGroupScreen(embedded: true);
        final selectedId = ref.watch(selectedGroupIdProvider);
        final g = list.firstWhere((x) => x.id == selectedId, orElse: () => list.first);
        return _GroupDashboard(group: g, all: list);
      },
    );
  }
}

class _GroupDashboard extends ConsumerWidget {
  const _GroupDashboard({required this.group, required this.all});
  final MyGroup group;
  final List<MyGroup> all;

  Future<void> _refresh(WidgetRef ref) async {
    ref.invalidate(myGroupsProvider);
    ref.invalidate(fundSummaryProvider(group.id));
    ref.invalidate(groupClaimsProvider(group.id));
    ref.invalidate(ledgerProvider(group.id));
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final summary = ref.watch(fundSummaryProvider(group.id));
    final claims = ref.watch(groupClaimsProvider(group.id));

    return RefreshIndicator(
      onRefresh: () => _refresh(ref),
      child: ListView(
        padding: const EdgeInsets.only(bottom: 32),
        children: [
          // ---- Chọn nhóm ----
          if (all.length > 1)
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
              child: DropdownButtonFormField<String>(
                value: group.id,
                decoration: const InputDecoration(labelText: 'Nhóm'),
                items: [
                  for (final g in all) DropdownMenuItem(value: g.id, child: Text(g.name)),
                ],
                onChanged: (v) => ref.read(selectedGroupIdProvider.notifier).state = v,
              ),
            ),

          // ---- Thẻ số dư ----
          Container(
            margin: const EdgeInsets.all(16),
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: Brand.gradient,
              borderRadius: BorderRadius.circular(20),
              boxShadow: [BoxShadow(color: Brand.navy.withOpacity(0.25), blurRadius: 16, offset: const Offset(0, 6))],
            ),
            child: DefaultTextStyle(
              style: const TextStyle(color: Colors.white),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Expanded(
                    child: Text(group.name,
                        style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600, color: Colors.white)),
                  ),
                  if (group.isLeader)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(color: Brand.orange, borderRadius: BorderRadius.circular(20)),
                      child: const Text('Trưởng nhóm',
                          style: TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w700)),
                    ),
                ]),
                const SizedBox(height: 12),
                const Text('Số dư quỹ chung', style: TextStyle(color: Colors.white70)),
                Text(money(summary.valueOrNull?.balance ?? group.balance),
                    style: const TextStyle(fontSize: 32, fontWeight: FontWeight.w700, color: Colors.white)),
                const SizedBox(height: 8),
                Text('${group.memberCount} thành viên · '
                    'Đóng ${money(group.contributionAmount)}/${periodLabel[group.period]}',
                    style: const TextStyle(color: Colors.white)),
              ]),
            ),
          ),

          // ---- Hành động chính ----
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(children: [
              Expanded(
                child: FilledButton.icon(
                  icon: const Icon(Icons.savings_outlined),
                  label: const Text('Đóng quỹ'),
                  onPressed: () => Navigator.push(context,
                      MaterialPageRoute(builder: (_) => ContributeScreen(group: group))),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: FilledButton.icon(
                  style: FilledButton.styleFrom(backgroundColor: Brand.orange),
                  icon: const Icon(Icons.health_and_safety_outlined),
                  label: const Text('Yêu cầu hỗ trợ'),
                  onPressed: () async {
                    final sent = await Navigator.push<bool>(context,
                        MaterialPageRoute(builder: (_) => CreateClaimScreen(group: group)));
                    if (sent == true) _refresh(ref);
                  },
                ),
              ),
            ]),
          ),

          if (group.isLeader)
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
              child: OutlinedButton.icon(
                icon: const Icon(Icons.admin_panel_settings_outlined),
                label: const Text('Việc của Trưởng nhóm: duyệt đóng quỹ, chi trả'),
                onPressed: () => Navigator.push(
                    context, MaterialPageRoute(builder: (_) => LeaderScreen(group: group))),
              ),
            ),

          // ---- Minh bạch thu – chi ----
          SectionTitle('Minh bạch dòng tiền',
              trailing: TextButton(
                onPressed: () => Navigator.push(context,
                    MaterialPageRoute(builder: (_) => FundReportScreen(group: group))),
                child: const Text('Xem sổ quỹ'),
              )),
          AsyncView<FundSummary>(
            value: summary,
            onRetry: () => ref.invalidate(fundSummaryProvider(group.id)),
            data: (s) => Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(children: [
                _Stat('Tổng thu', s.totalIn, Colors.green),
                _Stat('Tổng chi', s.totalOut, Colors.red),
                _Stat('Phí nền tảng', s.totalFee, Colors.blueGrey),
              ]),
            ),
          ),

          // ---- Yêu cầu hỗ trợ trong nhóm ----
          const SectionTitle('Yêu cầu hỗ trợ trong nhóm'),
          AsyncView(
            value: claims,
            onRetry: () => ref.invalidate(groupClaimsProvider(group.id)),
            data: (list) => list.isEmpty
                ? const EmptyHint('Chưa có yêu cầu nào. Mong mọi người luôn bình an!',
                    icon: Icons.favorite_border)
                : Column(children: [for (final c in list) GroupClaimTile(claim: c)]),
          ),
        ],
      ),
    );
  }
}

class _Stat extends StatelessWidget {
  const _Stat(this.label, this.value, this.color);
  final String label;
  final int value;
  final Color color;
  @override
  Widget build(BuildContext context) => Expanded(
        child: Card(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(label, style: const TextStyle(fontSize: 12, color: Colors.black54)),
              const SizedBox(height: 4),
              FittedBox(
                child: Text(money(value),
                    style: TextStyle(fontWeight: FontWeight.w700, color: color)),
              ),
            ]),
          ),
        ),
      );
}
