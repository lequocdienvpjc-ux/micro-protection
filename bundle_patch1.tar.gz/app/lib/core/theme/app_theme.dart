import 'package:flutter/material.dart';

/// Bộ nhận diện "Tương trợ — Kết nối sức mạnh, sẻ chia khó khăn".
/// Màu lấy trực tiếp từ logo: xanh dương (tin cậy), cam (sẻ chia), xanh đậm (chữ).
class Brand {
  static const blue = Color(0xFF017CE4);
  static const navy = Color(0xFF013D91);
  static const orange = Color(0xFFFF8502);
  static const orangeDeep = Color(0xFFF26A00);
  static const bg = Color(0xFFF5F8FC);

  static const name = 'Tương trợ';
  static const slogan = 'Kết nối sức mạnh, sẻ chia khó khăn';
  static const iconAsset = 'assets/icon.png';

  static const gradient = LinearGradient(
    colors: [blue, navy],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  static const warmGradient = LinearGradient(
    colors: [orange, orangeDeep],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}

/// Giao diện cho người dùng phổ thông: chữ to, nút cao 56px, tương phản rõ.
class AppTheme {
  static const primary = Brand.blue;
  static const danger = Color(0xFFC62828);

  static ThemeData light() {
    final scheme = ColorScheme.fromSeed(
      seedColor: Brand.blue,
      primary: Brand.blue,
      secondary: Brand.orange,
      tertiary: Brand.navy,
      error: danger,
      surface: Colors.white,
    );
    return ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      scaffoldBackgroundColor: Brand.bg,
      appBarTheme: const AppBarTheme(
        backgroundColor: Colors.white,
        foregroundColor: Brand.navy,
        elevation: 0,
        scrolledUnderElevation: 1,
        titleTextStyle: TextStyle(color: Brand.navy, fontSize: 19, fontWeight: FontWeight.w700),
      ),
      textTheme: const TextTheme(
        headlineSmall: TextStyle(fontSize: 24, fontWeight: FontWeight.w800, color: Brand.navy),
        titleMedium: TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: Brand.navy),
        bodyLarge: TextStyle(fontSize: 17),
        bodyMedium: TextStyle(fontSize: 15),
      ),
      cardTheme: CardTheme(
        color: Colors.white,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
          side: const BorderSide(color: Color(0xFFE3EAF3)),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: Colors.white,
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 18),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: Brand.blue, width: 2),
        ),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          backgroundColor: Brand.blue,
          minimumSize: const Size.fromHeight(56),
          textStyle: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: Brand.navy,
          minimumSize: const Size.fromHeight(56),
          side: const BorderSide(color: Brand.blue),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
      ),
      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: Colors.white,
        indicatorColor: Brand.orange.withOpacity(0.18),
        labelTextStyle: WidgetStateProperty.all(
          const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: Brand.navy),
        ),
      ),
    );
  }
}

/// Logo + tên + khẩu hiệu dùng ở màn đăng nhập / chờ.
class BrandHeader extends StatelessWidget {
  const BrandHeader({super.key, this.size = 120, this.showSlogan = true});
  final double size;
  final bool showSlogan;

  @override
  Widget build(BuildContext context) => Column(children: [
        Image.asset(Brand.iconAsset, height: size, width: size),
        const SizedBox(height: 8),
        const Text(Brand.name,
            style: TextStyle(fontSize: 34, fontWeight: FontWeight.w900, color: Brand.navy, height: 1.1)),
        if (showSlogan) ...[
          const SizedBox(height: 6),
          const Row(children: [
            Expanded(child: Divider(color: Brand.navy, thickness: 1, endIndent: 8)),
            Text(Brand.slogan,
                style: TextStyle(fontStyle: FontStyle.italic, color: Brand.navy, fontSize: 14)),
            Expanded(child: Divider(color: Brand.navy, thickness: 1, indent: 8)),
          ]),
        ],
      ]);
}
