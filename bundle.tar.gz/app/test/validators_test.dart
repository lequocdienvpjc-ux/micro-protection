import 'package:flutter_test/flutter_test.dart';
import 'package:micro_protection/core/utils/validators.dart';

void main() {
  test('chuẩn hoá số điện thoại VN', () {
    expect(Validators.normalizeVnPhone('0901 234 567'), '+84901234567');
    expect(Validators.normalizeVnPhone('84901234567'), '+84901234567');
    expect(Validators.normalizeVnPhone('+84901234567'), '+84901234567');
  });

  test('kiểm tra CCCD', () {
    expect(Validators.nationalId('079123456789'), isNull);
    expect(Validators.nationalId('12345'), isNotNull);
  });

  test('kiểm tra SĐT', () {
    expect(Validators.phone('0901234567'), isNull);
    expect(Validators.phone('0123'), isNotNull);
  });
}
