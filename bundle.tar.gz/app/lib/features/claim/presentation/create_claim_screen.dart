
import 'package:crypto/crypto.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:geolocator/geolocator.dart';
import 'package:image_picker/image_picker.dart';

import '../../../core/utils/formatters.dart';
import '../../../core/widgets/common.dart';
import '../../group/domain/entities.dart';
import '../data/claim_repository.dart';
import '../domain/entities.dart';

/// TẠO YÊU CẦU HỖ TRỢ: chụp ảnh/quay video TRỰC TIẾP (không chọn từ thư viện),
/// tự lấy GPS, mô tả rủi ro, số tiền đề nghị.
class CreateClaimScreen extends ConsumerStatefulWidget {
  const CreateClaimScreen({super.key, required this.group});
  final MyGroup group;
  @override
  ConsumerState<CreateClaimScreen> createState() => _CreateClaimScreenState();
}

class _CreateClaimScreenState extends ConsumerState<CreateClaimScreen> {
  final _form = GlobalKey<FormState>();
  final _desc = TextEditingController();
  final _amount = TextEditingController();
  final _picker = ImagePicker();
  String _type = 'accident';
  DateTime _incidentAt = DateTime.now();
  final List<CapturedMedia> _media = [];
  Position? _pos;
  String? _gpsError;
  bool _sending = false;
  String _progress = '';

  @override
  void initState() {
    super.initState();
    _locate();
  }

  @override
  void dispose() {
    _desc.dispose();
    _amount.dispose();
    super.dispose();
  }

  Future<void> _locate() async {
    setState(() => _gpsError = null);
    try {
      if (!await Geolocator.isLocationServiceEnabled()) {
        throw 'Hãy bật Vị trí (GPS) trên điện thoại.';
      }
      var perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) perm = await Geolocator.requestPermission();
      if (perm == LocationPermission.denied || perm == LocationPermission.deniedForever) {
        throw 'Cần cấp quyền Vị trí để xác minh hiện trường.';
      }
      final p = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.high,
          timeLimit: Duration(seconds: 20),
        ),
      );
      if (mounted) setState(() => _pos = p);
    } catch (e) {
      if (mounted) setState(() => _gpsError = e.toString());
    }
  }

  Future<void> _capture({required bool video}) async {
    if (_media.length >= 6) {
      toast(context, 'Tối đa 6 ảnh/video');
      return;
    }
    try {
      final XFile? f = video
          ? await _picker.pickVideo(
              source: ImageSource.camera, maxDuration: const Duration(seconds: 30))
          : await _picker.pickImage(
              source: ImageSource.camera, imageQuality: 70, maxWidth: 1600);
      if (f == null) return;
      final bytes = await f.readAsBytes();
      if (video && bytes.length > 45 * 1024 * 1024) {
        if (mounted) toast(context, 'Video quá lớn, hãy quay ngắn hơn.', error: true);
        return;
      }
      setState(() => _media.add(CapturedMedia(
            bytes: bytes,
            isVideo: video,
            sha256: sha256.convert(bytes).toString(),
            capturedAt: DateTime.now(),
            ext: video ? 'mp4' : 'jpg',
          )));
    } catch (e) {
      if (mounted) toast(context, 'Không mở được camera: $e', error: true);
    }
  }

  Future<void> _pickTime() async {
    final now = DateTime.now();
    final d = await showDatePicker(
      context: context,
      initialDate: _incidentAt,
      firstDate: now.subtract(const Duration(days: 7)),
      lastDate: now,
    );
    if (d == null || !mounted) return;
    final t = await showTimePicker(context: context, initialTime: TimeOfDay.fromDateTime(_incidentAt));
    if (t == null) return;
    final v = DateTime(d.year, d.month, d.day, t.hour, t.minute);
    setState(() => _incidentAt = v.isAfter(now) ? now : v);
  }

  Future<void> _submit() async {
    if (!_form.currentState!.validate()) return;
    if (!_media.any((m) => !m.isVideo)) {
      toast(context, 'Cần ít nhất 1 ảnh hiện trường', error: true);
      return;
    }
    if (_pos == null) {
      toast(context, 'Chưa lấy được vị trí GPS', error: true);
      return;
    }

    final amount = int.parse(_amount.text.replaceAll('.', ''));
    final ok = await confirmDialog(
      context,
      'Gửi yêu cầu hỗ trợ?',
      'Yêu cầu ${money(amount)} sẽ được gửi tới 5 thành viên ngẫu nhiên để thẩm định. '
          'Khai báo gian dối sẽ bị khoá tài khoản.',
      ok: 'Gửi',
    );
    if (!ok || !mounted) return;

    setState(() {
      _sending = true;
      _progress = 'Đang tạo yêu cầu…';
    });
    try {
      await ref.read(claimRepositoryProvider).submitClaim(
            groupId: widget.group.id,
            incidentType: _type,
            description: _desc.text.trim(),
            amount: amount,
            incidentAt: _incidentAt,
            lat: _pos!.latitude,
            lng: _pos!.longitude,
            accuracy: _pos!.accuracy,
            media: _media,
            onProgress: (d, t) {
              if (mounted) setState(() => _progress = 'Đang tải lên $d/$t…');
            },
          );
      if (!mounted) return;
      toast(context, 'Đã gửi! Bạn sẽ thấy kết quả thẩm định trong Trang chủ.');
      Navigator.pop(context, true);
    } catch (e) {
      if (mounted) toast(context, e.toString(), error: true);
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Yêu cầu hỗ trợ')),
      body: AbsorbPointer(
        absorbing: _sending,
        child: Form(
          key: _form,
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              DropdownButtonFormField<String>(
                value: _type,
                decoration: const InputDecoration(labelText: 'Loại sự cố'),
                items: [
                  for (final e in incidentTypes.entries)
                    DropdownMenuItem(value: e.key, child: Text(e.value)),
                ],
                onChanged: (v) => setState(() => _type = v!),
              ),
              const SizedBox(height: 12),
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.schedule),
                title: const Text('Thời điểm xảy ra'),
                subtitle: Text(dateTime(_incidentAt)),
                trailing: const Icon(Icons.edit_calendar),
                onTap: _pickTime,
              ),
              TextFormField(
                controller: _desc,
                maxLines: 4,
                maxLength: 2000,
                decoration: const InputDecoration(
                  labelText: 'Mô tả sự việc',
                  hintText: 'Chuyện gì đã xảy ra, ở đâu, thiệt hại thế nào…',
                  alignLabelWithHint: true,
                ),
                validator: (v) => (v ?? '').trim().length < 20 ? 'Mô tả tối thiểu 20 ký tự' : null,
              ),
              const SizedBox(height: 4),
              TextFormField(
                controller: _amount,
                keyboardType: TextInputType.number,
                inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                decoration: const InputDecoration(labelText: 'Số tiền đề nghị hỗ trợ (đ)', suffixText: 'đ'),
                validator: (v) {
                  final n = int.tryParse(v ?? '');
                  if (n == null || n < 10000) return 'Nhập số tiền hợp lệ';
                  return null;
                },
              ),
              const SizedBox(height: 20),

              // ---- GPS ----
              Card(
                child: ListTile(
                  leading: Icon(_pos != null ? Icons.location_on : Icons.location_off,
                      color: _pos != null ? Colors.green : Colors.red),
                  title: Text(_pos != null ? 'Đã xác định vị trí' : (_gpsError ?? 'Đang lấy vị trí…')),
                  subtitle: _pos == null
                      ? null
                      : Text('${_pos!.latitude.toStringAsFixed(5)}, ${_pos!.longitude.toStringAsFixed(5)} '
                          '(±${_pos!.accuracy.round()}m)'),
                  trailing: IconButton(icon: const Icon(Icons.refresh), onPressed: _locate),
                ),
              ),
              const SizedBox(height: 12),

              // ---- Ảnh / video ----
              Text('Ảnh / video hiện trường (${_media.length}/6)',
                  style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 4),
              const Text('Chụp trực tiếp tại chỗ. Không dùng ảnh cũ — hệ thống sẽ phát hiện.',
                  style: TextStyle(color: Colors.black54)),
              const SizedBox(height: 8),
              Wrap(spacing: 8, runSpacing: 8, children: [
                for (var i = 0; i < _media.length; i++)
                  Stack(children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: _media[i].isVideo
                          ? Container(
                              width: 96, height: 96, color: Colors.black87,
                              child: const Icon(Icons.videocam, color: Colors.white, size: 40))
                          : Image.memory(_media[i].bytes,
                              width: 96, height: 96, fit: BoxFit.cover),
                    ),
                    Positioned(
                      right: 0, top: 0,
                      child: InkWell(
                        onTap: () => setState(() => _media.removeAt(i)),
                        child: const CircleAvatar(
                            radius: 12, backgroundColor: Colors.black54,
                            child: Icon(Icons.close, size: 14, color: Colors.white)),
                      ),
                    ),
                  ]),
              ]),
              const SizedBox(height: 8),
              Row(children: [
                Expanded(
                  child: OutlinedButton.icon(
                    icon: const Icon(Icons.photo_camera),
                    label: const Text('Chụp ảnh'),
                    onPressed: () => _capture(video: false),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: OutlinedButton.icon(
                    icon: const Icon(Icons.videocam),
                    label: const Text('Quay video'),
                    onPressed: () => _capture(video: true),
                  ),
                ),
              ]),
              const SizedBox(height: 24),
              FilledButton(
                onPressed: _sending ? null : _submit,
                child: _sending
                    ? Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                        const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)),
                        const SizedBox(width: 12),
                        Text(_progress),
                      ])
                    : const Text('Gửi yêu cầu thẩm định'),
              ),
              const SizedBox(height: 8),
              const Text(
                'Số tiền thực nhận không vượt mức tối đa của nhóm và 20% số dư quỹ.',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.black54, fontSize: 13),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
