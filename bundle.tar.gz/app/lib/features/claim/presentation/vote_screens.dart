import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../../core/utils/formatters.dart';
import '../../../core/widgets/common.dart';
import '../../group/data/group_repository.dart';
import '../data/claim_repository.dart';
import '../domain/entities.dart';
import 'claim_widgets.dart';

/// Danh sách việc thẩm định được giao cho tôi.
class VoteListScreen extends ConsumerWidget {
  const VoteListScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final tasks = ref.watch(voteTasksProvider);
    return RefreshIndicator(
      onRefresh: () async => ref.invalidate(voteTasksProvider),
      child: AsyncView<List<VoteTask>>(
        value: tasks,
        onRetry: () => ref.invalidate(voteTasksProvider),
        data: (list) => ListView(
          padding: const EdgeInsets.all(16),
          children: [
            const Text(
              'Bạn được chọn ngẫu nhiên để thẩm định. Hãy xem kỹ ảnh, vị trí và mô tả — '
              'quyết định của bạn ảnh hưởng tới quỹ chung của cả nhóm.',
              style: TextStyle(color: Colors.black54),
            ),
            const SizedBox(height: 12),
            if (list.isEmpty)
              const EmptyHint('Không có yêu cầu nào cần bạn thẩm định.', icon: Icons.how_to_vote_outlined),
            for (final t in list)
              Card(
                margin: const EdgeInsets.only(bottom: 12),
                child: ListTile(
                  contentPadding: const EdgeInsets.all(12),
                  leading: const CircleAvatar(child: Icon(Icons.how_to_vote)),
                  title: Text('${incidentTypes[t.incidentType] ?? t.incidentType} · ${money(t.amountRequested)}'),
                  subtitle: Text('${t.claimant} · ${t.groupName}\nHạn bầu: ${dateTime(t.deadline)}'),
                  isThreeLine: true,
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () async {
                    await Navigator.push(
                        context, MaterialPageRoute(builder: (_) => VoteDetailScreen(task: t)));
                    ref.invalidate(voteTasksProvider);
                  },
                ),
              ),
          ],
        ),
      ),
    );
  }
}

/// MÀN HÌNH BỎ PHIẾU THẨM ĐỊNH
class VoteDetailScreen extends ConsumerStatefulWidget {
  const VoteDetailScreen({super.key, required this.task});
  final VoteTask task;
  @override
  ConsumerState<VoteDetailScreen> createState() => _VoteDetailScreenState();
}

class _VoteDetailScreenState extends ConsumerState<VoteDetailScreen> {
  bool _checkedMedia = false;
  bool _checkedLocation = false;
  bool _sending = false;

  Future<void> _vote(bool approve) async {
    String? comment;
    if (!approve) {
      comment = await _askReason();
      if (comment == null) return;
    } else {
      final ok = await confirmDialog(context, 'Xác nhận ĐỒNG Ý?',
          'Bạn xác nhận sự cố là có thật và mức đề nghị hợp lý.');
      if (!ok) return;
    }
    setState(() => _sending = true);
    try {
      final status = await ref.read(claimRepositoryProvider).castVote(widget.task.claimId, approve, comment);
      if (!mounted) return;
      toast(context, status == 'approved'
          ? 'Đủ phiếu! Yêu cầu đã được duyệt chi từ quỹ.'
          : status == 'rejected'
              ? 'Yêu cầu không được duyệt.'
              : 'Đã ghi nhận phiếu của bạn.');
      ref.invalidate(myGroupsProvider);
      Navigator.pop(context);
    } catch (e) {
      if (mounted) toast(context, e.toString(), error: true);
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  Future<String?> _askReason() {
    final c = TextEditingController();
    return showDialog<String>(
      context: context,
      builder: (d) => AlertDialog(
        title: const Text('Lý do không đồng ý'),
        content: TextField(
          controller: c,
          maxLines: 3,
          autofocus: true,
          decoration: const InputDecoration(hintText: 'Ví dụ: ảnh không khớp mô tả…'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(d), child: const Text('Huỷ')),
          FilledButton(
            onPressed: () => c.text.trim().length >= 5 ? Navigator.pop(d, c.text.trim()) : null,
            child: const Text('Gửi'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final t = widget.task;
    final mapUrl = Uri.parse('https://www.google.com/maps/search/?api=1&query=${t.lat},${t.lng}');
    return Scaffold(
      appBar: AppBar(
        title: const Text('Thẩm định yêu cầu'),
        actions: [
          IconButton(
            tooltip: 'Báo cáo gian lận',
            icon: const Icon(Icons.flag_outlined, color: Colors.red),
            onPressed: () async {
              await showFlagDialog(context, ref, t.claimId);
              if (context.mounted) Navigator.pop(context);
            },
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text(incidentTypes[t.incidentType] ?? t.incidentType,
              style: Theme.of(context).textTheme.headlineSmall),
          const SizedBox(height: 4),
          Text('${t.claimant} · ${t.groupName}', style: const TextStyle(color: Colors.black54)),
          const SizedBox(height: 16),
          Card(
            child: Column(children: [
              ListTile(
                leading: const Icon(Icons.payments_outlined),
                title: const Text('Số tiền đề nghị'),
                trailing: Text(money(t.amountRequested),
                    style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
              ),
              ListTile(
                leading: const Icon(Icons.schedule),
                title: const Text('Thời điểm sự cố'),
                trailing: Text(dateTime(t.incidentAt)),
              ),
              ListTile(
                leading: const Icon(Icons.timer_outlined),
                title: const Text('Hạn bỏ phiếu'),
                trailing: Text(dateTime(t.deadline)),
              ),
            ]),
          ),
          const SectionTitle('Mô tả'),
          Padding(padding: const EdgeInsets.symmetric(horizontal: 4), child: Text(t.description)),
          const SectionTitle('Ảnh / video hiện trường'),
          SizedBox(
            height: 180,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: t.media.length,
              separatorBuilder: (_, __) => const SizedBox(width: 8),
              itemBuilder: (_, i) => _MediaThumb(media: t.media[i]),
            ),
          ),
          const SectionTitle('Vị trí GPS'),
          Card(
            child: ListTile(
              leading: const Icon(Icons.map_outlined),
              title: Text('${t.lat.toStringAsFixed(5)}, ${t.lng.toStringAsFixed(5)}'),
              subtitle: const Text('Mở bản đồ để kiểm tra địa điểm'),
              trailing: const Icon(Icons.open_in_new),
              onTap: () => launchUrl(mapUrl, mode: LaunchMode.externalApplication),
            ),
          ),
          const SizedBox(height: 12),
          CheckboxListTile(
            value: _checkedMedia,
            onChanged: (v) => setState(() => _checkedMedia = v ?? false),
            title: const Text('Tôi đã xem kỹ ảnh/video'),
            controlAffinity: ListTileControlAffinity.leading,
          ),
          CheckboxListTile(
            value: _checkedLocation,
            onChanged: (v) => setState(() => _checkedLocation = v ?? false),
            title: const Text('Tôi đã kiểm tra vị trí và mô tả'),
            controlAffinity: ListTileControlAffinity.leading,
          ),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(
              child: OutlinedButton.icon(
                style: OutlinedButton.styleFrom(foregroundColor: Colors.red),
                icon: const Icon(Icons.thumb_down_alt_outlined),
                label: const Text('Không đồng ý'),
                onPressed: _sending ? null : () => _vote(false),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: FilledButton.icon(
                icon: const Icon(Icons.thumb_up_alt_outlined),
                label: const Text('Đồng ý'),
                onPressed: (_sending || !_checkedMedia || !_checkedLocation) ? null : () => _vote(true),
              ),
            ),
          ]),
          const SizedBox(height: 8),
          const Text(
            'Cần 4/5 người đồng ý để quỹ tự động giải ngân. Danh tính người bầu được giữ kín.',
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.black54, fontSize: 13),
          ),
        ],
      ),
    );
  }
}

class _MediaThumb extends ConsumerWidget {
  const _MediaThumb({required this.media});
  final MediaRef media;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final url = ref.watch(signedUrlProvider(media.path));
    return ClipRRect(
      borderRadius: BorderRadius.circular(12),
      child: SizedBox(
        width: 180,
        child: url.when(
          loading: () => const ColoredBox(color: Colors.black12, child: Center(child: CircularProgressIndicator())),
          error: (e, _) => const ColoredBox(color: Colors.black12, child: Icon(Icons.broken_image)),
          data: (u) => media.isVideo
              ? InkWell(
                  onTap: () => launchUrl(Uri.parse(u), mode: LaunchMode.externalApplication),
                  child: const ColoredBox(
                    color: Colors.black87,
                    child: Center(child: Icon(Icons.play_circle, color: Colors.white, size: 56)),
                  ),
                )
              : InkWell(
                  onTap: () => Navigator.push(context, MaterialPageRoute(
                    builder: (_) => Scaffold(
                      backgroundColor: Colors.black,
                      appBar: AppBar(backgroundColor: Colors.black, foregroundColor: Colors.white),
                      body: InteractiveViewer(child: Center(child: Image.network(u))),
                    ),
                  )),
                  child: Image.network(u, fit: BoxFit.cover),
                ),
        ),
      ),
    );
  }
}
