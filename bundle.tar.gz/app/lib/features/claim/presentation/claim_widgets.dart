import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/utils/formatters.dart';
import '../../../core/widgets/common.dart';
import '../data/claim_repository.dart';
import '../domain/entities.dart';

/// Một dòng yêu cầu hỗ trợ trong nhóm (công khai, không lộ ai đã bầu).
class GroupClaimTile extends ConsumerWidget {
  const GroupClaimTile({super.key, required this.claim});
  final GroupClaim claim;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final c = claim;
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: () => _showDetail(context, ref),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Expanded(
                child: Text('${incidentTypes[c.incidentType] ?? c.incidentType}'
                    '${c.isMine ? ' (của bạn)' : ''}',
                    style: const TextStyle(fontWeight: FontWeight.w600)),
              ),
              StatusChip(c.status, claimStatusLabel[c.status] ?? c.status),
            ]),
            const SizedBox(height: 4),
            Text('${c.claimant} · ${dateTime(c.at)}', style: const TextStyle(color: Colors.black54)),
            const SizedBox(height: 6),
            Text(c.description, maxLines: 2, overflow: TextOverflow.ellipsis),
            const SizedBox(height: 6),
            Row(children: [
              Text('Đề nghị: ${money(c.amountRequested)}'),
              const Spacer(),
              if (c.amountApproved != null)
                Text('Được chi: ${money(c.amountApproved!)}',
                    style: const TextStyle(color: Colors.green, fontWeight: FontWeight.w600)),
              if (c.status == 'voting')
                Text('Đồng ý ${c.approvals}/${c.votesNeeded}',
                    style: const TextStyle(color: Colors.orange, fontWeight: FontWeight.w600)),
            ]),
          ]),
        ),
      ),
    );
  }

  void _showDetail(BuildContext context, WidgetRef ref) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (sheet) => Padding(
        padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(incidentTypes[claim.incidentType] ?? claim.incidentType,
              style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          Text(claim.description),
          const SizedBox(height: 12),
          Text('Phiếu: ${claim.approvals} đồng ý · ${claim.rejections} không đồng ý '
              '(cần ${claim.votesNeeded} đồng ý)'),
          const SizedBox(height: 16),
          if (!claim.isMine && (claim.status == 'voting' || claim.status == 'approved'))
            OutlinedButton.icon(
              style: OutlinedButton.styleFrom(foregroundColor: Colors.red),
              icon: const Icon(Icons.flag_outlined),
              label: const Text('Báo cáo nghi vấn gian lận'),
              onPressed: () async {
                Navigator.pop(sheet);
                await showFlagDialog(context, ref, claim.id);
              },
            ),
        ]),
      ),
    );
  }
}

const flagReasons = <String, String>{
  'fake_media': 'Ảnh/video giả hoặc lấy trên mạng',
  'staged': 'Dàn dựng sự cố',
  'duplicate': 'Trùng với yêu cầu đã có',
  'exaggerated': 'Khai khống số tiền',
  'other': 'Lý do khác',
};

Future<void> showFlagDialog(BuildContext context, WidgetRef ref, String claimId) async {
  String reason = 'fake_media';
  final details = TextEditingController();
  final ok = await showDialog<bool>(
    context: context,
    builder: (d) => StatefulBuilder(
      builder: (d, setS) => AlertDialog(
        title: const Text('Báo cáo nghi vấn'),
        content: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            for (final e in flagReasons.entries)
              RadioListTile<String>(
                dense: true,
                value: e.key,
                groupValue: reason,
                title: Text(e.value),
                onChanged: (v) => setS(() => reason = v!),
              ),
            TextField(
              controller: details,
              maxLines: 3,
              decoration: const InputDecoration(hintText: 'Mô tả thêm (không bắt buộc)'),
            ),
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Huỷ')),
          FilledButton(onPressed: () => Navigator.pop(d, true), child: const Text('Gửi báo cáo')),
        ],
      ),
    ),
  );
  if (ok != true || !context.mounted) return;
  await runAction(context, () => ref.read(claimRepositoryProvider).flag(claimId, reason, details.text),
      success: 'Đã gửi báo cáo. Admin sẽ kiểm tra.');
}
