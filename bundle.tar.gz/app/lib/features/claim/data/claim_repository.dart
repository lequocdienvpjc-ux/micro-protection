import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../../core/error/failure.dart';
import '../../auth/presentation/providers/auth_providers.dart';
import '../domain/entities.dart';

class ClaimRepository {
  ClaimRepository(this._db);
  final SupabaseClient _db;
  static const bucket = 'claim-media';

  Future<T> _guard<T>(Future<T> Function() run) async {
    try {
      return await run();
    } catch (e) {
      throw Failure.from(e);
    }
  }

  List<Map<String, dynamic>> _rows(dynamic r) => (r as List).cast<Map<String, dynamic>>();

  Future<List<GroupClaim>> groupClaims(String groupId) => _guard(() async =>
      _rows(await _db.rpc('get_group_claims', params: {'p_group': groupId}))
          .map(GroupClaim.fromJson)
          .toList());

  Future<List<VoteTask>> myVoteTasks() => _guard(() async =>
      _rows(await _db.rpc('get_my_vote_tasks')).map(VoteTask.fromJson).toList());

  /// Luồng gửi yêu cầu: tạo nháp -> upload từng file -> ghi metadata -> gửi thẩm định.
  /// [onProgress] nhận (đã xong, tổng) để hiển thị tiến độ.
  Future<void> submitClaim({
    required String groupId,
    required String incidentType,
    required String description,
    required int amount,
    required DateTime incidentAt,
    required double lat,
    required double lng,
    double? accuracy,
    required List<CapturedMedia> media,
    void Function(int done, int total)? onProgress,
  }) =>
      _guard(() async {
        final claimId = await _db.rpc('create_claim_draft', params: {
          'p_group': groupId,
          'p_incident_type': incidentType,
          'p_description': description,
          'p_amount': amount,
          'p_incident_at': incidentAt.toUtc().toIso8601String(),
          'p_lat': lat,
          'p_lng': lng,
          'p_accuracy': accuracy,
        }) as String;

        for (var i = 0; i < media.length; i++) {
          final m = media[i];
          final path = '$groupId/$claimId/${m.sha256.substring(0, 16)}.${m.ext}';
          await _db.storage.from(bucket).uploadBinary(
                path,
                m.bytes,
                fileOptions: FileOptions(
                  contentType: m.isVideo ? 'video/mp4' : 'image/jpeg',
                  upsert: false,
                ),
              );
          await _db.rpc('add_claim_media', params: {
            'p_claim': claimId,
            'p_path': path,
            'p_type': m.isVideo ? 'video' : 'photo',
            'p_sha256': m.sha256,
            'p_captured_at': m.capturedAt.toUtc().toIso8601String(),
            'p_lat': lat,
            'p_lng': lng,
          });
          onProgress?.call(i + 1, media.length);
        }
        await _db.rpc('submit_claim', params: {'p_claim': claimId});
      });

  Future<String> signedUrl(String path) =>
      _guard(() => _db.storage.from(bucket).createSignedUrl(path, 3600));

  Future<String> castVote(String claimId, bool approve, String? comment) => _guard(() async =>
      await _db.rpc('cast_vote', params: {
        'p_claim': claimId,
        'p_choice': approve ? 'approve' : 'reject',
        'p_comment': comment,
      }) as String);

  Future<void> flag(String claimId, String reason, String? details) => _guard(() =>
      _db.rpc('flag_claim', params: {'p_claim': claimId, 'p_reason': reason, 'p_details': details}));
}

final claimRepositoryProvider =
    Provider((ref) => ClaimRepository(ref.watch(supabaseClientProvider)));

final groupClaimsProvider = FutureProvider.autoDispose.family<List<GroupClaim>, String>(
    (ref, id) => ref.watch(claimRepositoryProvider).groupClaims(id));

final voteTasksProvider = FutureProvider.autoDispose<List<VoteTask>>(
    (ref) => ref.watch(claimRepositoryProvider).myVoteTasks());

final signedUrlProvider = FutureProvider.autoDispose.family<String, String>(
    (ref, path) => ref.watch(claimRepositoryProvider).signedUrl(path));
