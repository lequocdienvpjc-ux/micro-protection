import 'dart:typed_data';

import '../../../core/utils/formatters.dart';

class GroupClaim {
  GroupClaim.fromJson(Map<String, dynamic> j)
      : id = j['claim_id'] as String,
        claimant = j['claimant_display'] as String,
        isMine = j['is_mine'] as bool,
        incidentType = j['incident_type'] as String,
        description = j['description'] as String,
        amountRequested = asInt(j['amount_requested']),
        amountApproved = j['amount_approved'] == null ? null : asInt(j['amount_approved']),
        status = j['status'] as String,
        approvals = asInt(j['approvals']),
        rejections = asInt(j['rejections']),
        votesNeeded = asInt(j['voters_needed']),
        at = asDate(j['created_at']);

  final String id, claimant, incidentType, description, status;
  final bool isMine;
  final int amountRequested, approvals, rejections, votesNeeded;
  final int? amountApproved;
  final DateTime at;
}

class MediaRef {
  MediaRef.fromJson(Map<String, dynamic> j)
      : path = j['path'] as String,
        type = j['type'] as String,
        capturedAt = asDate(j['captured_at']);
  final String path, type;
  final DateTime capturedAt;
  bool get isVideo => type == 'video';
}

class VoteTask {
  VoteTask.fromJson(Map<String, dynamic> j)
      : claimId = j['claim_id'] as String,
        groupName = j['group_name'] as String,
        claimant = j['claimant_display'] as String,
        incidentType = j['incident_type'] as String,
        description = j['description'] as String,
        amountRequested = asInt(j['amount_requested']),
        incidentAt = asDate(j['incident_at']),
        lat = (j['lat'] as num).toDouble(),
        lng = (j['lng'] as num).toDouble(),
        deadline = asDate(j['deadline']),
        media = (j['media'] as List).cast<Map<String, dynamic>>().map(MediaRef.fromJson).toList();

  final String claimId, groupName, claimant, incidentType, description;
  final int amountRequested;
  final DateTime incidentAt, deadline;
  final double lat, lng;
  final List<MediaRef> media;
}

/// Ảnh/video vừa chụp, chờ tải lên.
class CapturedMedia {
  CapturedMedia({
    required this.bytes,
    required this.isVideo,
    required this.sha256,
    required this.capturedAt,
    required this.ext,
  });
  final Uint8List bytes;
  final bool isVideo;
  final String sha256;
  final DateTime capturedAt;
  final String ext;
}
