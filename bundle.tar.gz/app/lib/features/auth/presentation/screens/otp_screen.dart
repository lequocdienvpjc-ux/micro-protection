import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/router/app_router.dart';
import '../../../../core/utils/validators.dart';
import '../providers/auth_providers.dart';
import '../widgets/auth_widgets.dart';

class OtpScreen extends ConsumerStatefulWidget {
  const OtpScreen({super.key, required this.phoneE164});
  final String phoneE164;
  @override
  ConsumerState<OtpScreen> createState() => _OtpScreenState();
}

class _OtpScreenState extends ConsumerState<OtpScreen> {
  static const _resendSeconds = 60;
  final _code = TextEditingController();
  Timer? _timer;
  int _remaining = _resendSeconds;

  @override
  void initState() {
    super.initState();
    // Mất tham số (vd. app bị khởi động lại) -> quay về nhập số
    if (widget.phoneE164.isEmpty) {
      WidgetsBinding.instance.addPostFrameCallback((_) => context.go(Routes.login));
      return;
    }
    _startTimer();
  }

  void _startTimer() {
    _timer?.cancel();
    setState(() => _remaining = _resendSeconds);
    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (_remaining <= 1) t.cancel();
      if (mounted) setState(() => _remaining--);
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    _code.dispose();
    super.dispose();
  }

  Future<void> _verify() async {
    final err = Validators.otp(_code.text);
    if (err != null) {
      showError(context, err);
      return;
    }
    final ok = await ref
        .read(authControllerProvider.notifier)
        .verifyOtp(widget.phoneE164, _code.text);
    if (!mounted) return;
    // Thành công: router tự chuyển sang KYC hoặc Home theo trạng thái hồ sơ
    if (!ok) {
      _code.clear();
      showError(context, ref.read(authControllerProvider).error);
    }
  }

  Future<void> _resend() async {
    final ok = await ref.read(authControllerProvider.notifier).sendOtp(widget.phoneE164);
    if (!mounted) return;
    if (ok) {
      _startTimer();
    } else {
      showError(context, ref.read(authControllerProvider).error);
    }
  }

  String get _maskedPhone {
    final p = widget.phoneE164;
    return p.length < 6 ? p : '${p.substring(0, p.length - 6)}***${p.substring(p.length - 3)}';
  }

  @override
  Widget build(BuildContext context) {
    final loading = ref.watch(authControllerProvider).isLoading;
    return AuthScaffold(
      showBack: true,
      title: 'Nhập mã xác thực',
      subtitle: 'Mã 6 số đã được gửi tới $_maskedPhone',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          TextField(
            controller: _code,
            autofocus: true,
            keyboardType: TextInputType.number,
            autofillHints: const [AutofillHints.oneTimeCode],
            maxLength: 6,
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 28, letterSpacing: 12, fontWeight: FontWeight.w600),
            inputFormatters: [FilteringTextInputFormatter.digitsOnly],
            decoration: const InputDecoration(counterText: '', hintText: '••••••'),
            onChanged: (v) {
              if (v.length == 6 && !loading) _verify(); // tự xác nhận khi đủ 6 số
            },
          ),
          const SizedBox(height: 20),
          PrimaryButton(label: 'Xác nhận', loading: loading, onPressed: _verify),
          const SizedBox(height: 12),
          TextButton(
            onPressed: (_remaining > 0 || loading) ? null : _resend,
            child: Text(_remaining > 0 ? 'Gửi lại mã sau ${_remaining}s' : 'Gửi lại mã'),
          ),
        ],
      ),
    );
  }
}
