import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/router/app_router.dart';
import '../../../../core/utils/validators.dart';
import '../providers/auth_providers.dart';
import '../widgets/auth_widgets.dart';

/// Đăng nhập/đăng ký bằng SỐ ĐIỆN THOẠI (OTP).
/// Cần cấu hình nhà cung cấp SMS trong Supabase (Auth > Providers > Phone).
/// Cùng một luồng cho cả người mới và người cũ — Supabase tự tạo tài khoản.
class LoginScreen extends ConsumerStatefulWidget {
  const LoginScreen({super.key});
  @override
  ConsumerState<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends ConsumerState<LoginScreen> {
  final _form = GlobalKey<FormState>();
  final _phone = TextEditingController();

  @override
  void dispose() {
    _phone.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_form.currentState!.validate()) return;
    final phone = Validators.normalizeVnPhone(_phone.text);
    final ok = await ref.read(authControllerProvider.notifier).sendOtp(phone);
    if (!mounted) return;
    if (ok) {
      context.push(Routes.otp, extra: phone);
    } else {
      showError(context, ref.read(authControllerProvider).error);
    }
  }

  @override
  Widget build(BuildContext context) {
    final loading = ref.watch(authControllerProvider).isLoading;
    return AuthScaffold(
      showBack: true,
      title: 'Đăng nhập bằng SĐT',
      subtitle: 'Nhận mã OTP qua tin nhắn SMS',
      child: Form(
        key: _form,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextFormField(
              controller: _phone,
              keyboardType: TextInputType.phone,
              autofillHints: const [AutofillHints.telephoneNumber],
              inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'[0-9+ ]'))],
              decoration: const InputDecoration(
                labelText: 'Số điện thoại',
                hintText: '0901 234 567',
                prefixIcon: Icon(Icons.phone_iphone),
              ),
              validator: Validators.phone,
              onFieldSubmitted: (_) => _submit(),
            ),
            const SizedBox(height: 20),
            PrimaryButton(label: 'Nhận mã OTP', loading: loading, onPressed: _submit),
            const SizedBox(height: 24),
            Text(
              'Bằng việc tiếp tục, bạn đồng ý với Điều khoản sử dụng và '
              'Chính sách bảo vệ dữ liệu cá nhân.',
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.bodySmall,
            ),
          ],
        ),
      ),
    );
  }
}
