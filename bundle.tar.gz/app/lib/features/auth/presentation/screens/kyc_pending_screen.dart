import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../providers/auth_providers.dart';
import '../widgets/auth_widgets.dart';

/// Chờ admin / trưởng nhóm duyệt KYC. Tự kiểm tra lại khi người dùng mở lại app.
class KycPendingScreen extends ConsumerStatefulWidget {
  const KycPendingScreen({super.key});
  @override
  ConsumerState<KycPendingScreen> createState() => _KycPendingScreenState();
}

class _KycPendingScreenState extends ConsumerState<KycPendingScreen>
    with WidgetsBindingObserver {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) ref.invalidate(currentUserProvider);
  }

  @override
  Widget build(BuildContext context) {
    final user = ref.watch(currentUserProvider);
    return AuthScaffold(
      title: 'Đang chờ duyệt hồ sơ',
      subtitle: 'Thường trong vòng 24 giờ. Bạn sẽ được vào nhóm ngay khi hồ sơ được duyệt.',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Card(
            child: ListTile(
              leading: const Icon(Icons.hourglass_top),
              title: Text(user.valueOrNull?.fullName ?? ''),
              subtitle: Text('CCCD ***${user.valueOrNull?.nationalIdLast4 ?? '----'}'),
            ),
          ),
          const SizedBox(height: 24),
          PrimaryButton(
            label: 'Kiểm tra lại',
            loading: user.isLoading,
            onPressed: () => ref.invalidate(currentUserProvider),
          ),
          TextButton(
            onPressed: () => ref.read(authControllerProvider.notifier).signOut(),
            child: const Text('Đăng xuất'),
          ),
        ],
      ),
    );
  }
}
