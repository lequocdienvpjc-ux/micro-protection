import 'package:supabase_flutter/supabase_flutter.dart';

import '../models/profile_model.dart';
import '../../domain/entities/app_user.dart';

/// Lớp duy nhất gọi trực tiếp Supabase cho luồng Auth.
class AuthRemoteDataSource {
  AuthRemoteDataSource(this._client);
  final SupabaseClient _client;

  GoTrueClient get _auth => _client.auth;

  Stream<AuthState> get authChanges => _auth.onAuthStateChange;
  Session? get session => _auth.currentSession;

  Future<void> sendPhoneOtp(String phone) =>
      _auth.signInWithOtp(phone: phone, shouldCreateUser: true);

  Future<void> verifyPhoneOtp(String phone, String code) async {
    final res = await _auth.verifyOTP(type: OtpType.sms, phone: phone, token: code);
    if (res.session == null) {
      throw const AuthException('OTP verification failed');
    }
  }

  Future<bool> signUpWithEmail(String email, String password) async {
    final res = await _auth.signUp(email: email, password: password);
    // Nếu project bật "Confirm email", session sẽ null cho tới khi bấm link xác nhận
    return res.session == null;
  }

  Future<void> signInWithEmail(String email, String password) =>
      _auth.signInWithPassword(email: email, password: password);

  Future<void> sendPasswordReset(String email) =>
      _auth.resetPasswordForEmail(email);

  Future<void> signOut() => _auth.signOut();

  Future<AppUser> fetchProfile(String userId) async {
    final row = await _client
        .from('profiles')
        .select(ProfileModel.columns)
        .eq('id', userId)
        .single();
    return ProfileModel.fromJson(row);
  }

  Future<KycStatus> submitKyc({
    required String fullName,
    required String nationalId,
    required String occupation,
    required bool consent,
  }) async {
    final result = await _client.rpc('submit_kyc', params: {
      'p_full_name': fullName,
      'p_national_id': nationalId,
      'p_occupation': occupation,
      'p_consent': consent,
    });
    return kycStatusFrom(result as String?);
  }
}
