import '../../../../core/error/failure.dart';
import '../../domain/entities/app_user.dart';
import '../../domain/repositories/auth_repository.dart';
import '../datasources/auth_remote_datasource.dart';

class AuthRepositoryImpl implements AuthRepository {
  AuthRepositoryImpl(this._remote);
  final AuthRemoteDataSource _remote;

  /// Bọc mọi lời gọi: lỗi kỹ thuật -> Failure tiếng Việt.
  Future<T> _guard<T>(Future<T> Function() run) async {
    try {
      return await run();
    } catch (e) {
      throw Failure.from(e);
    }
  }

  @override
  Stream<bool> watchSignedIn() =>
      _remote.authChanges.map((s) => s.session != null).distinct();

  @override
  bool get isSignedIn => _remote.session != null;

  @override
  String? get currentUserId => _remote.session?.user.id;

  @override
  Future<void> sendPhoneOtp(String phoneE164) =>
      _guard(() => _remote.sendPhoneOtp(phoneE164));

  @override
  Future<void> verifyPhoneOtp({required String phoneE164, required String code}) =>
      _guard(() => _remote.verifyPhoneOtp(phoneE164, code));

  @override
  Future<bool> signUpWithEmail({required String email, required String password}) =>
      _guard(() => _remote.signUpWithEmail(email.trim().toLowerCase(), password));

  @override
  Future<void> signInWithEmail({required String email, required String password}) =>
      _guard(() => _remote.signInWithEmail(email.trim().toLowerCase(), password));

  @override
  Future<void> sendPasswordReset(String email) =>
      _guard(() => _remote.sendPasswordReset(email.trim().toLowerCase()));

  @override
  Future<void> signOut() => _guard(_remote.signOut);

  @override
  Future<AppUser> fetchCurrentUser() => _guard(() {
        final id = currentUserId;
        if (id == null) throw const Failure('Phiên đăng nhập đã hết hạn.');
        return _remote.fetchProfile(id);
      });

  @override
  Future<KycStatus> submitKyc({
    required String fullName,
    required String nationalId,
    required String occupation,
    required bool consent,
  }) =>
      _guard(() => _remote.submitKyc(
            fullName: fullName.trim(),
            nationalId: nationalId.trim(),
            occupation: occupation.trim(),
            consent: consent,
          ));
}
