import '../../domain/entities/app_user.dart';

/// Ánh xạ bảng `profiles` <-> entity.
/// LƯU Ý: bảng profiles cấp quyền SELECT theo cột (ẩn CCCD mã hóa),
/// nên luôn select đúng danh sách [columns], KHÔNG dùng select('*').
class ProfileModel {
  static const columns =
      'id, phone, email, full_name, occupation, national_id_last4, kyc_status, system_role';

  static AppUser fromJson(Map<String, dynamic> j) => AppUser(
        id: j['id'] as String,
        phone: j['phone'] as String?,
        email: j['email'] as String?,
        fullName: j['full_name'] as String?,
        occupation: j['occupation'] as String?,
        nationalIdLast4: j['national_id_last4'] as String?,
        kycStatus: kycStatusFrom(j['kyc_status'] as String?),
        systemRole: j['system_role'] == 'admin' ? SystemRole.admin : SystemRole.member,
      );
}
