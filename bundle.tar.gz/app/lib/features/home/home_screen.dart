import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../admin/presentation/admin_screen.dart';
import '../auth/presentation/providers/auth_providers.dart';
import '../claim/data/claim_repository.dart';
import '../claim/presentation/vote_screens.dart';
import '../group/presentation/group_home_screen.dart';
import '../profile/profile_screen.dart';

/// Khung chính sau đăng nhập: Quỹ nhóm · Thẩm định · Tài khoản · (Quản trị)
class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});
  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen> {
  int _tab = 0;

  @override
  Widget build(BuildContext context) {
    final user = ref.watch(currentUserProvider).valueOrNull;
    final isAdmin = user?.isAdmin ?? false;
    final voteCount = ref.watch(voteTasksProvider).valueOrNull?.length ?? 0;

    final pages = <(String, Widget)>[
      ('Quỹ nhóm', const GroupHomeScreen()),
      ('Thẩm định', const VoteListScreen()),
      ('Tài khoản', const ProfileScreen()),
      if (isAdmin) ('Quản trị', const AdminScreen()),
    ];
    final index = _tab.clamp(0, pages.length - 1);

    return Scaffold(
      appBar: AppBar(
        title: Text(index == 0 ? 'Xin chào, ${user?.displayName ?? ''}' : pages[index].$1),
      ),
      body: IndexedStack(index: index, children: [for (final p in pages) p.$2]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (i) {
          setState(() => _tab = i);
          if (i == 1) ref.invalidate(voteTasksProvider);
        },
        destinations: [
          const NavigationDestination(icon: Icon(Icons.account_balance_wallet_outlined), label: 'Quỹ nhóm'),
          NavigationDestination(
            icon: Badge(
              isLabelVisible: voteCount > 0,
              label: Text('$voteCount'),
              child: const Icon(Icons.how_to_vote_outlined),
            ),
            label: 'Thẩm định',
          ),
          const NavigationDestination(icon: Icon(Icons.person_outline), label: 'Tài khoản'),
          if (isAdmin)
            const NavigationDestination(icon: Icon(Icons.admin_panel_settings_outlined), label: 'Quản trị'),
        ],
      ),
    );
  }
}
