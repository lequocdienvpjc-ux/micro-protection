import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/error/failure.dart';
import '../../../core/utils/formatters.dart';
import '../../../core/widgets/common.dart';
import '../../auth/presentation/providers/auth_providers.dart';
import '../../group/data/group_repository.dart';

// ---------------- Data ----------------
Future<dynamic> _rpc(WidgetRef ref, String fn, [Map<String, dynamic>? p]) async {
  try {
    return await ref.read(supabaseClientProvider).rpc(fn, params: p);
  } catch (e) {
    throw Failure.from(e);
  }
}

final _pendingKycProvider = FutureProvider.autoDispose<List<Map<String, dynamic>>>((ref) async {
  try {
    final r = await ref.read(supabaseClientProvider).rpc('admin_list_pending_kyc');
    return (r as List).cast<Map<String, dynamic>>();
  } catch (e) {
    throw Failure.from(e);
  }
});

final _reviewClaimsProvider = FutureProvider.autoDispose<List<Map<String, dynamic>>>((ref) async {
  try {
    final r = await ref.read(supabaseClientProvider).rpc('admin_list_review_claims');
    return (r as List).cast<Map<String, dynamic>>();
  } catch (e) {
    throw Failure.from(e);
  }
});

/// QUẢN TRỊ HỆ THỐNG: duyệt KYC, tạo nhóm, chỉ định trưởng nhóm, xử lý nghi vấn.
class AdminScreen extends ConsumerWidget {
  const AdminScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return DefaultTabController(
      length: 3,
      child: Column(children: [
        const TabBar(tabs: [Tab(text: 'Duyệt KYC'), Tab(text: 'Nhóm'), Tab(text: 'Nghi vấn')]),
        Expanded(
          child: TabBarView(children: [
            _KycTab(),
            _GroupsTab(),
            _ReviewTab(),
          ]),
        ),
      ]),
    );
  }
}

class _KycTab extends ConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final list = ref.watch(_pendingKycProvider);
    return RefreshIndicator(
      onRefresh: () async => ref.invalidate(_pendingKycProvider),
      child: AsyncView<List<Map<String, dynamic>>>(
        value: list,
        onRetry: () => ref.invalidate(_pendingKycProvider),
        data: (rows) => ListView(children: [
          if (rows.isEmpty) const EmptyHint('Không có hồ sơ chờ duyệt.'),
          for (final r in rows)
            Card(
              margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(r['full_name'] ?? '', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                  SelectableText('CCCD: ${r['national_id'] ?? ''}'),
                  Text('Nghề: ${riskTypeLabel[r['occupation']] ?? r['occupation'] ?? ''}'),
                  Text('Liên hệ: ${r['phone'] ?? r['email'] ?? ''}'),
                  const SizedBox(height: 8),
                  Row(children: [
                    Expanded(
                      child: OutlinedButton(
                        onPressed: () async {
                          await runAction(context,
                              () => _rpc(ref, 'review_kyc', {'p_user': r['user_id'], 'p_approve': false}));
                          ref.invalidate(_pendingKycProvider);
                        },
                        child: const Text('Từ chối'),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: FilledButton(
                        onPressed: () async {
                          await runAction(context,
                              () => _rpc(ref, 'review_kyc', {'p_user': r['user_id'], 'p_approve': true}),
                              success: 'Đã duyệt');
                          ref.invalidate(_pendingKycProvider);
                          ref.invalidate(currentUserProvider);
                        },
                        child: const Text('Duyệt'),
                      ),
                    ),
                  ]),
                ]),
              ),
            ),
        ]),
      ),
    );
  }
}

class _GroupsTab extends ConsumerStatefulWidget {
  @override
  ConsumerState<_GroupsTab> createState() => _GroupsTabState();
}

class _GroupsTabState extends ConsumerState<_GroupsTab> {
  final _form = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _desc = TextEditingController();
  final _amount = TextEditingController(text: '20000');
  final _max = TextEditingController(text: '2000000');
  final _bank = TextEditingController();
  final _acc = TextEditingController();
  final _accName = TextEditingController();
  final _waiting = TextEditingController(text: '30');
  final _minMembers = TextEditingController(text: '10');
  final _leaderContact = TextEditingController();
  String _risk = 'moto_driver';
  String _period = 'weekly';
  String? _leaderGroup;

  @override
  void dispose() {
    for (final c in [_name, _desc, _amount, _max, _bank, _acc, _accName, _waiting, _minMembers, _leaderContact]) {
      c.dispose();
    }
    super.dispose();
  }

  Widget _num(TextEditingController c, String label) => Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: TextFormField(
          controller: c,
          keyboardType: TextInputType.number,
          inputFormatters: [FilteringTextInputFormatter.digitsOnly],
          decoration: InputDecoration(labelText: label),
          validator: (v) => int.tryParse(v ?? '') == null ? 'Nhập số' : null,
        ),
      );

  Widget _text(TextEditingController c, String label, {bool required = true}) => Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: TextFormField(
          controller: c,
          decoration: InputDecoration(labelText: label),
          validator: (v) => required && (v ?? '').trim().isEmpty ? 'Bắt buộc' : null,
        ),
      );

  @override
  Widget build(BuildContext context) {
    final groups = ref.watch(openGroupsProvider);
    return ListView(padding: const EdgeInsets.all(16), children: [
      Text('Tạo nhóm rủi ro mới', style: Theme.of(context).textTheme.titleMedium),
      const SizedBox(height: 12),
      Form(
        key: _form,
        child: Column(children: [
          _text(_name, 'Tên nhóm (vd: Tài xế xe máy Quận 7)'),
          DropdownButtonFormField<String>(
            value: _risk,
            decoration: const InputDecoration(labelText: 'Loại nghề'),
            items: [for (final e in riskTypeLabel.entries) DropdownMenuItem(value: e.key, child: Text(e.value))],
            onChanged: (v) => setState(() => _risk = v!),
          ),
          const SizedBox(height: 12),
          _text(_desc, 'Mô tả ngắn', required: false),
          _num(_amount, 'Mức đóng mỗi kỳ (đ)'),
          DropdownButtonFormField<String>(
            value: _period,
            decoration: const InputDecoration(labelText: 'Chu kỳ đóng'),
            items: const [
              DropdownMenuItem(value: 'daily', child: Text('Hằng ngày')),
              DropdownMenuItem(value: 'weekly', child: Text('Hằng tuần')),
              DropdownMenuItem(value: 'monthly', child: Text('Hằng tháng')),
            ],
            onChanged: (v) => setState(() => _period = v!),
          ),
          const SizedBox(height: 12),
          _num(_max, 'Mức hỗ trợ tối đa / lần (đ)'),
          _num(_waiting, 'Số ngày chờ sau khi gia nhập'),
          _num(_minMembers, 'Số thành viên tối thiểu để xét hỗ trợ'),
          const Divider(height: 32),
          const Align(alignment: Alignment.centerLeft, child: Text('Tài khoản nhận quỹ của nhóm')),
          const SizedBox(height: 8),
          _text(_bank, 'Mã ngân hàng VietQR (vd: VCB, MB, TCB, ACB, BIDV, ICB)'),
          _text(_acc, 'Số tài khoản'),
          _text(_accName, 'Tên chủ tài khoản'),
          FilledButton(
            onPressed: () async {
              if (!_form.currentState!.validate()) return;
              final ok = await runAction(
                context,
                () => _rpc(ref, 'admin_create_group', {
                  'p_name': _name.text,
                  'p_risk_type': _risk,
                  'p_description': _desc.text,
                  'p_contribution_amount': int.parse(_amount.text),
                  'p_period': _period,
                  'p_max_claim': int.parse(_max.text),
                  'p_bank_bin': _bank.text,
                  'p_account_no': _acc.text,
                  'p_account_name': _accName.text,
                  'p_waiting_days': int.parse(_waiting.text),
                  'p_min_members': int.parse(_minMembers.text),
                }),
                success: 'Đã tạo nhóm',
              );
              if (ok) {
                _name.clear();
                _desc.clear();
                ref.invalidate(openGroupsProvider);
              }
            },
            child: const Text('Tạo nhóm'),
          ),
        ]),
      ),
      const Divider(height: 40),
      Text('Chỉ định Trưởng nhóm', style: Theme.of(context).textTheme.titleMedium),
      const SizedBox(height: 4),
      const Text('Người được chỉ định phải đã gia nhập nhóm. Trưởng nhóm duyệt tiền đóng quỹ và xác nhận chi trả.',
          style: TextStyle(color: Colors.black54)),
      const SizedBox(height: 12),
      AsyncView(
        value: groups,
        data: (list) => DropdownButtonFormField<String>(
          value: _leaderGroup,
          isExpanded: true,
          decoration: const InputDecoration(labelText: 'Nhóm'),
          items: [for (final g in list) DropdownMenuItem(value: g.id, child: Text(g.name))],
          onChanged: (v) => setState(() => _leaderGroup = v),
        ),
      ),
      const SizedBox(height: 12),
      TextField(
        controller: _leaderContact,
        decoration: const InputDecoration(labelText: 'Email hoặc SĐT của thành viên'),
      ),
      const SizedBox(height: 12),
      FilledButton.tonal(
        onPressed: () async {
          if (_leaderGroup == null || _leaderContact.text.trim().isEmpty) return;
          await runAction(
            context,
            () => _rpc(ref, 'admin_set_leader',
                {'p_group': _leaderGroup, 'p_contact': _leaderContact.text.trim(), 'p_is_leader': true}),
            success: 'Đã chỉ định trưởng nhóm',
          );
          ref.invalidate(myGroupsProvider);
        },
        child: const Text('Chỉ định'),
      ),
    ]);
  }
}

class _ReviewTab extends ConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final list = ref.watch(_reviewClaimsProvider);
    return RefreshIndicator(
      onRefresh: () async => ref.invalidate(_reviewClaimsProvider),
      child: AsyncView<List<Map<String, dynamic>>>(
        value: list,
        onRetry: () => ref.invalidate(_reviewClaimsProvider),
        data: (rows) => ListView(children: [
          if (rows.isEmpty) const EmptyHint('Không có yêu cầu nghi vấn.'),
          for (final r in rows)
            Card(
              margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('${r['claimant_name']} · ${r['group_name']}',
                      style: const TextStyle(fontWeight: FontWeight.w700)),
                  Text('Đề nghị ${money(asInt(r['amount_requested']))} · '
                      '${claimStatusLabel[r['status']] ?? r['status']}'),
                  const SizedBox(height: 4),
                  Text(r['description'] ?? ''),
                  const SizedBox(height: 6),
                  for (final f in (r['flags'] as List))
                    Text('⚑ ${f['reason']}: ${f['details'] ?? ''}', style: const TextStyle(color: Colors.red)),
                  const SizedBox(height: 8),
                  if (r['status'] == 'under_review' || r['status'] == 'voting')
                    Row(children: [
                      Expanded(
                        child: OutlinedButton(
                          style: OutlinedButton.styleFrom(foregroundColor: Colors.red),
                          onPressed: () async {
                            if (!await confirmDialog(context, 'Xác nhận gian lận?',
                                'Yêu cầu bị bác và thành viên bị tạm khoá trong nhóm.')) {
                              return;
                            }
                            if (!context.mounted) return;
                            await runAction(context,
                                () => _rpc(ref, 'admin_resolve_claim', {'p_claim': r['claim_id'], 'p_approve': false}));
                            ref.invalidate(_reviewClaimsProvider);
                          },
                          child: const Text('Gian lận – bác'),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: FilledButton(
                          onPressed: () async {
                            await runAction(context,
                                () => _rpc(ref, 'admin_resolve_claim', {'p_claim': r['claim_id'], 'p_approve': true}),
                                success: 'Đã duyệt chi');
                            ref.invalidate(_reviewClaimsProvider);
                          },
                          child: const Text('Hợp lệ – duyệt chi'),
                        ),
                      ),
                    ]),
                ]),
              ),
            ),
        ]),
      ),
    );
  }
}
