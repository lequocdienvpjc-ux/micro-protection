import '../../../core/utils/formatters.dart';

class MyGroup {
  MyGroup.fromJson(Map<String, dynamic> j)
      : id = j['group_id'] as String,
        name = j['name'] as String,
        riskType = j['risk_type'] as String,
        isLeader = j['my_role'] == 'leader',
        contributionAmount = asInt(j['contribution_amount']),
        period = j['contribution_period'] as String,
        balance = asInt(j['balance']),
        memberCount = asInt(j['member_count']),
        joinedAt = asDate(j['joined_at']);

  final String id, name, riskType, period;
  final bool isLeader;
  final int contributionAmount, balance, memberCount;
  final DateTime joinedAt;
}

class OpenGroup {
  OpenGroup.fromJson(Map<String, dynamic> j)
      : id = j['group_id'] as String,
        name = j['name'] as String,
        riskType = j['risk_type'] as String,
        description = j['description'] as String?,
        contributionAmount = asInt(j['contribution_amount']),
        period = j['contribution_period'] as String,
        maxClaim = asInt(j['max_claim_amount']),
        waitingDays = asInt(j['waiting_days']),
        memberCount = asInt(j['member_count']),
        isMember = j['is_member'] as bool;

  final String id, name, riskType, period;
  final String? description;
  final int contributionAmount, maxClaim, waitingDays, memberCount;
  final bool isMember;
}

class FundSummary {
  FundSummary.fromJson(Map<String, dynamic> j)
      : balance = asInt(j['balance']),
        totalIn = asInt(j['total_in']),
        totalOut = asInt(j['total_out']),
        totalFee = asInt(j['total_fee']),
        memberCount = asInt(j['member_count']);
  final int balance, totalIn, totalOut, totalFee, memberCount;
}

class LedgerLine {
  LedgerLine.fromJson(Map<String, dynamic> j)
      : type = j['txn_type'] as String,
        amount = asInt(j['amount']),
        member = j['member_display'] as String?,
        memo = j['memo'] as String?,
        at = asDate(j['created_at']);
  final String type;
  final int amount;
  final String? member, memo;
  final DateTime at;
}

class ContributionTicket {
  ContributionTicket.fromJson(Map<String, dynamic> j)
      : requestId = j['request_id'] as String,
        amount = asInt(j['amount']),
        transferCode = j['transfer_code'] as String,
        bankBin = j['bank_bin'] as String? ?? '',
        accountNo = j['bank_account_no'] as String? ?? '',
        accountName = j['bank_account_name'] as String? ?? '';
  final String requestId, transferCode, bankBin, accountNo, accountName;
  final int amount;

  /// Ảnh QR chuyển khoản theo chuẩn VietQR (napas247), app ngân hàng nào cũng quét được.
  String get qrUrl => 'https://img.vietqr.io/image/$bankBin-$accountNo-compact2.png'
      '?amount=$amount&addInfo=${Uri.encodeComponent(transferCode)}'
      '&accountName=${Uri.encodeComponent(accountName)}';
}

class PendingContribution {
  PendingContribution.fromJson(Map<String, dynamic> j)
      : requestId = j['request_id'] as String,
        memberName = j['member_name'] as String? ?? 'Thành viên',
        amount = asInt(j['amount']),
        periods = asInt(j['periods']),
        transferCode = j['transfer_code'] as String,
        at = asDate(j['created_at']);
  final String requestId, memberName, transferCode;
  final int amount, periods;
  final DateTime at;
}

class PendingPayout {
  PendingPayout.fromJson(Map<String, dynamic> j)
      : claimId = j['claim_id'] as String,
        memberName = j['member_name'] as String? ?? 'Thành viên',
        amount = asInt(j['amount']),
        bank = j['bank'] as String?,
        accountNo = j['account_no'] as String?,
        accountName = j['account_name'] as String?,
        openFlags = asInt(j['open_flags']);
  final String claimId, memberName;
  final int amount, openFlags;
  final String? bank, accountNo, accountName;
}
