import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/utils/formatters.dart';
import '../../../core/widgets/common.dart';
import '../data/group_repository.dart';
import '../domain/entities.dart';

/// Chọn & gia nhập "Nhóm rủi ro".
class JoinGroupScreen extends ConsumerWidget {
  const JoinGroupScreen({super.key, this.embedded = false});
  final bool embedded;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final groups = ref.watch(openGroupsProvider);
    final body = RefreshIndicator(
      onRefresh: () async => ref.invalidate(openGroupsProvider),
      child: AsyncView<List<OpenGroup>>(
        value: groups,
        onRetry: () => ref.invalidate(openGroupsProvider),
        data: (list) => ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Text('Chọn nhóm phù hợp với công việc của bạn',
                style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 4),
            const Text('Các thành viên cùng nghề góp quỹ nhỏ mỗi kỳ, '
                'cùng nhau thẩm định và hỗ trợ khi ai đó gặp rủi ro.'),
            const SizedBox(height: 16),
            if (list.isEmpty)
              const EmptyHint('Chưa có nhóm nào đang mở. Liên hệ Admin để tạo nhóm.'),
            for (final g in list) _GroupCard(g),
          ],
        ),
      ),
    );
    return embedded ? body : Scaffold(appBar: AppBar(title: const Text('Gia nhập nhóm')), body: body);
  }
}

class _GroupCard extends ConsumerWidget {
  const _GroupCard(this.g);
  final OpenGroup g;

  @override
  Widget build(BuildContext context, WidgetRef ref) => Card(
        margin: const EdgeInsets.only(bottom: 12),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              const Icon(Icons.groups_2_outlined),
              const SizedBox(width: 8),
              Expanded(child: Text(g.name, style: Theme.of(context).textTheme.titleMedium)),
              Text('${g.memberCount} người'),
            ]),
            const SizedBox(height: 4),
            Text(riskTypeLabel[g.riskType] ?? g.riskType,
                style: const TextStyle(color: Colors.black54)),
            if (g.description != null) ...[const SizedBox(height: 8), Text(g.description!)],
            const Divider(height: 24),
            Text('• Đóng góp: ${money(g.contributionAmount)}/${periodLabel[g.period]}'),
            Text('• Hỗ trợ tối đa: ${money(g.maxClaim)}/lần'),
            Text('• Được yêu cầu hỗ trợ sau ${g.waitingDays} ngày tham gia'),
            const SizedBox(height: 12),
            g.isMember
                ? const OutlinedButton(onPressed: null, child: Text('Bạn đã ở trong nhóm'))
                : FilledButton(
                    onPressed: () async {
                      final ok = await confirmDialog(context, 'Gia nhập ${g.name}?',
                          'Bạn cam kết đóng ${money(g.contributionAmount)} mỗi ${periodLabel[g.period]} '
                          'và tham gia thẩm định trung thực khi được chọn.');
                      if (!ok || !context.mounted) return;
                      final done = await runAction(
                          context, () => ref.read(groupRepositoryProvider).join(g.id),
                          success: 'Đã gia nhập nhóm!');
                      if (done) {
                        ref.read(selectedGroupIdProvider.notifier).state = g.id;
                        ref.invalidate(myGroupsProvider);
                        ref.invalidate(openGroupsProvider);
                        if (context.mounted && Navigator.canPop(context)) Navigator.pop(context);
                      }
                    },
                    child: const Text('Gia nhập'),
                  ),
          ]),
        ),
      );
}
