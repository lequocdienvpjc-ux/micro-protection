import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/utils/formatters.dart';
import '../../../core/widgets/common.dart';
import '../data/group_repository.dart';
import '../domain/entities.dart';

/// Sổ quỹ công khai: toàn bộ thu – chi của nhóm, ai cũng xem được.
class FundReportScreen extends ConsumerWidget {
  const FundReportScreen({super.key, required this.group});
  final MyGroup group;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = ref.watch(fundSummaryProvider(group.id));
    final lines = ref.watch(ledgerProvider(group.id));
    return Scaffold(
      appBar: AppBar(title: const Text('Sổ quỹ minh bạch')),
      body: RefreshIndicator(
        onRefresh: () async {
          ref.invalidate(fundSummaryProvider(group.id));
          ref.invalidate(ledgerProvider(group.id));
        },
        child: ListView(children: [
          AsyncView<FundSummary>(
            value: s,
            data: (v) => Card(
              margin: const EdgeInsets.all(16),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(children: [
                  _line('Tổng thu vào quỹ', v.totalIn, Colors.green),
                  _line('Tổng chi hỗ trợ', -v.totalOut, Colors.red),
                  const Divider(),
                  _line('Số dư hiện tại', v.balance, Colors.black, bold: true),
                  const SizedBox(height: 8),
                  _line('Phí nền tảng đã trích (ngoài quỹ)', v.totalFee, Colors.blueGrey),
                ]),
              ),
            ),
          ),
          const SectionTitle('Chi tiết giao dịch'),
          AsyncView<List<LedgerLine>>(
            value: lines,
            onRetry: () => ref.invalidate(ledgerProvider(group.id)),
            data: (list) => list.isEmpty
                ? const EmptyHint('Chưa có giao dịch.')
                : Column(children: [
                    for (final l in list)
                      ListTile(
                        leading: CircleAvatar(
                          backgroundColor: l.amount > 0 ? Colors.green.shade50 : Colors.red.shade50,
                          child: Icon(l.amount > 0 ? Icons.south_west : Icons.north_east,
                              color: l.amount > 0 ? Colors.green : Colors.red),
                        ),
                        title: Text(l.amount > 0 ? 'Đóng quỹ' : (l.memo ?? 'Chi hỗ trợ')),
                        subtitle: Text('${l.member ?? ''}  ·  ${dateTime(l.at)}'),
                        trailing: Text(
                          '${l.amount > 0 ? '+' : ''}${money(l.amount)}',
                          style: TextStyle(
                              fontWeight: FontWeight.w700,
                              color: l.amount > 0 ? Colors.green.shade700 : Colors.red.shade700),
                        ),
                      ),
                  ]),
          ),
        ]),
      ),
    );
  }

  Widget _line(String label, int v, Color c, {bool bold = false}) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(children: [
          Expanded(child: Text(label)),
          Text(money(v),
              style: TextStyle(color: c, fontWeight: bold ? FontWeight.w800 : FontWeight.w600, fontSize: bold ? 18 : 15)),
        ]),
      );
}
