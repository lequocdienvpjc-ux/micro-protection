import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/utils/formatters.dart';
import '../../../core/widgets/common.dart';
import '../data/group_repository.dart';
import '../domain/entities.dart';

/// Đóng quỹ: chọn số kỳ -> hiện mã VietQR + nội dung chuyển khoản.
/// Trưởng nhóm thấy tiền về sẽ bấm xác nhận, số dư quỹ cập nhật cho mọi người.
class ContributeScreen extends ConsumerStatefulWidget {
  const ContributeScreen({super.key, required this.group});
  final MyGroup group;
  @override
  ConsumerState<ContributeScreen> createState() => _ContributeScreenState();
}

class _ContributeScreenState extends ConsumerState<ContributeScreen> {
  int _periods = 1;
  ContributionTicket? _ticket;
  bool _loading = false;

  Future<void> _create() async {
    setState(() => _loading = true);
    try {
      final t = await ref
          .read(groupRepositoryProvider)
          .requestContribution(widget.group.id, _periods);
      setState(() => _ticket = t);
    } catch (e) {
      if (mounted) toast(context, e.toString(), error: true);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _copy(String label, String v) {
    Clipboard.setData(ClipboardData(text: v));
    toast(context, 'Đã sao chép $label');
  }

  @override
  Widget build(BuildContext context) {
    final g = widget.group;
    final t = _ticket;
    return Scaffold(
      appBar: AppBar(title: const Text('Đóng quỹ')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          if (t == null) ...[
            Text('Chọn số kỳ muốn đóng', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 12),
            Wrap(spacing: 8, runSpacing: 8, children: [
              for (final p in const [1, 2, 4, 8, 12])
                ChoiceChip(
                  label: Text('$p ${periodLabel[g.period]}'),
                  selected: _periods == p,
                  onSelected: (_) => setState(() => _periods = p),
                ),
            ]),
            const SizedBox(height: 24),
            Card(
              child: ListTile(
                title: const Text('Số tiền cần chuyển'),
                trailing: Text(money(g.contributionAmount * _periods),
                    style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'Phí vận hành nền tảng 5% được trích từ số tiền đóng, phần còn lại vào quỹ chung. '
              'Mọi khoản thu – chi đều hiển thị công khai cho cả nhóm.',
              style: TextStyle(color: Colors.black54),
            ),
            const SizedBox(height: 24),
            FilledButton(
              onPressed: _loading ? null : _create,
              child: _loading
                  ? const CircularProgressIndicator()
                  : const Text('Tạo mã chuyển khoản'),
            ),
          ] else ...[
            Center(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.network(
                  t.qrUrl,
                  width: 280,
                  errorBuilder: (_, __, ___) => const Padding(
                    padding: EdgeInsets.all(24),
                    child: Text('Không tải được mã QR, hãy chuyển khoản theo thông tin bên dưới.'),
                  ),
                  loadingBuilder: (c, w, p) =>
                      p == null ? w : const SizedBox(height: 280, child: Center(child: CircularProgressIndicator())),
                ),
              ),
            ),
            const SizedBox(height: 16),
            _Row('Ngân hàng', t.bankBin, onCopy: null),
            _Row('Số tài khoản', t.accountNo, onCopy: () => _copy('số tài khoản', t.accountNo)),
            _Row('Chủ tài khoản', t.accountName, onCopy: null),
            _Row('Số tiền', money(t.amount), onCopy: () => _copy('số tiền', '${t.amount}')),
            _Row('Nội dung CK', t.transferCode,
                highlight: true, onCopy: () => _copy('nội dung', t.transferCode)),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.amber.shade50,
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Text(
                'Quan trọng: ghi ĐÚNG nội dung chuyển khoản để Trưởng nhóm đối soát. '
                'Sau khi được xác nhận, khoản đóng sẽ xuất hiện trong sổ quỹ.',
              ),
            ),
            const SizedBox(height: 16),
            FilledButton(onPressed: () => Navigator.pop(context), child: const Text('Tôi đã chuyển khoản')),
          ],
        ],
      ),
    );
  }
}

class _Row extends StatelessWidget {
  const _Row(this.label, this.value, {this.onCopy, this.highlight = false});
  final String label, value;
  final VoidCallback? onCopy;
  final bool highlight;
  @override
  Widget build(BuildContext context) => ListTile(
        dense: true,
        title: Text(label, style: const TextStyle(color: Colors.black54)),
        subtitle: Text(value,
            style: TextStyle(
              fontSize: 17,
              fontWeight: FontWeight.w600,
              color: highlight ? Colors.deepOrange : Colors.black87,
            )),
        trailing: onCopy == null
            ? null
            : IconButton(icon: const Icon(Icons.copy), onPressed: onCopy),
      );
}
