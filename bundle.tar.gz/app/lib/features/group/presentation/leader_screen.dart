import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/utils/formatters.dart';
import '../../../core/widgets/common.dart';
import '../../claim/data/claim_repository.dart';
import '../data/group_repository.dart';
import '../domain/entities.dart';

/// Màn hình Trưởng nhóm: (1) xác nhận tiền đóng quỹ đã về, (2) xác nhận đã chi trả.
class LeaderScreen extends ConsumerWidget {
  const LeaderScreen({super.key, required this.group});
  final MyGroup group;

  void _refreshAll(WidgetRef ref) {
    ref.invalidate(pendingContributionsProvider(group.id));
    ref.invalidate(pendingPayoutsProvider(group.id));
    ref.invalidate(fundSummaryProvider(group.id));
    ref.invalidate(ledgerProvider(group.id));
    ref.invalidate(groupClaimsProvider(group.id));
    ref.invalidate(myGroupsProvider);
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final contribs = ref.watch(pendingContributionsProvider(group.id));
    final payouts = ref.watch(pendingPayoutsProvider(group.id));
    final repo = ref.read(groupRepositoryProvider);

    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: Text('Trưởng nhóm · ${group.name}'),
          bottom: const TabBar(tabs: [Tab(text: 'Duyệt đóng quỹ'), Tab(text: 'Chi trả hỗ trợ')]),
        ),
        body: TabBarView(children: [
          // ---- Tab 1: đóng quỹ chờ xác nhận ----
          RefreshIndicator(
            onRefresh: () async => _refreshAll(ref),
            child: AsyncView<List<PendingContribution>>(
              value: contribs,
              onRetry: () => _refreshAll(ref),
              data: (list) => ListView(children: [
                const Padding(
                  padding: EdgeInsets.all(16),
                  child: Text('Mở app ngân hàng, đối chiếu NỘI DUNG CK và số tiền, '
                      'sau đó bấm "Đã nhận".'),
                ),
                if (list.isEmpty) const EmptyHint('Không có khoản nào chờ xác nhận.'),
                for (final c in list)
                  Card(
                    margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                    child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(c.memberName, style: const TextStyle(fontWeight: FontWeight.w600)),
                        Text('${money(c.amount)} · ${c.periods} kỳ · ${dateTime(c.at)}'),
                        SelectableText('Nội dung: ${c.transferCode}',
                            style: const TextStyle(color: Colors.deepOrange, fontWeight: FontWeight.w600)),
                        const SizedBox(height: 8),
                        Row(children: [
                          Expanded(
                            child: OutlinedButton(
                              onPressed: () async {
                                if (await confirmDialog(context, 'Từ chối?',
                                        'Chỉ từ chối khi KHÔNG thấy tiền về.') &&
                                    context.mounted) {
                                  await runAction(context, () => repo.reviewContribution(c.requestId, false));
                                  _refreshAll(ref);
                                }
                              },
                              child: const Text('Không thấy tiền'),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: FilledButton(
                              onPressed: () async {
                                await runAction(context, () => repo.reviewContribution(c.requestId, true),
                                    success: 'Đã ghi nhận vào quỹ');
                                _refreshAll(ref);
                              },
                              child: const Text('Đã nhận'),
                            ),
                          ),
                        ]),
                      ]),
                    ),
                  ),
              ]),
            ),
          ),

          // ---- Tab 2: chi trả ----
          RefreshIndicator(
            onRefresh: () async => _refreshAll(ref),
            child: AsyncView<List<PendingPayout>>(
              value: payouts,
              onRetry: () => _refreshAll(ref),
              data: (list) => ListView(children: [
                const Padding(
                  padding: EdgeInsets.all(16),
                  child: Text('Các yêu cầu đã được cộng đồng duyệt. Chuyển khoản cho thành viên '
                      'từ tài khoản quỹ, rồi nhập mã giao dịch để hoàn tất.'),
                ),
                if (list.isEmpty) const EmptyHint('Không có khoản cần chi.'),
                for (final p in list) _PayoutCard(p: p, onDone: () => _refreshAll(ref)),
              ]),
            ),
          ),
        ]),
      ),
    );
  }
}

class _PayoutCard extends ConsumerWidget {
  const _PayoutCard({required this.p, required this.onDone});
  final PendingPayout p;
  final VoidCallback onDone;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final hasBank = (p.accountNo ?? '').isNotEmpty;
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Expanded(child: Text(p.memberName, style: const TextStyle(fontWeight: FontWeight.w600))),
            Text(money(p.amount), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
          ]),
          const SizedBox(height: 6),
          if (hasBank) ...[
            Text('${p.bank} · ${p.accountName}'),
            Row(children: [
              SelectableText(p.accountNo!, style: const TextStyle(fontWeight: FontWeight.w600)),
              IconButton(
                icon: const Icon(Icons.copy, size: 18),
                onPressed: () => Clipboard.setData(ClipboardData(text: p.accountNo!)),
              ),
            ]),
          ] else
            const Text('Thành viên chưa khai báo tài khoản nhận tiền.',
                style: TextStyle(color: Colors.red)),
          if (p.openFlags > 0)
            Text('⚠ Đang có ${p.openFlags} báo cáo nghi vấn — chờ Admin xử lý.',
                style: const TextStyle(color: Colors.purple)),
          const SizedBox(height: 8),
          FilledButton(
            onPressed: (!hasBank || p.openFlags > 0)
                ? null
                : () async {
                    final ref0 = await _askBankRef(context);
                    if (ref0 == null || !context.mounted) return;
                    await runAction(
                        context, () => ref.read(groupRepositoryProvider).confirmDisbursement(p.claimId, ref0),
                        success: 'Đã ghi nhận chi trả');
                    onDone();
                  },
            child: const Text('Đã chuyển khoản'),
          ),
        ]),
      ),
    );
  }

  Future<String?> _askBankRef(BuildContext context) {
    final c = TextEditingController();
    return showDialog<String>(
      context: context,
      builder: (d) => AlertDialog(
        title: const Text('Mã giao dịch ngân hàng'),
        content: TextField(
          controller: c,
          autofocus: true,
          decoration: const InputDecoration(hintText: 'Ví dụ: FT26110612345'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(d), child: const Text('Huỷ')),
          FilledButton(onPressed: () => Navigator.pop(d, c.text.trim()), child: const Text('Xác nhận')),
        ],
      ),
    );
  }
}
