import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../../core/error/failure.dart';
import '../../auth/presentation/providers/auth_providers.dart';
import '../domain/entities.dart';

/// Tất cả lời gọi RPC liên quan tới nhóm & quỹ.
class GroupRepository {
  GroupRepository(this._db);
  final SupabaseClient _db;

  Future<dynamic> _rpc(String fn, [Map<String, dynamic>? params]) async {
    try {
      return await _db.rpc(fn, params: params);
    } catch (e) {
      throw Failure.from(e);
    }
  }

  List<Map<String, dynamic>> _rows(dynamic r) => (r as List).cast<Map<String, dynamic>>();

  Future<List<MyGroup>> myGroups() async =>
      _rows(await _rpc('get_my_groups')).map(MyGroup.fromJson).toList();

  Future<List<OpenGroup>> openGroups() async =>
      _rows(await _rpc('list_open_groups')).map(OpenGroup.fromJson).toList();

  Future<void> join(String groupId) => _rpc('join_group', {'p_group': groupId});

  Future<FundSummary> summary(String groupId) async =>
      FundSummary.fromJson(_rows(await _rpc('get_group_fund_summary', {'p_group': groupId})).first);

  Future<List<LedgerLine>> ledger(String groupId) async =>
      _rows(await _rpc('get_group_ledger', {'p_group': groupId, 'p_limit': 100}))
          .map(LedgerLine.fromJson)
          .toList();

  Future<ContributionTicket> requestContribution(String groupId, int periods) async =>
      ContributionTicket.fromJson(_rows(await _rpc(
              'request_contribution', {'p_group': groupId, 'p_periods': periods}))
          .first);

  Future<List<PendingContribution>> pendingContributions(String groupId) async =>
      _rows(await _rpc('list_pending_contributions', {'p_group': groupId}))
          .map(PendingContribution.fromJson)
          .toList();

  Future<void> reviewContribution(String requestId, bool approve) =>
      _rpc('review_contribution', {'p_request': requestId, 'p_approve': approve});

  Future<List<PendingPayout>> pendingPayouts(String groupId) async =>
      _rows(await _rpc('list_pending_payouts', {'p_group': groupId}))
          .map(PendingPayout.fromJson)
          .toList();

  Future<void> confirmDisbursement(String claimId, String bankRef) =>
      _rpc('confirm_disbursement', {'p_claim': claimId, 'p_bank_ref': bankRef});

  Future<void> updatePayoutAccount(String bank, String no, String name) => _rpc(
      'update_payout_account', {'p_bank': bank, 'p_account_no': no, 'p_account_name': name});
}

final groupRepositoryProvider =
    Provider((ref) => GroupRepository(ref.watch(supabaseClientProvider)));

final myGroupsProvider = FutureProvider.autoDispose<List<MyGroup>>(
    (ref) => ref.watch(groupRepositoryProvider).myGroups());

final openGroupsProvider = FutureProvider.autoDispose<List<OpenGroup>>(
    (ref) => ref.watch(groupRepositoryProvider).openGroups());

/// Nhóm đang chọn ở Trang chủ (null = nhóm đầu tiên).
final selectedGroupIdProvider = StateProvider<String?>((_) => null);

final fundSummaryProvider = FutureProvider.autoDispose.family<FundSummary, String>(
    (ref, id) => ref.watch(groupRepositoryProvider).summary(id));

final ledgerProvider = FutureProvider.autoDispose.family<List<LedgerLine>, String>(
    (ref, id) => ref.watch(groupRepositoryProvider).ledger(id));

final pendingContributionsProvider =
    FutureProvider.autoDispose.family<List<PendingContribution>, String>(
        (ref, id) => ref.watch(groupRepositoryProvider).pendingContributions(id));

final pendingPayoutsProvider = FutureProvider.autoDispose.family<List<PendingPayout>, String>(
    (ref, id) => ref.watch(groupRepositoryProvider).pendingPayouts(id));
