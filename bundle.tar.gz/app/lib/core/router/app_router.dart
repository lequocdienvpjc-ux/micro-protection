import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../features/auth/domain/entities/app_user.dart';
import '../../features/auth/presentation/providers/auth_providers.dart';
import '../../features/auth/presentation/screens/email_auth_screen.dart';
import '../../features/auth/presentation/screens/kyc_pending_screen.dart';
import '../../features/auth/presentation/screens/kyc_screen.dart';
import '../../features/auth/presentation/screens/login_screen.dart';
import '../../features/auth/presentation/screens/otp_screen.dart';
import '../../features/auth/presentation/screens/splash_screen.dart';
import '../../features/home/home_screen.dart';

abstract final class Routes {
  static const splash = '/splash';
  static const login = '/login';
  static const phone = '/login/phone';
  static const otp = '/login/phone/otp';
  static const kyc = '/kyc';
  static const kycPending = '/kyc/pending';
  static const home = '/home';
}

/// Báo cho GoRouter chạy lại `redirect` mỗi khi phiên/hồ sơ thay đổi.
class _RouterRefresh extends ChangeNotifier {
  _RouterRefresh(Ref ref) {
    ref.listen(signedInProvider, (_, __) => notifyListeners());
    ref.listen(currentUserProvider, (_, __) => notifyListeners());
  }
}

final appRouterProvider = Provider<GoRouter>((ref) {
  final refresh = _RouterRefresh(ref);
  ref.onDispose(refresh.dispose);

  return GoRouter(
    initialLocation: Routes.splash,
    refreshListenable: refresh,
    redirect: (context, state) {
      final loc = state.matchedLocation;
      final inAuthFlow = loc.startsWith(Routes.login);

      final signedIn = ref.read(signedInProvider);
      if (signedIn.isLoading) return Routes.splash;

      // 1) Chưa đăng nhập -> chỉ được ở luồng login
      if (signedIn.valueOrNull != true) return inAuthFlow ? null : Routes.login;

      // 2) Đã đăng nhập, đang tải hồ sơ
      final user = ref.read(currentUserProvider);
      if (user.isLoading && !user.hasValue) return Routes.splash;
      if (user.hasError) return Routes.splash; // splash hiển thị nút thử lại

      // 3) Điều hướng theo trạng thái KYC
      final u = user.valueOrNull;
      if (u == null) return Routes.splash;
      final target = switch (u.kycStatus) {
        KycStatus.none || KycStatus.rejected => Routes.kyc,
        KycStatus.pending => Routes.kycPending,
        KycStatus.verified => null,
      };
      if (target != null) return loc == target ? null : target;

      // 4) Đã xác minh: không quay lại login/kyc/splash
      if (inAuthFlow || loc.startsWith(Routes.kyc) || loc == Routes.splash) {
        return Routes.home;
      }
      return null;
    },
    routes: [
      GoRoute(path: Routes.splash, builder: (_, __) => const SplashScreen()),
      GoRoute(
        path: Routes.login,
        builder: (_, __) => const EmailAuthScreen(),
        routes: [
          GoRoute(
            path: 'phone',
            builder: (_, __) => const LoginScreen(),
            routes: [
              GoRoute(
                path: 'otp',
                builder: (_, s) => OtpScreen(phoneE164: s.extra as String? ?? ''),
              ),
            ],
          ),
        ],
      ),
      GoRoute(path: Routes.kyc, builder: (_, __) => const KycScreen()),
      GoRoute(path: Routes.kycPending, builder: (_, __) => const KycPendingScreen()),
      GoRoute(path: Routes.home, builder: (_, __) => const HomeScreen()),
    ],
    debugLogDiagnostics: kDebugMode,
  );
});
