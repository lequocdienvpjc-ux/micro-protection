import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

/// Lưu phiên đăng nhập (access + refresh token) vào Keychain (iOS) /
/// EncryptedSharedPreferences (Android) thay vì SharedPreferences dạng rõ.
/// supabase_flutter sẽ tự refresh token và khôi phục phiên khi mở lại app.
class SecureLocalStorage extends LocalStorage {
  SecureLocalStorage();

  static const _key = 'mpn_supabase_session';
  final _storage = const FlutterSecureStorage(
    aOptions: AndroidOptions(encryptedSharedPreferences: true),
    iOptions: IOSOptions(accessibility: KeychainAccessibility.first_unlock),
  );

  @override
  Future<void> initialize() async {}

  @override
  Future<bool> hasAccessToken() => _storage.containsKey(key: _key);

  @override
  Future<String?> accessToken() => _storage.read(key: _key);

  @override
  Future<void> persistSession(String persistSessionString) =>
      _storage.write(key: _key, value: persistSessionString);

  @override
  Future<void> removePersistedSession() => _storage.delete(key: _key);
}
