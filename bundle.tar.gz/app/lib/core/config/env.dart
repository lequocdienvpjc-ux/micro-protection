/// Cấu hình kết nối Supabase.
/// URL và anon key là thông tin CÔNG KHAI theo thiết kế của Supabase (dữ liệu được
/// bảo vệ bằng RLS), nên có thể nhúng vào app. Có thể ghi đè khi build:
///   flutter build apk --dart-define=SUPABASE_URL=... --dart-define=SUPABASE_ANON_KEY=...
/// TUYỆT ĐỐI không đưa service_role key vào app.
class Env {
  static const supabaseUrl = String.fromEnvironment(
    'SUPABASE_URL',
    defaultValue: 'https://tnchzmdmskbepnszycvh.supabase.co',
  );
  static const supabaseAnonKey = String.fromEnvironment(
    'SUPABASE_ANON_KEY',
    defaultValue:
        'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRuY2h6bWRtc2tiZXBuc3p5Y3ZoIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTM5MzE2MTgsImV4cCI6MjEwOTUwNzYxOH0.g4Dnqo_4VU81NHJ2afAgl48PR38llmVSPFzuPM4tqDo',
  );

  static void assertConfigured() {
    if (supabaseUrl.startsWith('__') || supabaseAnonKey.startsWith('__')) {
      throw StateError('Chưa cấu hình SUPABASE_URL / SUPABASE_ANON_KEY trong env.dart.');
    }
  }
}
