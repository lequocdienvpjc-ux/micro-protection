import 'package:supabase_flutter/supabase_flutter.dart';

/// Lỗi nghiệp vụ hiển thị được cho người dùng (tiếng Việt).
class Failure implements Exception {
  const Failure(this.message, {this.code});
  final String message;
  final String? code;

  @override
  String toString() => message;

  /// Chuyển mọi lỗi từ Supabase/Postgres về thông điệp dễ hiểu.
  factory Failure.from(Object error) {
    if (error is Failure) return error;

    if (error is AuthException) {
      final m = error.message.toLowerCase();
      if (m.contains('invalid login credentials')) {
        return const Failure('Email hoặc mật khẩu không đúng.');
      }
      if (m.contains('token has expired') || m.contains('otp')) {
        return const Failure('Mã OTP không đúng hoặc đã hết hạn.');
      }
      if (m.contains('already registered')) {
        return const Failure('Email này đã được đăng ký.');
      }
      if (m.contains('rate limit') || error.statusCode == '429') {
        return const Failure('Bạn thao tác quá nhanh, vui lòng thử lại sau ít phút.');
      }
      return Failure(error.message);
    }

    if (error is PostgrestException) {
      // Các mã lỗi do hàm SQL raise exception
      const known = {
        'INVALID_NATIONAL_ID': 'Số CCCD phải gồm đúng 12 chữ số.',
        'INVALID_NAME': 'Vui lòng nhập họ tên đầy đủ.',
        'CONSENT_REQUIRED': 'Bạn cần đồng ý điều khoản xử lý dữ liệu cá nhân.',
        'NATIONAL_ID_ALREADY_USED': 'Số CCCD này đã được dùng cho tài khoản khác.',
        'KYC_ALREADY_SUBMITTED': 'Hồ sơ đã được gửi, vui lòng chờ duyệt.',
        'KYC_NOT_VERIFIED': 'Tài khoản chưa được xác minh danh tính.',
        'MEMBER_SUSPENDED': 'Tài khoản của bạn đang bị tạm khóa trong nhóm này.',
        'GROUP_CLOSED': 'Nhóm đã ngừng nhận thành viên.',
        'FORBIDDEN': 'Bạn không có quyền thực hiện thao tác này.',
        'NOT_ACTIVE_MEMBER': 'Bạn chưa là thành viên của nhóm này.',
        'GROUP_BANK_NOT_SET': 'Nhóm chưa có tài khoản ngân hàng nhận quỹ.',
        'WAITING_PERIOD': 'Bạn chưa hết thời gian chờ sau khi gia nhập nhóm.',
        'AMOUNT_OVER_LIMIT': 'Số tiền vượt mức hỗ trợ tối đa của nhóm.',
        'INCIDENT_DATE_INVALID': 'Thời điểm sự cố phải trong vòng 7 ngày gần đây.',
        'CONTRIBUTION_NOT_CURRENT': 'Bạn cần đóng quỹ đủ kỳ gần nhất trước khi yêu cầu hỗ trợ.',
        'GROUP_TOO_SMALL': 'Nhóm chưa đủ số thành viên tối thiểu để xét hỗ trợ.',
        'PHOTO_REQUIRED': 'Cần ít nhất 1 ảnh chụp hiện trường.',
        'MEDIA_REUSED': 'Ảnh/video này đã từng được dùng. Hãy chụp ảnh mới.',
        'MEDIA_TOO_OLD': 'Ảnh đã chụp quá lâu. Vui lòng chụp lại.',
        'TOO_MANY_MEDIA': 'Tối đa 6 ảnh/video cho một yêu cầu.',
        'NOT_ENOUGH_VOTERS': 'Nhóm chưa đủ thành viên đã xác minh để thẩm định.',
        'VOTING_CLOSED': 'Yêu cầu này đã kết thúc thẩm định.',
        'NOT_ASSIGNED_VOTER': 'Bạn không được giao thẩm định yêu cầu này.',
        'ALREADY_VOTED': 'Bạn đã bỏ phiếu rồi.',
        'VOTE_EXPIRED': 'Đã hết hạn bỏ phiếu.',
        'REJECT_REASON_REQUIRED': 'Vui lòng ghi lý do không đồng ý.',
        'CANNOT_FLAG_OWN': 'Không thể báo cáo yêu cầu của chính mình.',
        'CLAIM_HAS_OPEN_FLAGS': 'Yêu cầu đang bị báo gian lận, chờ Admin xử lý.',
        'BANK_REF_REQUIRED': 'Nhập mã giao dịch chuyển khoản.',
        'INVALID_BANK_ACCOUNT': 'Thông tin tài khoản ngân hàng không hợp lệ.',
        'ALREADY_REVIEWED': 'Yêu cầu này đã được xử lý.',
        'USER_NOT_FOUND': 'Không tìm thấy người dùng với SĐT/email này.',
        'INVALID_STATE': 'Trạng thái hiện tại không cho phép thao tác này.',
      };
      for (final e in known.entries) {
        if (error.message.contains(e.key)) return Failure(e.value, code: e.key);
      }
      return Failure('Có lỗi từ máy chủ: ${error.message}');
    }

    if (error is StorageException) return Failure('Lỗi tải tệp: ${error.message}');
    if (error is String) return Failure(error);
    return const Failure('Không có kết nối mạng hoặc lỗi không xác định.');
  }
}
