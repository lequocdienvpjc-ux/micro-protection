/// Kiểm tra & chuẩn hóa dữ liệu nhập.
class Validators {
  static final _vnMobile = RegExp(r'^(0|\+?84)(3|5|7|8|9)\d{8}$');
  static final _email = RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$');
  static final _cccd = RegExp(r'^\d{12}$');

  /// "0901 234 567" -> "+84901234567" (định dạng E.164 Supabase yêu cầu)
  static String normalizeVnPhone(String input) {
    final digits = input.replaceAll(RegExp(r'[\s\-\.]'), '');
    if (digits.startsWith('+84')) return digits;
    if (digits.startsWith('84')) return '+$digits';
    if (digits.startsWith('0')) return '+84${digits.substring(1)}';
    return digits;
  }

  static String? phone(String? v) {
    final s = (v ?? '').replaceAll(RegExp(r'[\s\-\.]'), '');
    if (s.isEmpty) return 'Vui lòng nhập số điện thoại';
    if (!_vnMobile.hasMatch(s)) return 'Số điện thoại không hợp lệ';
    return null;
  }

  static String? email(String? v) {
    if ((v ?? '').trim().isEmpty) return 'Vui lòng nhập email';
    if (!_email.hasMatch(v!.trim())) return 'Email không hợp lệ';
    return null;
  }

  static String? password(String? v) {
    if ((v ?? '').length < 8) return 'Mật khẩu tối thiểu 8 ký tự';
    return null;
  }

  static String? otp(String? v) {
    if (!RegExp(r'^\d{6}$').hasMatch(v ?? '')) return 'Mã OTP gồm 6 chữ số';
    return null;
  }

  static String? fullName(String? v) {
    final s = (v ?? '').trim();
    if (s.length < 2 || !s.contains(' ')) return 'Nhập đầy đủ họ và tên';
    return null;
  }

  static String? nationalId(String? v) {
    if (!_cccd.hasMatch((v ?? '').trim())) return 'Số CCCD gồm 12 chữ số';
    return null;
  }
}
