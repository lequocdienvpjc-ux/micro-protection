import 'package:intl/intl.dart';

final _vnd = NumberFormat.decimalPattern('vi');
final _dt = DateFormat('dd/MM/yyyy HH:mm');
final _d = DateFormat('dd/MM/yyyy');

String money(num v) => '${_vnd.format(v)} đ';
String dateTime(DateTime v) => _dt.format(v.toLocal());
String dateOnly(DateTime v) => _d.format(v.toLocal());

int asInt(dynamic v) => v is int ? v : (v is num ? v.toInt() : int.parse('$v'));
DateTime asDate(dynamic v) => DateTime.parse(v as String);

const periodLabel = {'daily': 'ngày', 'weekly': 'tuần', 'monthly': 'tháng'};

const incidentTypes = <String, String>{
  'accident': 'Tai nạn giao thông',
  'vehicle_damage': 'Hư hỏng xe / phương tiện',
  'theft': 'Mất cắp tài sản, hàng hóa',
  'illness': 'Ốm đau, nằm viện',
  'other': 'Rủi ro khác',
};

const claimStatusLabel = {
  'draft': 'Nháp',
  'voting': 'Đang thẩm định',
  'approved': 'Đã duyệt – chờ chuyển tiền',
  'paid': 'Đã chi trả',
  'rejected': 'Không được duyệt',
  'expired': 'Hết hạn',
  'under_review': 'Đang kiểm tra (nghi vấn)',
  'cancelled': 'Đã huỷ',
};

const riskTypeLabel = {
  'moto_driver': 'Tài xế xe máy',
  'car_driver': 'Tài xế ô tô',
  'lottery_vendor': 'Bán vé số',
  'street_vendor': 'Bán hàng rong',
  'grocery': 'Tiệm tạp hóa',
  'construction': 'Lao động tự do',
  'other': 'Khác',
};
