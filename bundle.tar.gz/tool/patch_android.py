"""Chỉnh cấu hình Android sau khi `flutter create` sinh thư mục android/."""
import pathlib, re, sys

app = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else "app")
manifest = app / "android/app/src/main/AndroidManifest.xml"
m = manifest.read_text(encoding="utf-8")

# Quyền: Internet (bản release mặc định KHÔNG có), vị trí GPS.
# KHÔNG khai báo CAMERA: image_picker dùng app Camera hệ thống; nếu khai báo mà
# chưa cấp quyền runtime thì Android sẽ chặn intent chụp ảnh.
perms = [
    "android.permission.INTERNET",
    "android.permission.ACCESS_FINE_LOCATION",
    "android.permission.ACCESS_COARSE_LOCATION",
]
for p in perms:
    if p not in m:
        m = m.replace("<application", f'<uses-permission android:name="{p}"/>\n    <application', 1)

# Tên hiển thị
m = re.sub(r'android:label="[^"]*"', 'android:label="Tương trợ"', m, count=1)

# Cho url_launcher mở bản đồ / video (Android 11+ cần khai báo queries)
view_intent = ('<intent><action android:name="android.intent.action.VIEW"/>'
               '<data android:scheme="https"/></intent>')
if "android.intent.action.VIEW" not in m:
    if "<queries>" in m:
        m = m.replace("<queries>", "<queries>\n        " + view_intent, 1)
    else:
        m = m.replace("</manifest>", f"    <queries>{view_intent}</queries>\n</manifest>")
manifest.write_text(m, encoding="utf-8")

# minSdk 23
for name in ("build.gradle.kts", "build.gradle"):
    g = app / "android/app" / name
    if g.exists():
        s = g.read_text(encoding="utf-8")
        s = s.replace("minSdk = flutter.minSdkVersion", "minSdk = 23")
        s = s.replace("minSdkVersion flutter.minSdkVersion", "minSdkVersion 23")
        g.write_text(s, encoding="utf-8")
        print("patched", g)
print("patched", manifest)
