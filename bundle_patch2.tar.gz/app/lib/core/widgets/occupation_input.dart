import 'package:flutter/material.dart';

import '../data/occupation_suggestions.dart';
import '../theme/app_theme.dart';

/// Ô nhập ngành nghề TỰ DO dạng thẻ (tag):
///  - Gõ nghề bất kỳ rồi bấm "Thêm" / Enter (không bắt buộc chọn gợi ý)
///  - Gợi ý tự động khi gõ (không phân biệt dấu), hoặc chọn theo nhóm nghề
///  - Bấm vào thẻ để sửa, bấm × để xoá. Tối đa 8 nghề.
class OccupationInput extends StatefulWidget {
  const OccupationInput({
    super.key,
    required this.initial,
    required this.onChanged,
    this.max = 8,
  });

  final List<String> initial;
  final ValueChanged<List<String>> onChanged;
  final int max;

  @override
  State<OccupationInput> createState() => _OccupationInputState();
}

class _OccupationInputState extends State<OccupationInput> {
  late List<String> _items = [...widget.initial];
  TextEditingController? _ctrl;
  FocusNode? _focus;
  String? _error;

  String _clean(String s) => s.trim().replaceAll(RegExp(r'\s+'), ' ');

  bool _add(String raw) {
    final v = _clean(raw);
    if (v.isEmpty) return false;
    if (v.length < 2 || v.length > 60) {
      setState(() => _error = 'Mỗi ngành nghề từ 2 đến 60 ký tự');
      return false;
    }
    if (_items.any((e) => vnNorm(e) == vnNorm(v))) {
      setState(() => _error = '"$v" đã có trong danh sách');
      return false;
    }
    if (_items.length >= widget.max) {
      setState(() => _error = 'Tối đa ${widget.max} ngành nghề');
      return false;
    }
    setState(() {
      _items.add(v);
      _error = null;
    });
    widget.onChanged(List.unmodifiable(_items));
    return true;
  }

  void _remove(int i) {
    setState(() => _items.removeAt(i));
    widget.onChanged(List.unmodifiable(_items));
  }

  Future<void> _edit(int i) async {
    final c = TextEditingController(text: _items[i]);
    final v = await showDialog<String>(
      context: context,
      builder: (d) => AlertDialog(
        title: const Text('Sửa ngành nghề'),
        content: TextField(controller: c, autofocus: true, maxLength: 60),
        actions: [
          TextButton(onPressed: () => Navigator.pop(d), child: const Text('Huỷ')),
          FilledButton(onPressed: () => Navigator.pop(d, c.text), child: const Text('Lưu')),
        ],
      ),
    );
    if (v == null) return;
    final cleaned = _clean(v);
    if (cleaned.length < 2 || cleaned.length > 60) {
      setState(() => _error = 'Mỗi ngành nghề từ 2 đến 60 ký tự');
      return;
    }
    if (_items.asMap().entries.any((e) => e.key != i && vnNorm(e.value) == vnNorm(cleaned))) {
      setState(() => _error = '"$cleaned" đã có trong danh sách');
      return;
    }
    setState(() {
      _items[i] = cleaned;
      _error = null;
    });
    widget.onChanged(List.unmodifiable(_items));
  }

  Future<void> _browseGroups() async {
    final picked = await showModalBottomSheet<String>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (sheet) => DraggableScrollableSheet(
        expand: false,
        initialChildSize: 0.75,
        builder: (_, scroll) => ListView(
          controller: scroll,
          children: [
            const Padding(
              padding: EdgeInsets.fromLTRB(16, 0, 16, 8),
              child: Text('Chọn nhanh theo nhóm nghề (không bắt buộc)',
                  style: TextStyle(fontWeight: FontWeight.w700, color: Brand.navy)),
            ),
            for (final g in occupationGroups.entries)
              ExpansionTile(
                title: Text(g.key),
                children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
                    child: Wrap(spacing: 6, runSpacing: 6, children: [
                      for (final o in g.value)
                        ActionChip(label: Text(o), onPressed: () => Navigator.pop(sheet, o)),
                    ]),
                  ),
                ],
              ),
          ],
        ),
      ),
    );
    if (picked != null) _add(picked);
  }

  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      if (_items.isNotEmpty)
        Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: Wrap(spacing: 6, runSpacing: 6, children: [
            for (var i = 0; i < _items.length; i++)
              InputChip(
                label: Text(_items[i]),
                backgroundColor: Brand.blue.withOpacity(0.08),
                side: const BorderSide(color: Brand.blue),
                onPressed: () => _edit(i),
                onDeleted: () => _remove(i),
                deleteButtonTooltipMessage: 'Xoá',
              ),
          ]),
        ),
      Autocomplete<String>(
        optionsBuilder: (v) {
          final q = vnNorm(v.text);
          if (q.length < 2) return const Iterable<String>.empty();
          return allOccupationSuggestions
              .where((o) => vnNorm(o).contains(q) && !_items.contains(o))
              .take(12);
        },
        onSelected: (o) {
          _add(o);
          _ctrl?.clear();
        },
        fieldViewBuilder: (context, controller, focus, onSubmit) {
          _ctrl = controller;
          _focus = focus;
          return TextField(
            controller: controller,
            focusNode: focus,
            textCapitalization: TextCapitalization.sentences,
            maxLength: 60,
            decoration: InputDecoration(
              labelText: _items.isEmpty ? 'Ngành nghề của bạn' : 'Thêm ngành nghề khác (nếu có)',
              hintText: 'Gõ nghề của bạn, ví dụ: công nhân ép nhựa',
              prefixIcon: const Icon(Icons.work_outline),
              counterText: '',
              errorText: _error,
              suffixIcon: IconButton(
                tooltip: 'Thêm',
                icon: const Icon(Icons.add_circle, color: Brand.blue),
                onPressed: () {
                  if (_add(controller.text)) controller.clear();
                  _focus?.requestFocus();
                },
              ),
            ),
            onSubmitted: (v) {
              if (_add(v)) controller.clear();
              _focus?.requestFocus();
            },
          );
        },
      ),
      const SizedBox(height: 4),
      Row(children: [
        const Expanded(
          child: Text('Nghề chưa có trong gợi ý vẫn nhập được bình thường.',
              style: TextStyle(fontSize: 12, color: Colors.black54)),
        ),
        TextButton.icon(
          onPressed: _browseGroups,
          icon: const Icon(Icons.list_alt, size: 18),
          label: const Text('Xem gợi ý'),
        ),
      ]),
    ]);
  }
}
