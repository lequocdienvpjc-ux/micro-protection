/// Danh sách GỢI Ý ngành nghề phổ biến tại Việt Nam — chỉ để nhập nhanh.
/// Người dùng KHÔNG bắt buộc chọn trong danh sách; nghề nào cũng nhập & lưu được.
const occupationGroups = <String, List<String>>{
  'Công nhân sản xuất, nhà máy': [
    'Công nhân sản xuất', 'Công nhân nhà máy', 'Công nhân khu công nghiệp', 'Công nhân lắp ráp',
    'Công nhân đóng gói', 'Công nhân kho', 'Thủ kho', 'Công nhân vận hành máy', 'Tổ trưởng sản xuất',
    'Trưởng ca sản xuất', 'Nhân viên QC / kiểm tra chất lượng', 'Công nhân bốc xếp', 'Lái xe nâng',
    'Công nhân in ấn, bao bì', 'Công nhân giấy, carton',
  ],
  'Nhựa, khuôn mẫu, cơ khí, CNC': [
    'Công nhân ép nhựa', 'Kỹ thuật viên ép nhựa', 'Thợ làm khuôn mẫu', 'Thợ sửa khuôn', 'Thợ thổi nhựa',
    'Công nhân đùn ống nhựa', 'Thợ cơ khí', 'Thợ tiện', 'Thợ phay', 'Thợ mài', 'Thợ hàn', 'Thợ gò',
    'Thợ CNC', 'Lập trình CNC', 'Thợ cắt laser', 'Thợ đột dập', 'Thợ sơn tĩnh điện', 'Thợ xi mạ',
    'Kỹ sư cơ khí', 'Thiết kế khuôn (CAD/CAM)',
  ],
  'Điện, điện tử, điện lạnh, tự động hóa': [
    'Thợ điện', 'Thợ điện công nghiệp', 'Thợ điện dân dụng', 'Thợ điện lạnh', 'Thợ sửa máy lạnh, tủ lạnh',
    'Kỹ thuật viên điện tử', 'Công nhân điện tử', 'Kỹ thuật viên tự động hóa', 'Lập trình PLC',
    'Kỹ sư điện', 'Thợ lắp đặt năng lượng mặt trời', 'Thợ lắp camera an ninh', 'Thợ bảo trì máy móc',
  ],
  'May mặc, giày da, dệt nhuộm': [
    'Công nhân may', 'Thợ may', 'Thợ may đo', 'Thợ cắt vải', 'Công nhân ủi, đóng gói hàng may',
    'Công nhân giày da', 'Thợ đóng giày', 'Công nhân dệt', 'Công nhân nhuộm', 'Công nhân thêu',
    'Thợ sửa quần áo', 'Thiết kế thời trang', 'Nhân viên kỹ thuật chuyền may', 'Phụ liệu may mặc',
  ],
  'Thực phẩm, chế biến, nông nghiệp, thủy sản': [
    'Công nhân chế biến thực phẩm', 'Công nhân chế biến thủy sản', 'Công nhân đông lạnh',
    'Thợ làm bánh', 'Thợ nấu ăn', 'Công nhân nhà máy bia, nước giải khát', 'Công nhân chế biến gỗ',
    'Ngư dân', 'Nuôi trồng thủy sản', 'Nuôi tôm', 'Nuôi cá', 'Kỹ sư nông nghiệp',
    'Lò mổ, giết mổ gia súc', 'Sơ chế rau củ',
  ],
  'Xây dựng, kiến trúc, nội thất': [
    'Thợ xây', 'Thợ hồ', 'Phụ hồ', 'Thợ sơn nước', 'Thợ ốp lát', 'Thợ trần thạch cao', 'Thợ cốp pha',
    'Thợ sắt', 'Thợ mộc', 'Thợ làm nhôm kính', 'Thợ điện nước', 'Thợ chống thấm', 'Thợ làm mái tôn',
    'Kỹ sư xây dựng', 'Kiến trúc sư', 'Giám sát công trình', 'Thiết kế nội thất', 'Thợ đóng đồ nội thất',
    'Bán vật liệu xây dựng', 'Lái máy xúc, máy ủi', 'Lái xe cẩu',
  ],
  'Vận tải, tài xế, giao hàng': [
    'Tài xế xe máy / xe ôm công nghệ', 'Xe ôm truyền thống', 'Tài xế ô tô', 'Tài xế taxi',
    'Tài xế xe công nghệ (Grab, Be, Xanh SM...)', 'Tài xế xe tải', 'Tài xế container', 'Tài xế xe khách',
    'Tài xế xe buýt', 'Phụ xe', 'Shipper / giao hàng', 'Giao đồ ăn', 'Giao hàng thương mại điện tử',
    'Xe ba gác, chở hàng thuê', 'Bốc xếp hàng hóa', 'Điều phối vận tải', 'Lái tàu, thuyền',
  ],
  'Kinh doanh, buôn bán, bán hàng online': [
    'Kinh doanh tự do', 'Buôn bán nhỏ', 'Bán hàng online', 'Bán hàng livestream', 'Bán hàng chợ',
    'Tiểu thương chợ', 'Bán hàng rong', 'Bán trái cây', 'Bán quần áo', 'Bán đồ ăn vặt',
    'Nhân viên bán hàng', 'Nhân viên kinh doanh', 'Đại lý phân phối', 'Bán hàng siêu thị',
    'Thu ngân', 'Nhân viên cửa hàng tiện lợi', 'Cộng tác viên bán hàng',
  ],
  'Chủ cửa hàng, quán ăn, cà phê': [
    'Chủ tiệm tạp hóa / kinh doanh nhỏ', 'Chủ quán ăn', 'Chủ quán cà phê', 'Chủ quán nhậu',
    'Bán cơm, phở, bún', 'Bán bánh mì', 'Bán xôi, chè', 'Bán nước giải khát', 'Bán trà sữa',
    'Chủ tiệm điện thoại', 'Chủ tiệm thuốc tây', 'Chủ tiệm vật tư', 'Chủ cửa hàng quần áo',
    'Nhân viên phục vụ quán', 'Pha chế (barista, bartender)',
  ],
  'Nhà hàng, khách sạn, du lịch': [
    'Đầu bếp', 'Phụ bếp', 'Nhân viên phục vụ nhà hàng', 'Lễ tân khách sạn', 'Buồng phòng khách sạn',
    'Hướng dẫn viên du lịch', 'Nhân viên đặt tour', 'Bảo vệ khách sạn', 'Quản lý nhà hàng',
    'Chủ homestay, nhà nghỉ', 'Nhân viên tiệc cưới, sự kiện',
  ],
  'Giáo dục, đào tạo': [
    'Giáo viên mầm non', 'Giáo viên tiểu học', 'Giáo viên THCS, THPT', 'Giảng viên', 'Gia sư',
    'Giáo viên tiếng Anh', 'Giáo viên dạy nghề', 'Bảo mẫu', 'Huấn luyện viên thể thao',
    'Giáo viên năng khiếu (đàn, vẽ, múa)', 'Nhân viên trung tâm đào tạo',
  ],
  'Y tế, chăm sóc sức khỏe': [
    'Bác sĩ', 'Điều dưỡng', 'Y tá', 'Hộ lý', 'Dược sĩ', 'Nhân viên nhà thuốc', 'Kỹ thuật viên xét nghiệm',
    'Kỹ thuật viên vật lý trị liệu', 'Chăm sóc người cao tuổi', 'Chăm sóc người bệnh', 'Y học cổ truyền',
    'Nha sĩ / phụ tá nha khoa', 'Nhân viên y tế cơ sở',
  ],
  'Công nghệ thông tin, thiết kế, marketing': [
    'Lập trình viên', 'Kỹ sư phần mềm', 'Kiểm thử phần mềm', 'Quản trị mạng', 'Kỹ thuật viên IT',
    'Thiết kế đồ họa', 'Thiết kế UI/UX', 'Dựng phim, chỉnh sửa video', 'Marketing online',
    'Chạy quảng cáo Facebook, Google', 'Quản trị fanpage', 'Viết nội dung (content)', 'SEO website',
    'Phân tích dữ liệu', 'Freelancer công nghệ',
  ],
  'Văn phòng, kế toán, nhân sự': [
    'Nhân viên văn phòng', 'Kế toán', 'Thủ quỹ', 'Nhân viên nhân sự', 'Nhân viên hành chính',
    'Thư ký, trợ lý', 'Nhân viên chăm sóc khách hàng', 'Tổng đài viên', 'Nhân viên mua hàng',
    'Nhân viên xuất nhập khẩu', 'Nhân viên ngân hàng', 'Nhân viên bảo hiểm', 'Nhân viên nhập liệu',
    'Cán bộ, công chức', 'Nhân viên pháp chế',
  ],
  'Bất động sản, môi giới, tư vấn': [
    'Môi giới bất động sản', 'Nhân viên kinh doanh bất động sản', 'Tư vấn tài chính',
    'Tư vấn bảo hiểm', 'Môi giới xe cũ', 'Tư vấn du học, xuất khẩu lao động', 'Cho thuê nhà trọ',
    'Quản lý tòa nhà', 'Thẩm định giá',
  ],
  'Làm đẹp, spa, tóc, nail': [
    'Thợ cắt tóc nam (barber)', 'Thợ làm tóc', 'Thợ nail', 'Nhân viên spa', 'Kỹ thuật viên massage',
    'Chuyên viên trang điểm', 'Phun xăm thẩm mỹ', 'Nối mi', 'Chủ tiệm làm đẹp', 'Gội đầu dưỡng sinh',
  ],
  'Sửa chữa điện thoại, máy tính, xe': [
    'Sửa điện thoại', 'Sửa máy tính, laptop', 'Sửa xe máy', 'Sửa ô tô', 'Thợ điện ô tô',
    'Rửa xe', 'Vá vỏ xe', 'Sửa xe đạp', 'Sửa đồ điện gia dụng', 'Sửa tivi', 'Sửa máy giặt',
    'Sửa đồng hồ', 'Đánh chìa khóa',
  ],
  'Nghề tự do, thời vụ, giúp việc': [
    'Lao động tự do', 'Lao động thời vụ', 'Làm thuê theo ngày', 'Giúp việc gia đình',
    'Giúp việc theo giờ', 'Trông trẻ', 'Phụ việc', 'Cộng tác viên', 'Người làm nhiều nghề',
  ],
  'Thủ công, mỹ nghệ, làm tại nhà': [
    'Thợ thủ công', 'Đan lát mây tre', 'Làm gốm', 'Thợ kim hoàn', 'Thợ chạm khắc gỗ',
    'Làm đồ handmade', 'Gia công tại nhà', 'May gia công tại nhà', 'Làm hương (nhang)', 'Làm bánh tại nhà',
    'Làm hoa giả, hoa voan',
  ],
  'Nông dân, làm vườn, chăn nuôi': [
    'Nông dân', 'Trồng lúa', 'Trồng rau màu', 'Trồng cây ăn trái', 'Trồng cà phê', 'Trồng tiêu',
    'Trồng cao su / cạo mủ', 'Làm vườn', 'Chăn nuôi heo', 'Chăn nuôi gà, vịt', 'Chăn nuôi bò, dê',
    'Nuôi ong', 'Trồng hoa, cây cảnh', 'Làm thuê nông nghiệp',
  ],
  'Bán vé số, thu mua phế liệu': [
    'Bán vé số', 'Bán vé số dạo', 'Đại lý vé số', 'Thu mua phế liệu', 'Ve chai, đồng nát',
    'Phân loại rác tái chế', 'Thu gom rác',
  ],
  'Bảo vệ, vệ sinh, chăm sóc nhà cửa': [
    'Bảo vệ', 'Bảo vệ tòa nhà', 'Bảo vệ công ty', 'Nhân viên vệ sinh', 'Tạp vụ', 'Vệ sinh công nghiệp',
    'Lao công', 'Làm vườn, cắt cỏ thuê', 'Vệ sinh máy lạnh', 'Diệt côn trùng', 'Giữ xe',
  ],
  'Nghệ thuật, nhiếp ảnh, sáng tạo nội dung': [
    'Nhiếp ảnh gia', 'Quay phim', 'Ca sĩ', 'Nhạc công', 'Diễn viên', 'Người mẫu', 'Họa sĩ',
    'Sáng tạo nội dung (TikTok, YouTube)', 'MC, dẫn chương trình', 'Vũ công', 'Thợ in ấn quảng cáo',
  ],
  'Học sinh, sinh viên, đang tìm việc': [
    'Sinh viên', 'Học sinh', 'Học viên học nghề', 'Sinh viên làm thêm', 'Đang tìm việc',
    'Mới ra trường', 'Thực tập sinh',
  ],
  'Nghỉ hưu và các nhóm khác': [
    'Đã nghỉ hưu', 'Nội trợ', 'Người khuyết tật làm việc', 'Lao động xuất khẩu đã về nước',
    'Tu sĩ, chức sắc tôn giáo', 'Quân nhân xuất ngũ', 'Nghề khác',
  ],
};

/// Danh sách phẳng để gợi ý tự động khi gõ.
final List<String> allOccupationSuggestions =
    {for (final list in occupationGroups.values) ...list}.toList();

/// Bỏ dấu tiếng Việt, viết thường — để tìm "tai xe" ra "Tài xế".
String vnNorm(String input) {
  const from = 'àáạảãâầấậẩẫăằắặẳẵèéẹẻẽêềếệểễìíịỉĩòóọỏõôồốộổỗơờớợởỡùúụủũưừứựửữỳýỵỷỹđ';
  final to = '${'a' * 17}${'e' * 11}${'i' * 5}${'o' * 17}${'u' * 11}${'y' * 5}d';
  final s = input.toLowerCase().trim();
  final b = StringBuffer();
  for (final ch in s.split('')) {
    final i = from.indexOf(ch);
    b.write(i >= 0 ? to[i] : ch);
  }
  return b.toString().replaceAll(RegExp(r'\s+'), ' ');
}
