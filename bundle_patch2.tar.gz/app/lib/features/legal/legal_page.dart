import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../core/theme/app_theme.dart';
import '../../core/utils/formatters.dart';
import '../../core/widgets/common.dart';
import 'legal_data.dart';

/// PHÁP NHÂN VÀ MINH BẠCH PHÁP LÝ — trang công khai, xem được cả khi chưa đăng nhập.
class LegalPage extends ConsumerWidget {
  const LegalPage({super.key});

  Future<void> _open(BuildContext context, String? url) async {
    if (url == null || url.isEmpty) return;
    final ok = await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
    if (!ok && context.mounted) toast(context, 'Không mở được liên kết', error: true);
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final info = ref.watch(legalPublicProvider);
    return Scaffold(
      appBar: AppBar(title: const Text('Pháp nhân & pháp lý')),
      body: RefreshIndicator(
        onRefresh: () async => ref.invalidate(legalPublicProvider),
        child: AsyncView<Map<String, dynamic>>(
          value: info,
          onRetry: () => ref.invalidate(legalPublicProvider),
          data: (d) {
            final published = d['published'] == true;
            final status = (d['status'] ?? 'not_updated') as String;
            final docs = ((d['documents'] as List?) ?? const []).cast<Map<String, dynamic>>();
            final taxCode = d['tax_code'] as String?;
            final lookup = (d['lookup_url'] as String?) ?? 'https://dangkykinhdoanh.gov.vn/';

            return ListView(padding: const EdgeInsets.all(16), children: [
              const Text('PHÁP NHÂN VÀ MINH BẠCH PHÁP LÝ',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: Brand.navy)),
              const SizedBox(height: 6),
              const Text('Thông tin đơn vị đứng ra vận hành ứng dụng Tương trợ và các giấy tờ để bạn tự tra cứu, kiểm tra.',
                  style: TextStyle(color: Colors.black54)),
              const SizedBox(height: 12),
              Wrap(spacing: 8, runSpacing: 8, children: [
                _StatusBadge(status: published ? status : 'not_published', text: published
                    ? (legalStatusLabel[status] ?? status)
                    : (status == 'not_updated' ? legalStatusLabel['not_updated']! : legalStatusLabel['in_progress']!)),
                if (d['has_expired_docs'] == true)
                  const _StatusBadge(status: 'expired', text: 'Có giấy tờ hết hiệu lực'),
              ]),
              const SizedBox(height: 16),

              if (!published)
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.amber.shade50,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: Colors.amber.shade200),
                  ),
                  child: const Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Icon(Icons.hourglass_top, color: Colors.orange),
                    SizedBox(width: 10),
                    Expanded(child: Text(legalPendingMessage, style: TextStyle(fontSize: 15))),
                  ]),
                )
              else ...[
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(14),
                    child: Column(children: [
                      _Row('Tên pháp nhân / đơn vị vận hành', d['legal_name']),
                      _Row('Tên giao dịch', d['trade_name']),
                      _Row('Mã số doanh nghiệp / Mã số thuế', taxCode,
                          trailing: taxCode == null
                              ? null
                              : IconButton(
                                  icon: const Icon(Icons.copy, size: 18),
                                  tooltip: 'Sao chép',
                                  onPressed: () {
                                    Clipboard.setData(ClipboardData(text: taxCode));
                                    toast(context, 'Đã sao chép mã số');
                                  },
                                )),
                      _Row('Địa chỉ trụ sở', d['address']),
                      _Row('Người đại diện theo pháp luật', d['legal_rep']),
                      _Row('Ngày thành lập',
                          d['established_date'] == null ? null : dateOnly(DateTime.parse(d['established_date']))),
                      _Row('Tình trạng hoạt động', d['operating_status']),
                      _Row('Điện thoại', d['contact_phone']),
                      _Row('Email', d['contact_email']),
                      _Row('Website', d['website']),
                      _Row('Cập nhật gần nhất',
                          d['updated_at'] == null ? null : dateTime(asDate(d['updated_at']))),
                      if (status == 'verified') ...[
                        _Row('Phạm vi đã xác minh', d['verification_scope']),
                        _Row('Ngày xác minh',
                            d['verified_at'] == null ? null : dateOnly(asDate(d['verified_at']))),
                      ],
                    ]),
                  ),
                ),
                if ((d['public_note'] ?? '').toString().isNotEmpty) ...[
                  const SizedBox(height: 8),
                  Text(d['public_note'], style: const TextStyle(color: Colors.black87)),
                ],
                const SectionTitle('Giấy tờ pháp lý công khai'),
                if (docs.isEmpty) const EmptyHint('Chưa có giấy tờ được công khai.'),
                for (final doc in docs) _DocCard(doc: doc, onOpen: (u) => _open(context, u)),
              ],

              const SizedBox(height: 20),
              FilledButton.icon(
                icon: const Icon(Icons.travel_explore),
                label: const Text('TRA CỨU THÔNG TIN DOANH NGHIỆP'),
                onPressed: () => _open(context, lookup),
              ),
              const SizedBox(height: 8),
              Text(
                taxCode == null
                    ? 'Mở Cổng thông tin quốc gia về đăng ký doanh nghiệp (dangkykinhdoanh.gov.vn), '
                        'nhập mã số doanh nghiệp/mã số thuế vào ô tìm kiếm để tự kiểm tra.'
                    : 'Mở Cổng thông tin quốc gia về đăng ký doanh nghiệp, nhập mã số $taxCode vào ô '
                        'tìm kiếm để đối chiếu tên, địa chỉ và tình trạng hoạt động.',
                style: const TextStyle(fontSize: 13, color: Colors.black54),
              ),
              const SizedBox(height: 20),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Brand.blue.withOpacity(0.06),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Text(legalDisclaimer, style: TextStyle(fontSize: 13, color: Brand.navy)),
              ),
            ]);
          },
        ),
      ),
    );
  }
}

class _Row extends StatelessWidget {
  const _Row(this.label, this.value, {this.trailing});
  final String label;
  final dynamic value;
  final Widget? trailing;
  @override
  Widget build(BuildContext context) {
    if (value == null || value.toString().isEmpty) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(label, style: const TextStyle(fontSize: 12, color: Colors.black54)),
            const SizedBox(height: 2),
            SelectableText(value.toString(),
                style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
          ]),
        ),
        if (trailing != null) trailing!,
      ]),
    );
  }
}

class _StatusBadge extends StatelessWidget {
  const _StatusBadge({required this.status, required this.text});
  final String status;
  final String text;
  @override
  Widget build(BuildContext context) {
    final (color, icon) = switch (status) {
      'verified' => (Colors.green, Icons.verified),
      'updated' => (Brand.blue, Icons.check_circle_outline),
      'needs_update' || 'expired' => (Colors.red, Icons.error_outline),
      _ => (Colors.orange, Icons.hourglass_empty),
    };
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withOpacity(0.5)),
      ),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(icon, size: 16, color: color),
        const SizedBox(width: 6),
        Flexible(child: Text(text, style: TextStyle(color: color, fontWeight: FontWeight.w700, fontSize: 13))),
      ]),
    );
  }
}

class _DocCard extends ConsumerWidget {
  const _DocCard({required this.doc, required this.onOpen});
  final Map<String, dynamic> doc;
  final void Function(String? url) onOpen;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final expired = doc['expired'] == true;
    String? d(String k) => doc[k] == null ? null : dateOnly(DateTime.parse(doc[k]));
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            const Icon(Icons.description_outlined, color: Brand.blue),
            const SizedBox(width: 8),
            Expanded(
              child: Text(doc['title'] ?? '', style: const TextStyle(fontWeight: FontWeight.w700)),
            ),
          ]),
          const SizedBox(height: 4),
          Text(legalDocTypeLabel[doc['doc_type']] ?? '', style: const TextStyle(fontSize: 12, color: Colors.black54)),
          if (doc['doc_number'] != null) Text('Số: ${doc['doc_number']}'),
          if (doc['issuer'] != null) Text('Nơi cấp: ${doc['issuer']}'),
          if (doc['issued_date'] != null) Text('Ngày cấp: ${d('issued_date')}'),
          if (doc['expiry_date'] != null)
            Text('Hiệu lực đến: ${d('expiry_date')}',
                style: TextStyle(color: expired ? Colors.red : null, fontWeight: expired ? FontWeight.w700 : null)),
          const SizedBox(height: 6),
          Wrap(spacing: 6, runSpacing: 6, children: [
            if (doc['is_verified'] == true)
              const _StatusBadge(status: 'verified', text: 'Admin đã đối chiếu'),
            if (expired) const _StatusBadge(status: 'expired', text: 'Giấy tờ hết hiệu lực'),
          ]),
          const SizedBox(height: 6),
          Wrap(spacing: 8, children: [
            if (doc['file_path'] != null)
              OutlinedButton.icon(
                style: OutlinedButton.styleFrom(minimumSize: const Size(0, 40)),
                icon: const Icon(Icons.visibility_outlined, size: 18),
                label: const Text('Xem tài liệu'),
                onPressed: () async {
                  try {
                    final url = await ref.read(legalRepositoryProvider).signedUrl(doc['file_path']);
                    onOpen(url);
                  } catch (e) {
                    if (context.mounted) toast(context, e.toString(), error: true);
                  }
                },
              ),
            if (doc['lookup_url'] != null)
              OutlinedButton.icon(
                style: OutlinedButton.styleFrom(minimumSize: const Size(0, 40)),
                icon: const Icon(Icons.open_in_new, size: 18),
                label: const Text('Tra cứu'),
                onPressed: () => onOpen(doc['lookup_url']),
              ),
          ]),
        ]),
      ),
    );
  }
}
