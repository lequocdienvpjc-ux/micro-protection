import 'dart:typed_data';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../core/error/failure.dart';
import '../auth/presentation/providers/auth_providers.dart';

const legalStatusLabel = <String, String>{
  'not_updated': 'Chưa cập nhật thông tin pháp nhân',
  'in_progress': 'Đang hoàn thiện hồ sơ',
  'updated': 'Đã cập nhật thông tin pháp nhân',
  'verified': 'Đã xác minh hồ sơ theo phạm vi công bố',
  'needs_update': 'Hồ sơ cần cập nhật',
};

const legalDocTypeLabel = <String, String>{
  'business_registration': 'Giấy chứng nhận đăng ký doanh nghiệp',
  'tax_registration': 'Đăng ký thuế',
  'license': 'Giấy phép',
  'approval': 'Văn bản chấp thuận',
  'charter': 'Điều lệ / Quy chế',
  'other': 'Tài liệu khác',
};

/// Câu thông báo trung thực khi chưa công khai (theo yêu cầu, không dùng dữ liệu giả).
const legalPendingMessage =
    'Thông tin pháp nhân và hồ sơ pháp lý đang được hoàn thiện. '
    'Chúng tôi sẽ công khai khi có đầy đủ giấy tờ và điều kiện cần thiết.';

const legalDisclaimer =
    'Lưu ý: Việc công khai giấy đăng ký doanh nghiệp không đồng nghĩa với việc mọi hoạt động của '
    'ứng dụng đã được cơ quan nhà nước cấp phép. Tương trợ là nền tảng quản lý quỹ tương trợ tự nguyện '
    'giữa các thành viên; không phải doanh nghiệp bảo hiểm, không huy động vốn và không cung cấp dịch vụ '
    'tài chính, trừ khi có giấy phép tương ứng được công bố trên trang này.';

class LegalRepository {
  LegalRepository(this._db);
  final SupabaseClient _db;
  static const bucket = 'legal-docs';

  Future<T> _g<T>(Future<T> Function() f) async {
    try {
      return await f();
    } catch (e) {
      throw Failure.from(e);
    }
  }

  Future<Map<String, dynamic>> publicInfo() =>
      _g(() async => Map<String, dynamic>.from(await _db.rpc('get_legal_public') as Map));

  Future<Map<String, dynamic>> adminGet() =>
      _g(() async => Map<String, dynamic>.from(await _db.rpc('admin_get_legal') as Map));

  Future<String> saveEntity(Map<String, dynamic> data) =>
      _g(() async => await _db.rpc('admin_save_legal_entity', params: {'p': data}) as String);

  Future<void> setStatus(String status) =>
      _g(() => _db.rpc('admin_set_legal_status', params: {'p_status': status}));

  Future<void> verify(String scope) =>
      _g(() => _db.rpc('admin_verify_legal', params: {'p_scope': scope, 'p_confirm': true}));

  Future<void> publish(bool publish) => _g(() =>
      _db.rpc('admin_publish_legal', params: {'p_publish': publish, 'p_confirm_checked': publish}));

  Future<String> upsertDoc(Map<String, dynamic> data) =>
      _g(() async => await _db.rpc('admin_upsert_legal_doc', params: {'p': data}) as String);

  Future<void> setDocFlags(String id, {bool? isPublic, bool? isActive, bool? verify}) =>
      _g(() => _db.rpc('admin_set_doc_flags', params: {
            'p_id': id,
            'p_is_public': isPublic,
            'p_is_active': isActive,
            'p_verify': verify,
          }));

  Future<List<Map<String, dynamic>>> audit() => _g(() async =>
      ((await _db.rpc('admin_legal_audit', params: {'p_limit': 200})) as List).cast<Map<String, dynamic>>());

  Future<String> uploadFile(Uint8List bytes, String ext) => _g(() async {
        final path = 'docs/${DateTime.now().millisecondsSinceEpoch}.$ext';
        await _db.storage.from(bucket).uploadBinary(path, bytes,
            fileOptions: FileOptions(contentType: ext == 'pdf' ? 'application/pdf' : 'image/$ext'));
        return path;
      });

  Future<String> signedUrl(String path) =>
      _g(() => _db.storage.from(bucket).createSignedUrl(path, 600));
}

final legalRepositoryProvider =
    Provider((ref) => LegalRepository(ref.watch(supabaseClientProvider)));

final legalPublicProvider = FutureProvider.autoDispose<Map<String, dynamic>>(
    (ref) => ref.watch(legalRepositoryProvider).publicInfo());
