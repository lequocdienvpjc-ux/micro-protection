import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/error/failure.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/formatters.dart';
import '../../core/widgets/common.dart';
import '../auth/presentation/providers/auth_providers.dart';

const feedbackCategories = <String, String>{
  'feedback': 'Góp ý',
  'complaint': 'Khiếu nại',
  'support': 'Cần hỗ trợ',
  'fraud': 'Báo cáo lừa đảo / nghi vấn',
  'other': 'Khác',
};

const feedbackStatusLabel = <String, String>{
  'new': 'Mới gửi',
  'processing': 'Đang xử lý',
  'resolved': 'Đã giải quyết',
  'closed': 'Đã đóng',
};

final myFeedbackProvider = FutureProvider.autoDispose<List<Map<String, dynamic>>>((ref) async {
  try {
    final r = await ref
        .read(supabaseClientProvider)
        .from('feedback')
        .select('id, category, subject, content, status, admin_reply, created_at')
        .order('created_at', ascending: false);
    return (r as List).cast<Map<String, dynamic>>();
  } catch (e) {
    throw Failure.from(e);
  }
});

/// Kênh tiếp nhận PHẢN ÁNH / KHIẾU NẠI của thành viên.
class FeedbackScreen extends ConsumerStatefulWidget {
  const FeedbackScreen({super.key});
  @override
  ConsumerState<FeedbackScreen> createState() => _FeedbackScreenState();
}

class _FeedbackScreenState extends ConsumerState<FeedbackScreen> {
  final _form = GlobalKey<FormState>();
  final _subject = TextEditingController();
  final _content = TextEditingController();
  final _contact = TextEditingController();
  String _category = 'feedback';
  bool _sending = false;

  @override
  void dispose() {
    _subject.dispose();
    _content.dispose();
    _contact.dispose();
    super.dispose();
  }

  Future<void> _send() async {
    if (!_form.currentState!.validate()) return;
    setState(() => _sending = true);
    final ok = await runAction(context, () async {
      try {
        await ref.read(supabaseClientProvider).rpc('submit_feedback', params: {
          'p_category': _category,
          'p_subject': _subject.text.trim(),
          'p_content': _content.text.trim(),
          'p_contact': _contact.text.trim(),
        });
      } catch (e) {
        throw Failure.from(e);
      }
    }, success: 'Đã gửi. Ban quản trị sẽ phản hồi trong ứng dụng.');
    if (!mounted) return;
    setState(() => _sending = false);
    if (ok) {
      _subject.clear();
      _content.clear();
      ref.invalidate(myFeedbackProvider);
    }
  }

  @override
  Widget build(BuildContext context) {
    final mine = ref.watch(myFeedbackProvider);
    return Scaffold(
      appBar: AppBar(title: const Text('Phản ánh / khiếu nại')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        const Text(
          'Mọi phản ánh được ghi nhận và lưu lịch sử. Với nghi vấn gian lận của một yêu cầu hỗ trợ cụ thể, '
          'bạn có thể bấm vào yêu cầu đó trong Trang chủ nhóm và chọn "Báo cáo nghi vấn".',
          style: TextStyle(color: Colors.black54),
        ),
        const SizedBox(height: 16),
        Form(
          key: _form,
          child: Column(children: [
            DropdownButtonFormField<String>(
              value: _category,
              decoration: const InputDecoration(labelText: 'Loại'),
              items: [
                for (final e in feedbackCategories.entries)
                  DropdownMenuItem(value: e.key, child: Text(e.value)),
              ],
              onChanged: (v) => setState(() => _category = v!),
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _subject,
              maxLength: 150,
              decoration: const InputDecoration(labelText: 'Tiêu đề', counterText: ''),
              validator: (v) => (v ?? '').trim().length < 3 ? 'Nhập tiêu đề' : null,
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _content,
              maxLines: 5,
              maxLength: 3000,
              decoration: const InputDecoration(
                labelText: 'Nội dung', alignLabelWithHint: true),
              validator: (v) => (v ?? '').trim().length < 10 ? 'Nội dung tối thiểu 10 ký tự' : null,
            ),
            const SizedBox(height: 4),
            TextFormField(
              controller: _contact,
              decoration: const InputDecoration(
                  labelText: 'Số điện thoại / Zalo liên hệ (không bắt buộc)'),
            ),
            const SizedBox(height: 16),
            FilledButton(
              onPressed: _sending ? null : _send,
              child: Text(_sending ? 'Đang gửi…' : 'Gửi phản ánh'),
            ),
          ]),
        ),
        const SectionTitle('Phản ánh của tôi'),
        AsyncView<List<Map<String, dynamic>>>(
          value: mine,
          onRetry: () => ref.invalidate(myFeedbackProvider),
          data: (list) => list.isEmpty
              ? const EmptyHint('Bạn chưa gửi phản ánh nào.')
              : Column(children: [
                  for (final f in list)
                    Card(
                      margin: const EdgeInsets.only(bottom: 8),
                      child: Padding(
                        padding: const EdgeInsets.all(12),
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Row(children: [
                            Expanded(
                              child: Text(f['subject'] ?? '',
                                  style: const TextStyle(fontWeight: FontWeight.w700)),
                            ),
                            StatusChip(f['status'] == 'resolved' ? 'paid' : (f['status'] == 'new' ? 'pending' : 'voting'),
                                feedbackStatusLabel[f['status']] ?? f['status']),
                          ]),
                          Text('${feedbackCategories[f['category']] ?? ''} · ${dateTime(asDate(f['created_at']))}',
                              style: const TextStyle(fontSize: 12, color: Colors.black54)),
                          const SizedBox(height: 6),
                          Text(f['content'] ?? ''),
                          if ((f['admin_reply'] ?? '').toString().isNotEmpty) ...[
                            const SizedBox(height: 8),
                            Container(
                              width: double.infinity,
                              padding: const EdgeInsets.all(10),
                              decoration: BoxDecoration(
                                color: Brand.blue.withOpacity(0.07),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Text('Phản hồi: ${f['admin_reply']}',
                                  style: const TextStyle(color: Brand.navy)),
                            ),
                          ],
                        ]),
                      ),
                    ),
                ]),
        ),
      ]),
    );
  }
}
