import '../entities/app_user.dart';

/// Hợp đồng của tầng domain. Tầng presentation chỉ biết interface này,
/// nên có thể đổi Supabase sang backend khác mà không sửa UI.
abstract interface class AuthRepository {
  /// Phát `true` khi có phiên đăng nhập hợp lệ, `false` khi đăng xuất/hết hạn.
  Stream<bool> watchSignedIn();
  bool get isSignedIn;
  String? get currentUserId;

  // --- Số điện thoại + OTP ---
  Future<void> sendPhoneOtp(String phoneE164);
  Future<void> verifyPhoneOtp({required String phoneE164, required String code});

  // --- Email + mật khẩu ---
  /// Trả về `true` nếu cần xác nhận email trước khi đăng nhập.
  Future<bool> signUpWithEmail({required String email, required String password});
  Future<void> signInWithEmail({required String email, required String password});
  Future<void> sendPasswordReset(String email);

  Future<void> signOut();

  // --- Hồ sơ & KYC ---
  Future<AppUser> fetchCurrentUser();
  Future<KycStatus> submitKyc({
    required String fullName,
    required String nationalId,
    required List<String> occupations,
    required bool consent,
  });

  /// Thêm / sửa / xoá ngành nghề sau khi đã xác minh.
  Future<List<String>> updateOccupations(List<String> occupations);
}
