enum KycStatus { none, pending, verified, rejected }

enum SystemRole { member, admin }

KycStatus kycStatusFrom(String? v) =>
    KycStatus.values.firstWhere((e) => e.name == v, orElse: () => KycStatus.none);

/// Người dùng trong domain — không phụ thuộc Supabase.
class AppUser {
  const AppUser({
    required this.id,
    this.phone,
    this.email,
    this.fullName,
    this.occupation,
    this.occupations = const [],
    this.nationalIdLast4,
    this.kycStatus = KycStatus.none,
    this.systemRole = SystemRole.member,
  });

  final String id;
  final String? phone;
  final String? email;
  final String? fullName;
  final String? occupation; // cột cũ (chuỗi nối) — giữ để tương thích
  final List<String> occupations;
  final String? nationalIdLast4;
  final KycStatus kycStatus;
  final SystemRole systemRole;

  bool get isAdmin => systemRole == SystemRole.admin;
  bool get isVerified => kycStatus == KycStatus.verified;
  bool get needsKyc => kycStatus == KycStatus.none || kycStatus == KycStatus.rejected;

  String get displayName => fullName ?? phone ?? email ?? 'Thành viên';
}
