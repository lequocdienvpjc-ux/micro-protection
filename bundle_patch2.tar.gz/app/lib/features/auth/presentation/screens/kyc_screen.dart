import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/utils/validators.dart';
import '../../../../core/widgets/occupation_input.dart';
import '../../domain/entities/app_user.dart';
import '../providers/auth_providers.dart';
import '../widgets/auth_widgets.dart';

/// KYC siêu ngắn: Họ tên + CCCD + Ngành nghề + đồng ý xử lý dữ liệu cá nhân.
/// CCCD được gửi thẳng vào RPC `submit_kyc`, mã hóa phía server, client không lưu.
class KycScreen extends ConsumerStatefulWidget {
  const KycScreen({super.key});
  @override
  ConsumerState<KycScreen> createState() => _KycScreenState();
}

class _KycScreenState extends ConsumerState<KycScreen> {
  final _form = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _cccd = TextEditingController();
  List<String> _occupations = const [];
  bool _consent = false;

  @override
  void dispose() {
    _name.dispose();
    _cccd.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_form.currentState!.validate()) return;
    if (_occupations.isEmpty) {
      showError(context, 'Vui lòng nhập ít nhất một ngành nghề (gõ rồi bấm dấu +).');
      return;
    }
    if (!_consent) {
      showError(context, 'Bạn cần đồng ý điều khoản xử lý dữ liệu cá nhân.');
      return;
    }
    final ok = await ref.read(authControllerProvider.notifier).submitKyc(
          fullName: _name.text,
          nationalId: _cccd.text,
          occupations: _occupations,
          consent: _consent,
        );
    if (!mounted) return;
    if (ok) {
      _cccd.clear(); // không giữ CCCD trong bộ nhớ UI
    } else {
      showError(context, ref.read(authControllerProvider).error);
    }
    // Thành công: currentUserProvider được làm mới -> router chuyển sang màn chờ duyệt
  }

  @override
  Widget build(BuildContext context) {
    final loading = ref.watch(authControllerProvider).isLoading;
    final rejected =
        ref.watch(currentUserProvider).valueOrNull?.kycStatus == KycStatus.rejected;

    return AuthScaffold(
      title: 'Xác minh danh tính',
      subtitle: 'Chỉ mất 1 phút. Thông tin giúp nhóm tránh tài khoản giả mạo.',
      child: Form(
        key: _form,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            if (rejected)
              Container(
                margin: const EdgeInsets.only(bottom: 16),
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.red.shade50,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Text('Hồ sơ trước chưa được duyệt. Vui lòng kiểm tra và gửi lại.'),
              ),
            TextFormField(
              controller: _name,
              textCapitalization: TextCapitalization.words,
              autofillHints: const [AutofillHints.name],
              decoration: const InputDecoration(
                labelText: 'Họ và tên (như trên CCCD)',
                prefixIcon: Icon(Icons.person_outline),
              ),
              validator: Validators.fullName,
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _cccd,
              keyboardType: TextInputType.number,
              maxLength: 12,
              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
              decoration: const InputDecoration(
                labelText: 'Số CCCD (12 số)',
                prefixIcon: Icon(Icons.badge_outlined),
                counterText: '',
              ),
              validator: Validators.nationalId,
            ),
            const SizedBox(height: 16),
            OccupationInput(
              initial: _occupations,
              onChanged: (v) => _occupations = v,
            ),
            const SizedBox(height: 12),
            CheckboxListTile(
              value: _consent,
              onChanged: (v) => setState(() => _consent = v ?? false),
              controlAffinity: ListTileControlAffinity.leading,
              contentPadding: EdgeInsets.zero,
              title: const Text(
                'Tôi đồng ý cho nền tảng xử lý họ tên, số CCCD và ngành nghề '
                'để xác minh danh tính, theo Chính sách bảo vệ dữ liệu cá nhân.',
                style: TextStyle(fontSize: 14),
              ),
            ),
            const SizedBox(height: 16),
            PrimaryButton(label: 'Gửi xác minh', loading: loading, onPressed: _submit),
            TextButton(
              onPressed: loading ? null : () => ref.read(authControllerProvider.notifier).signOut(),
              child: const Text('Đăng xuất'),
            ),
          ],
        ),
      ),
    );
  }
}
