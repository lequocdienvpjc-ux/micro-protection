import 'dart:async';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../data/datasources/auth_remote_datasource.dart';
import '../../data/repositories/auth_repository_impl.dart';
import '../../domain/entities/app_user.dart';
import '../../domain/repositories/auth_repository.dart';

// ---------------- Dependency injection ----------------
final supabaseClientProvider = Provider<SupabaseClient>((_) => Supabase.instance.client);

final authRepositoryProvider = Provider<AuthRepository>(
  (ref) => AuthRepositoryImpl(AuthRemoteDataSource(ref.watch(supabaseClientProvider))),
);

// ---------------- Trạng thái phiên ----------------
/// true/false theo phiên đăng nhập; phát giá trị hiện tại ngay khi lắng nghe.
final signedInProvider = StreamProvider<bool>((ref) async* {
  final repo = ref.watch(authRepositoryProvider);
  yield repo.isSignedIn;
  yield* repo.watchSignedIn();
});

/// Hồ sơ người dùng hiện tại (null nếu chưa đăng nhập).
/// Gọi `ref.invalidate(currentUserProvider)` để tải lại (vd. sau khi nộp KYC).
final currentUserProvider = FutureProvider<AppUser?>((ref) async {
  final signedIn = ref.watch(signedInProvider).valueOrNull ?? false;
  if (!signedIn) return null;
  return ref.read(authRepositoryProvider).fetchCurrentUser();
});

// ---------------- Controller cho các hành động ----------------
/// State = trạng thái của thao tác đang chạy (loading / error) để UI hiển thị.
class AuthController extends AutoDisposeAsyncNotifier<void> {
  AuthRepository get _repo => ref.read(authRepositoryProvider);

  @override
  FutureOr<void> build() {}

  Future<bool> _run(Future<void> Function() action) async {
    state = const AsyncLoading();
    state = await AsyncValue.guard(action);
    return !state.hasError;
  }

  Future<bool> sendOtp(String phoneE164) => _run(() => _repo.sendPhoneOtp(phoneE164));

  Future<bool> verifyOtp(String phoneE164, String code) =>
      _run(() => _repo.verifyPhoneOtp(phoneE164: phoneE164, code: code));

  Future<bool> signInEmail(String email, String password) =>
      _run(() => _repo.signInWithEmail(email: email, password: password));

  /// Trả về null nếu lỗi; true nếu cần xác nhận email; false nếu đã đăng nhập ngay.
  Future<bool?> signUpEmail(String email, String password) async {
    bool? needsConfirm;
    final ok = await _run(() async {
      needsConfirm = await _repo.signUpWithEmail(email: email, password: password);
    });
    return ok ? needsConfirm : null;
  }

  Future<bool> resetPassword(String email) => _run(() => _repo.sendPasswordReset(email));

  Future<bool> submitKyc({
    required String fullName,
    required String nationalId,
    required List<String> occupations,
    required bool consent,
  }) async {
    final ok = await _run(() => _repo.submitKyc(
          fullName: fullName,
          nationalId: nationalId,
          occupations: occupations,
          consent: consent,
        ));
    if (ok) ref.invalidate(currentUserProvider);
    return ok;
  }

  Future<void> signOut() => _run(_repo.signOut);
}

final authControllerProvider =
    AutoDisposeAsyncNotifierProvider<AuthController, void>(AuthController.new);
