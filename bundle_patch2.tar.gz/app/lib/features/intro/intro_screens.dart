import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:go_router/go_router.dart';

import '../../core/router/app_router.dart';
import '../../core/theme/app_theme.dart';

/// Đã xem màn giới thiệu chưa (đọc 1 lần lúc mở app, ghi đè trong main.dart).
final introSeenProvider = StateProvider<bool>((_) => true);
const introSeenKey = 'mpn_intro_seen';

Future<bool> readIntroSeen() async {
  try {
    return (await const FlutterSecureStorage().read(key: introSeenKey)) == '1';
  } catch (_) {
    return true; // lỗi đọc bộ nhớ thì bỏ qua giới thiệu, không chặn người dùng
  }
}

// ---------------------------------------------------------------------------
// 1. MÀN GIỚI THIỆU NGẮN (mở app lần đầu, hoặc từ Tài khoản / Đăng nhập)
// ---------------------------------------------------------------------------
class WelcomeScreen extends ConsumerWidget {
  const WelcomeScreen({super.key});

  Future<void> _start(BuildContext context, WidgetRef ref) async {
    try {
      await const FlutterSecureStorage().write(key: introSeenKey, value: '1');
    } catch (_) {}
    ref.read(introSeenProvider.notifier).state = true;
    if (!context.mounted) return;
    if (context.canPop()) {
      context.pop();
    } else {
      context.go(Routes.login);
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: ListView(padding: const EdgeInsets.fromLTRB(22, 24, 22, 24), children: [
          const BrandHeader(size: 120),
          const SizedBox(height: 24),
          const Text(
            'Không ai biết trước khi nào mình gặp biến cố. Một tai nạn, một sự cố bất ngờ hay một giai đoạn '
            'khó khăn có thể đến với bất kỳ ai.',
            style: TextStyle(fontSize: 16, height: 1.45),
          ),
          const SizedBox(height: 12),
          const Text(
            'Tương trợ kết nối những người bình thường thành một cộng đồng cùng sẻ chia. Mỗi người góp một phần nhỏ '
            'theo quy chế chung; khi một thành viên gặp hoàn cảnh đủ điều kiện, cộng đồng cùng xem xét và chung tay giúp đỡ.',
            style: TextStyle(fontSize: 16, height: 1.45),
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(gradient: Brand.warmGradient, borderRadius: BorderRadius.circular(14)),
            child: const Text(
              'Bạn không cần phải giàu có để giúp đỡ người khác. Chỉ cần mỗi người góp một chút, '
              'chúng ta có thể tạo nên một điểm tựa lớn.',
              style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w700, height: 1.4),
            ),
          ),
          const SizedBox(height: 22),
          const Text('Tạo niềm tin bằng sự minh bạch',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: Brand.navy)),
          const SizedBox(height: 8),
          const _Check('Công khai mọi khoản đóng góp và chi hỗ trợ trong sổ quỹ của nhóm.'),
          const _Check('Đề nghị hỗ trợ phải có ảnh chụp tại chỗ và vị trí GPS để xác minh.'),
          const _Check('5 thành viên được chọn ngẫu nhiên cùng thẩm định theo quy chế.'),
          const _Check('Công khai thông tin đơn vị vận hành và hồ sơ pháp lý khi đã hoàn thiện.'),
          const _Check('Có kênh tiếp nhận phản ánh và khiếu nại ngay trong ứng dụng.'),
          const SizedBox(height: 14),
          const Text(
            'Tương trợ không yêu cầu bạn tin tưởng bằng lời nói. Chúng tôi hướng đến việc để bạn có thể kiểm tra, '
            'theo dõi và tự đánh giá trước khi tham gia.',
            style: TextStyle(fontSize: 15, fontStyle: FontStyle.italic, color: Brand.navy, height: 1.4),
          ),
          const SizedBox(height: 24),
          FilledButton(onPressed: () => _start(context, ref), child: const Text('Bắt đầu')),
          const SizedBox(height: 10),
          OutlinedButton.icon(
            icon: const Icon(Icons.route_outlined),
            label: const Text('Tìm hiểu cách Tương trợ hoạt động'),
            onPressed: () => context.push(Routes.about),
          ),
          const SizedBox(height: 8),
          Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            TextButton(onPressed: () => context.push(Routes.rules), child: const Text('Quy chế quỹ')),
            const Text('·'),
            TextButton(onPressed: () => context.push(Routes.legal), child: const Text('Pháp nhân & pháp lý')),
          ]),
        ]),
      ),
    );
  }
}

class _Check extends StatelessWidget {
  const _Check(this.text);
  final String text;
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Icon(Icons.check_circle, color: Brand.blue, size: 20),
          const SizedBox(width: 8),
          Expanded(child: Text(text, style: const TextStyle(fontSize: 15, height: 1.35))),
        ]),
      );
}

// ---------------------------------------------------------------------------
// 2. CÁCH TƯƠNG TRỢ HOẠT ĐỘNG
// ---------------------------------------------------------------------------
class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});

  @override
  Widget build(BuildContext context) {
    const steps = [
      (Icons.badge_outlined, 'Đăng ký & xác minh',
          'Tạo tài khoản, nhập họ tên, số CCCD và ngành nghề. Số CCCD được mã hoá, chỉ Admin xem khi duyệt.'),
      (Icons.groups_2_outlined, 'Tham gia nhóm',
          'Chọn nhóm phù hợp. Mỗi nhóm công bố rõ mức đóng góp, mức hỗ trợ tối đa và thời gian chờ.'),
      (Icons.savings_outlined, 'Đóng góp định kỳ',
          'Chuyển khoản bằng mã VietQR vào tài khoản của nhóm, ghi đúng nội dung. Trưởng nhóm xác nhận khi tiền về.'),
      (Icons.health_and_safety_outlined, 'Đề nghị hỗ trợ khi gặp biến cố',
          'Chụp ảnh / quay video tại chỗ, hệ thống tự ghi vị trí GPS và thời gian. Không dùng được ảnh cũ.'),
      (Icons.how_to_vote_outlined, 'Cộng đồng thẩm định',
          '5 thành viên được chọn ngẫu nhiên (loại người quen của người đề nghị). Đủ 4/5 đồng ý mới được duyệt.'),
      (Icons.payments_outlined, 'Chi hỗ trợ & công khai',
          'Trưởng nhóm chuyển khoản cho người được hỗ trợ và nhập mã giao dịch. Khoản chi hiện trong sổ quỹ của nhóm.'),
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('Cách Tương trợ hoạt động')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        for (var i = 0; i < steps.length; i++)
          Card(
            margin: const EdgeInsets.only(bottom: 10),
            child: ListTile(
              contentPadding: const EdgeInsets.all(12),
              leading: CircleAvatar(
                backgroundColor: i.isEven ? Brand.blue : Brand.orange,
                foregroundColor: Colors.white,
                child: Icon(steps[i].$1),
              ),
              title: Text('${i + 1}. ${steps[i].$2}', style: const TextStyle(fontWeight: FontWeight.w800, color: Brand.navy)),
              subtitle: Padding(padding: const EdgeInsets.only(top: 4), child: Text(steps[i].$3)),
            ),
          ),
        const _Section('Tiền đóng góp được quản lý ra sao?', [
          'Tiền nằm ở tài khoản ngân hàng của nhóm (hiển thị trong mã QR khi đóng góp), không nằm trong ứng dụng.',
          'Mọi khoản thu – chi được ghi vào sổ quỹ không sửa, không xoá được; thành viên nhóm đều xem được.',
          'Phí vận hành nền tảng hiện tại là 5% trên mỗi khoản đóng góp, hiển thị riêng trong sổ quỹ.',
          'Mỗi lần chi không vượt mức tối đa của nhóm và không quá 20% số dư quỹ.',
        ]),
        const _Section('Kiểm tra thông tin & phòng tránh lừa đảo', [
          'Chỉ chuyển khoản vào tài khoản nhóm hiển thị trong ứng dụng, với đúng nội dung chuyển khoản được cấp.',
          'Không ai trong Tương trợ được yêu cầu bạn chuyển tiền vào tài khoản cá nhân, hay đòi mật khẩu, mã OTP.',
          'Tự tra cứu đơn vị vận hành tại trang "Pháp nhân & pháp lý" và Cổng thông tin quốc gia về đăng ký doanh nghiệp.',
          'Thấy đề nghị hỗ trợ đáng ngờ: bấm vào đề nghị đó và chọn "Báo cáo nghi vấn".',
          'Có vướng mắc: gửi "Phản ánh / khiếu nại" trong mục Tài khoản để được phản hồi.',
        ]),
        const SizedBox(height: 8),
        Wrap(spacing: 8, runSpacing: 8, children: [
          OutlinedButton.icon(
              onPressed: () => context.push(Routes.rules),
              icon: const Icon(Icons.gavel_outlined),
              label: const Text('Quy chế quỹ')),
          OutlinedButton.icon(
              onPressed: () => context.push(Routes.legal),
              icon: const Icon(Icons.verified_outlined),
              label: const Text('Pháp nhân & pháp lý')),
        ]),
        const SizedBox(height: 12),
        const Text(
          'Sổ quỹ minh bạch của từng nhóm xem tại Trang chủ nhóm → "Xem sổ quỹ" sau khi bạn tham gia nhóm.',
          style: TextStyle(fontSize: 13, color: Colors.black54),
        ),
      ]),
    );
  }
}

class _Section extends StatelessWidget {
  const _Section(this.title, this.items);
  final String title;
  final List<String> items;
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(top: 14, bottom: 4),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: Brand.navy)),
          const SizedBox(height: 6),
          for (final t in items)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 3),
              child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Padding(
                  padding: EdgeInsets.only(top: 7, right: 8),
                  child: Icon(Icons.circle, size: 6, color: Brand.orange),
                ),
                Expanded(child: Text(t, style: const TextStyle(fontSize: 15, height: 1.4))),
              ]),
            ),
        ]),
      );
}

// ---------------------------------------------------------------------------
// 3. QUY CHẾ QUỸ (tóm tắt đúng các quy tắc đang chạy trong hệ thống)
// ---------------------------------------------------------------------------
class RulesScreen extends StatelessWidget {
  const RulesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Quy chế quỹ (tóm tắt)')),
      body: ListView(padding: const EdgeInsets.all(16), children: const [
        Text('Các quy tắc dưới đây được hệ thống áp dụng tự động cho mọi nhóm. Mức đóng góp, mức hỗ trợ '
            'tối đa và thời gian chờ của từng nhóm hiển thị trong thông tin nhóm.',
            style: TextStyle(color: Colors.black54)),
        _Section('1. Tham gia', [
          'Thành viên phải xác minh danh tính (họ tên, CCCD) trước khi vào nhóm.',
          'Mỗi số CCCD chỉ dùng cho một tài khoản.',
        ]),
        _Section('2. Đóng góp', [
          'Đóng theo mức và chu kỳ của nhóm, chuyển khoản vào tài khoản nhóm qua mã VietQR.',
          'Khoản đóng chỉ được ghi nhận khi Trưởng nhóm xác nhận đã thấy tiền về.',
          'Phí vận hành nền tảng 5% được trích từ mỗi khoản đóng góp và hiển thị công khai.',
        ]),
        _Section('3. Điều kiện đề nghị hỗ trợ', [
          'Đã tham gia nhóm đủ thời gian chờ của nhóm (mặc định 30 ngày).',
          'Đã đóng góp trong kỳ gần nhất.',
          'Nhóm có đủ số thành viên tối thiểu để thẩm định.',
          'Sự cố xảy ra trong vòng 7 ngày; có ít nhất 1 ảnh chụp tại chỗ kèm vị trí GPS.',
          'Mỗi người chỉ có 1 đề nghị đang xử lý trong một nhóm.',
        ]),
        _Section('4. Thẩm định', [
          '5 thành viên đã xác minh được chọn ngẫu nhiên; loại trừ người giới thiệu và người được người đề nghị giới thiệu.',
          'Cần 4/5 phiếu đồng ý. Phiếu không đồng ý phải ghi lý do.',
          'Mỗi người có 24 giờ để bầu, quá hạn sẽ được thay người khác; tổng thời gian tối đa 72 giờ.',
          'Danh tính người thẩm định được giữ kín với người đề nghị.',
        ]),
        _Section('5. Chi hỗ trợ', [
          'Số tiền chi không vượt mức tối đa của nhóm và không quá 20% số dư quỹ tại thời điểm duyệt.',
          'Trưởng nhóm chuyển khoản vào tài khoản người được hỗ trợ và nhập mã giao dịch ngân hàng.',
          'Mọi khoản chi được ghi vào sổ quỹ công khai trong nhóm.',
        ]),
        _Section('6. Gian lận & khiếu nại', [
          'Bất kỳ thành viên nào cũng có thể báo cáo nghi vấn; đề nghị bị báo cáo sẽ tạm dừng để Admin kiểm tra.',
          'Gian lận được xác nhận: đề nghị bị từ chối và thành viên bị tạm khoá trong nhóm.',
          'Thắc mắc, khiếu nại gửi qua mục "Phản ánh / khiếu nại" và được lưu lịch sử xử lý.',
        ]),
        SizedBox(height: 16),
        Text(
          'Tương trợ là nền tảng quản lý quỹ tương trợ tự nguyện giữa các thành viên. Đây không phải sản phẩm bảo '
          'hiểm và không phải cam kết chi trả như hợp đồng bảo hiểm; việc hỗ trợ phụ thuộc vào quy chế, số dư quỹ và '
          'kết quả thẩm định của cộng đồng.',
          style: TextStyle(fontSize: 13, color: Brand.navy, fontStyle: FontStyle.italic),
        ),
      ]),
    );
  }
}
