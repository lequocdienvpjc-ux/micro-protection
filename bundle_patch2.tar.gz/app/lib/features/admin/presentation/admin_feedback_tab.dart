import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/error/failure.dart';
import '../../../core/utils/formatters.dart';
import '../../../core/widgets/common.dart';
import '../../auth/presentation/providers/auth_providers.dart';
import '../../feedback/feedback_screen.dart';

final _feedbackProvider = FutureProvider.autoDispose<List<Map<String, dynamic>>>((ref) async {
  try {
    final r = await ref.read(supabaseClientProvider).rpc('admin_list_feedback');
    return (r as List).cast<Map<String, dynamic>>();
  } catch (e) {
    throw Failure.from(e);
  }
});

/// Admin tiếp nhận & phản hồi phản ánh / khiếu nại.
class AdminFeedbackTab extends ConsumerWidget {
  const AdminFeedbackTab({super.key});

  Future<void> _reply(BuildContext context, WidgetRef ref, Map<String, dynamic> f) async {
    final c = TextEditingController(text: f['admin_reply'] ?? '');
    String status = f['status'] == 'new' ? 'processing' : f['status'];
    final go = await showDialog<bool>(
      context: context,
      builder: (d) => StatefulBuilder(
        builder: (d, setS) => AlertDialog(
          title: const Text('Phản hồi'),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            DropdownButtonFormField<String>(
              value: status,
              decoration: const InputDecoration(labelText: 'Trạng thái'),
              items: [
                for (final e in feedbackStatusLabel.entries) DropdownMenuItem(value: e.key, child: Text(e.value)),
              ],
              onChanged: (v) => setS(() => status = v!),
            ),
            const SizedBox(height: 10),
            TextField(controller: c, maxLines: 4, decoration: const InputDecoration(labelText: 'Nội dung phản hồi')),
          ]),
          actions: [
            TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Huỷ')),
            FilledButton(onPressed: () => Navigator.pop(d, true), child: const Text('Gửi')),
          ],
        ),
      ),
    );
    if (go != true || !context.mounted) return;
    await runAction(context, () async {
      try {
        await ref.read(supabaseClientProvider).rpc('admin_reply_feedback',
            params: {'p_id': f['id'], 'p_status': status, 'p_reply': c.text});
      } catch (e) {
        throw Failure.from(e);
      }
    }, success: 'Đã cập nhật');
    ref.invalidate(_feedbackProvider);
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final list = ref.watch(_feedbackProvider);
    return RefreshIndicator(
      onRefresh: () async => ref.invalidate(_feedbackProvider),
      child: AsyncView<List<Map<String, dynamic>>>(
        value: list,
        onRetry: () => ref.invalidate(_feedbackProvider),
        data: (rows) => ListView(padding: const EdgeInsets.all(16), children: [
          if (rows.isEmpty) const EmptyHint('Chưa có phản ánh nào.'),
          for (final f in rows)
            Card(
              margin: const EdgeInsets.only(bottom: 8),
              child: InkWell(
                onTap: () => _reply(context, ref, f),
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [
                      Expanded(child: Text(f['subject'] ?? '', style: const TextStyle(fontWeight: FontWeight.w700))),
                      Text(feedbackStatusLabel[f['status']] ?? '',
                          style: TextStyle(color: f['status'] == 'new' ? Colors.red : Colors.black54)),
                    ]),
                    Text('${feedbackCategories[f['category']] ?? ''} · ${f['member_name'] ?? ''} · '
                        '${f['contact'] ?? f['member_contact'] ?? ''} · ${dateTime(asDate(f['created_at']))}',
                        style: const TextStyle(fontSize: 12, color: Colors.black54)),
                    const SizedBox(height: 6),
                    Text(f['content'] ?? ''),
                    if ((f['admin_reply'] ?? '').toString().isNotEmpty)
                      Padding(
                        padding: const EdgeInsets.only(top: 6),
                        child: Text('Đã phản hồi: ${f['admin_reply']}', style: const TextStyle(color: Colors.green)),
                      ),
                  ]),
                ),
              ),
            ),
        ]),
      ),
    );
  }
}
