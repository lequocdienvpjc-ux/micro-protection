import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/app_theme.dart';
import '../../../core/utils/formatters.dart';
import '../../../core/widgets/common.dart';
import '../../legal/legal_data.dart';

final _adminLegalProvider = FutureProvider.autoDispose<Map<String, dynamic>>(
    (ref) => ref.watch(legalRepositoryProvider).adminGet());

/// QUẢN TRỊ PHÁP NHÂN: nhập thông tin, giấy tờ, xác minh, công khai, nhật ký.
class AdminLegalTab extends ConsumerWidget {
  const AdminLegalTab({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final data = ref.watch(_adminLegalProvider);
    return RefreshIndicator(
      onRefresh: () async => ref.invalidate(_adminLegalProvider),
      child: AsyncView<Map<String, dynamic>>(
        value: data,
        onRetry: () => ref.invalidate(_adminLegalProvider),
        data: (d) => _LegalAdminBody(
          key: ValueKey(d['entity']?['updated_at']),
          entity: Map<String, dynamic>.from(d['entity'] as Map),
          docs: ((d['documents'] as List?) ?? const []).cast<Map<String, dynamic>>(),
          onChanged: () => ref.invalidate(_adminLegalProvider),
        ),
      ),
    );
  }
}

class _LegalAdminBody extends ConsumerStatefulWidget {
  const _LegalAdminBody({super.key, required this.entity, required this.docs, required this.onChanged});
  final Map<String, dynamic> entity;
  final List<Map<String, dynamic>> docs;
  final VoidCallback onChanged;
  @override
  ConsumerState<_LegalAdminBody> createState() => _LegalAdminBodyState();
}

class _LegalAdminBodyState extends ConsumerState<_LegalAdminBody> {
  static const _fields = <String, String>{
    'legal_name': 'Tên pháp nhân / đơn vị vận hành *',
    'trade_name': 'Tên giao dịch',
    'tax_code': 'Mã số doanh nghiệp / Mã số thuế *',
    'address': 'Địa chỉ trụ sở *',
    'legal_rep': 'Người đại diện theo pháp luật',
    'established_date': 'Ngày thành lập (YYYY-MM-DD)',
    'operating_status': 'Tình trạng hoạt động (theo Cổng ĐKDN)',
    'contact_phone': 'Điện thoại liên hệ chính thức',
    'contact_email': 'Email liên hệ chính thức',
    'website': 'Website',
    'lookup_url': 'Liên kết tra cứu công khai',
    'public_note': 'Ghi chú công khai',
  };
  late final Map<String, TextEditingController> _c = {
    for (final k in _fields.keys) k: TextEditingController(text: widget.entity[k]?.toString() ?? ''),
  };
  late bool _showRep = widget.entity['show_legal_rep'] == true;

  LegalRepository get _repo => ref.read(legalRepositoryProvider);

  @override
  void dispose() {
    for (final c in _c.values) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _do(Future<void> Function() f, String ok) async {
    if (await runAction(context, f, success: ok)) widget.onChanged();
  }

  Future<void> _verify() async {
    final scope = TextEditingController();
    bool checked = false;
    final go = await showDialog<bool>(
      context: context,
      builder: (d) => StatefulBuilder(
        builder: (d, setS) => AlertDialog(
          title: const Text('Xác minh hồ sơ pháp nhân'),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            const Text('Chỉ xác minh khi bạn đã đối chiếu giấy tờ gốc và tra cứu trên Cổng ĐKDN.'),
            const SizedBox(height: 12),
            TextField(
              controller: scope,
              maxLines: 3,
              decoration: const InputDecoration(
                labelText: 'Phạm vi đã xác minh (hiển thị công khai)',
                hintText: 'VD: Đã đối chiếu Giấy CN ĐKDN bản gốc và tra cứu trên Cổng ĐKDN ngày…',
              ),
            ),
            CheckboxListTile(
              value: checked,
              contentPadding: EdgeInsets.zero,
              controlAffinity: ListTileControlAffinity.leading,
              onChanged: (v) => setS(() => checked = v ?? false),
              title: const Text('Tôi xác nhận đã kiểm tra hồ sơ'),
            ),
          ]),
          actions: [
            TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Huỷ')),
            FilledButton(onPressed: checked ? () => Navigator.pop(d, true) : null, child: const Text('Xác minh')),
          ],
        ),
      ),
    );
    if (go == true && mounted) await _do(() => _repo.verify(scope.text), 'Đã xác minh hồ sơ');
  }

  Future<void> _publish(bool publish) async {
    if (publish) {
      bool checked = false;
      final go = await showDialog<bool>(
        context: context,
        builder: (d) => StatefulBuilder(
          builder: (d, setS) => AlertDialog(
            title: const Text('Công khai trang pháp nhân?'),
            content: Column(mainAxisSize: MainAxisSize.min, children: [
              const Text('Mọi người (kể cả chưa đăng nhập) sẽ xem được thông tin pháp nhân và các giấy tờ '
                  'bạn đã chọn công khai.'),
              CheckboxListTile(
                value: checked,
                contentPadding: EdgeInsets.zero,
                controlAffinity: ListTileControlAffinity.leading,
                onChanged: (v) => setS(() => checked = v ?? false),
                title: const Text('Tôi xác nhận hồ sơ đầy đủ, đúng sự thật và đã kiểm tra'),
              ),
            ]),
            actions: [
              TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Huỷ')),
              FilledButton(onPressed: checked ? () => Navigator.pop(d, true) : null, child: const Text('Công khai')),
            ],
          ),
        ),
      );
      if (go != true) return;
    }
    if (mounted) await _do(() => _repo.publish(publish), publish ? 'Đã công khai' : 'Đã ẩn trang pháp nhân');
  }

  Future<void> _docDialog([Map<String, dynamic>? doc]) async {
    final ctrl = {
      for (final k in ['title', 'doc_number', 'issuer', 'issued_date', 'expiry_date', 'lookup_url', 'note'])
        k: TextEditingController(text: doc?[k]?.toString() ?? ''),
    };
    String type = doc?['doc_type'] ?? 'business_registration';
    PlatformFile? file;
    final go = await showDialog<bool>(
      context: context,
      builder: (d) => StatefulBuilder(
        builder: (d, setS) => AlertDialog(
          title: Text(doc == null ? 'Thêm giấy tờ' : 'Sửa giấy tờ'),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              DropdownButtonFormField<String>(
                value: type,
                isExpanded: true,
                decoration: const InputDecoration(labelText: 'Loại giấy tờ'),
                items: [
                  for (final e in legalDocTypeLabel.entries) DropdownMenuItem(value: e.key, child: Text(e.value)),
                ],
                onChanged: (v) => setS(() => type = v!),
              ),
              for (final e in {
                'title': 'Tên giấy tờ *',
                'doc_number': 'Số giấy tờ',
                'issuer': 'Cơ quan cấp',
                'issued_date': 'Ngày cấp (YYYY-MM-DD)',
                'expiry_date': 'Ngày hết hạn (YYYY-MM-DD, nếu có)',
                'lookup_url': 'Liên kết tra cứu công khai',
                'note': 'Ghi chú nội bộ',
              }.entries)
                Padding(
                  padding: const EdgeInsets.only(top: 10),
                  child: TextField(controller: ctrl[e.key], decoration: InputDecoration(labelText: e.value)),
                ),
              const SizedBox(height: 10),
              OutlinedButton.icon(
                icon: const Icon(Icons.attach_file),
                label: Text(file?.name ?? (doc?['file_path'] != null ? 'Thay tệp (PDF/ảnh)' : 'Chọn tệp (PDF/ảnh)')),
                onPressed: () async {
                  final r = await FilePicker.platform.pickFiles(
                    type: FileType.custom,
                    allowedExtensions: ['pdf', 'jpg', 'jpeg', 'png'],
                    withData: true,
                  );
                  if (r != null && r.files.isNotEmpty) setS(() => file = r.files.first);
                },
              ),
              const Padding(
                padding: EdgeInsets.only(top: 6),
                child: Text('Che thông tin cá nhân nhạy cảm (CCCD, địa chỉ nhà riêng…) trước khi tải lên '
                    'nếu định công khai.', style: TextStyle(fontSize: 12, color: Colors.black54)),
              ),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Huỷ')),
            FilledButton(onPressed: () => Navigator.pop(d, true), child: const Text('Lưu')),
          ],
        ),
      ),
    );
    if (go != true || !mounted) return;
    if (ctrl['title']!.text.trim().length < 2) {
      toast(context, 'Nhập tên giấy tờ', error: true);
      return;
    }
    await _do(() async {
      String? path;
      if (file?.bytes != null) {
        var ext = (file!.extension ?? 'pdf').toLowerCase();
        if (ext == 'jpg') ext = 'jpeg';
        path = await _repo.uploadFile(file!.bytes!, ext);
      }
      await _repo.upsertDoc({
        if (doc != null) 'id': doc['id'],
        'doc_type': type,
        for (final e in ctrl.entries) e.key: e.value.text.trim(),
        if (path != null) 'file_path': path,
      });
    }, 'Đã lưu giấy tờ (cần xác minh lại trước khi công khai)');
  }

  Future<void> _showAudit() async {
    final rows = await _repo.audit();
    if (!mounted) return;
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (_) => DraggableScrollableSheet(
        expand: false,
        initialChildSize: 0.7,
        builder: (_, sc) => ListView(controller: sc, children: [
          const Padding(
            padding: EdgeInsets.fromLTRB(16, 0, 16, 8),
            child: Text('Lịch sử thay đổi', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18)),
          ),
          if (rows.isEmpty) const EmptyHint('Chưa có thay đổi.'),
          for (final r in rows)
            ListTile(
              dense: true,
              leading: Icon(r['action'] == 'insert' ? Icons.add_circle_outline : Icons.edit_outlined),
              title: Text('${r['table_name'] == 'legal_entity' ? 'Pháp nhân' : 'Giấy tờ'}: ${r['summary'] ?? ''}'),
              subtitle: Text('${r['actor_name']} · ${dateTime(asDate(r['at']))}'),
            ),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final e = widget.entity;
    final status = (e['status'] ?? 'not_updated') as String;
    final published = e['is_published'] == true;
    return ListView(padding: const EdgeInsets.all(16), children: [
      Row(children: [
        Expanded(
          child: Text('Trạng thái: ${legalStatusLabel[status] ?? status}',
              style: const TextStyle(fontWeight: FontWeight.w800, color: Brand.navy)),
        ),
        Chip(
          label: Text(published ? 'Đang công khai' : 'Chưa công khai'),
          backgroundColor: published ? Colors.green.shade50 : Colors.grey.shade200,
        ),
      ]),
      const Text('Không nhập thông tin giả. Trạng thái "Đã xác minh" chỉ có khi bạn bấm Xác minh.',
          style: TextStyle(fontSize: 12, color: Colors.black54)),
      const SectionTitle('Thông tin pháp nhân'),
      for (final f in _fields.entries)
        Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: TextField(
            controller: _c[f.key],
            maxLines: f.key == 'address' || f.key == 'public_note' ? 2 : 1,
            decoration: InputDecoration(labelText: f.value),
          ),
        ),
      SwitchListTile(
        value: _showRep,
        onChanged: (v) => setState(() => _showRep = v),
        title: const Text('Công khai tên người đại diện'),
        contentPadding: EdgeInsets.zero,
      ),
      FilledButton(
        onPressed: () => _do(
          () => _repo.saveEntity({
            for (final x in _c.entries) x.key: x.value.text.trim(),
            'show_legal_rep': _showRep,
          }),
          'Đã lưu thông tin pháp nhân',
        ),
        child: const Text('Lưu thông tin'),
      ),
      const SizedBox(height: 12),
      Wrap(spacing: 8, runSpacing: 8, children: [
        OutlinedButton(
            onPressed: () => _do(() => _repo.setStatus('in_progress'), 'Đã chuyển: Đang hoàn thiện'),
            child: const Text('Đang hoàn thiện')),
        OutlinedButton(
            onPressed: () => _do(() => _repo.setStatus('updated'), 'Đã chuyển: Đã cập nhật'),
            child: const Text('Đã cập nhật đủ')),
        OutlinedButton(
            onPressed: () => _do(() => _repo.setStatus('needs_update'), 'Đã chuyển: Cần cập nhật'),
            child: const Text('Cần cập nhật')),
        FilledButton.tonal(onPressed: _verify, child: const Text('Xác minh hồ sơ')),
        published
            ? OutlinedButton(onPressed: () => _publish(false), child: const Text('Ẩn trang'))
            : FilledButton(
                style: FilledButton.styleFrom(backgroundColor: Brand.orange),
                onPressed: () => _publish(true),
                child: const Text('Công khai')),
        TextButton.icon(onPressed: _showAudit, icon: const Icon(Icons.history), label: const Text('Lịch sử thay đổi')),
      ]),
      SectionTitle('Giấy tờ pháp lý (${widget.docs.length})',
          trailing: TextButton.icon(
              onPressed: () => _docDialog(), icon: const Icon(Icons.add), label: const Text('Thêm'))),
      if (widget.docs.isEmpty) const EmptyHint('Chưa có giấy tờ nào.'),
      for (final doc in widget.docs) _docTile(doc),
    ]);
  }

  Widget _docTile(Map<String, dynamic> doc) {
    final active = doc['is_active'] == true;
    final pub = doc['is_public'] == true;
    final ver = doc['is_verified'] == true;
    final exp = doc['expiry_date'] != null && DateTime.parse(doc['expiry_date']).isBefore(DateTime.now());
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(doc['title'] ?? '', style: TextStyle(
              fontWeight: FontWeight.w700, decoration: active ? null : TextDecoration.lineThrough)),
          Text(legalDocTypeLabel[doc['doc_type']] ?? '', style: const TextStyle(fontSize: 12, color: Colors.black54)),
          const SizedBox(height: 4),
          Wrap(spacing: 6, children: [
            Chip(label: Text(ver ? 'Đã xác minh' : 'Chưa xác minh'), visualDensity: VisualDensity.compact),
            Chip(label: Text(pub ? 'Công khai' : 'Nội bộ'), visualDensity: VisualDensity.compact),
            if (!active) const Chip(label: Text('Đã gỡ'), visualDensity: VisualDensity.compact),
            if (exp) Chip(label: const Text('Hết hiệu lực'), backgroundColor: Colors.red.shade50,
                visualDensity: VisualDensity.compact),
            if (doc['file_path'] != null) const Chip(label: Text('Có tệp'), visualDensity: VisualDensity.compact),
          ]),
          Wrap(spacing: 4, children: [
            TextButton(onPressed: () => _docDialog(doc), child: const Text('Sửa')),
            if (!ver)
              TextButton(
                  onPressed: () => _do(() => _repo.setDocFlags(doc['id'], verify: true), 'Đã xác minh giấy tờ'),
                  child: const Text('Xác minh')),
            if (active)
              TextButton(
                  onPressed: () => _do(() => _repo.setDocFlags(doc['id'], isPublic: !pub),
                      pub ? 'Đã ẩn giấy tờ' : 'Đã công khai giấy tờ'),
                  child: Text(pub ? 'Ẩn' : 'Công khai')),
            TextButton(
                onPressed: () => _do(() => _repo.setDocFlags(doc['id'], isActive: !active),
                    active ? 'Đã gỡ giấy tờ' : 'Đã khôi phục'),
                child: Text(active ? 'Gỡ (hết hiệu lực)' : 'Khôi phục')),
          ]),
        ]),
      ),
    );
  }
}
