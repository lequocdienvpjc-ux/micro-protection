import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/error/failure.dart';
import '../../../core/widgets/common.dart';
import '../../auth/presentation/providers/auth_providers.dart';

final _memberQueryProvider = StateProvider.autoDispose<String>((_) => '');

final _membersProvider = FutureProvider.autoDispose<List<Map<String, dynamic>>>((ref) async {
  final q = ref.watch(_memberQueryProvider);
  try {
    final r = await ref.read(supabaseClientProvider).rpc('admin_search_members', params: {'p_query': q, 'p_limit': 100});
    return (r as List).cast<Map<String, dynamic>>();
  } catch (e) {
    throw Failure.from(e);
  }
});

final _occStatsProvider = FutureProvider.autoDispose<List<Map<String, dynamic>>>((ref) async {
  try {
    final r = await ref.read(supabaseClientProvider).rpc('admin_occupation_stats');
    return (r as List).cast<Map<String, dynamic>>();
  } catch (e) {
    throw Failure.from(e);
  }
});

const _kycLabel = {'none': 'Chưa KYC', 'pending': 'Chờ duyệt', 'verified': 'Đã xác minh', 'rejected': 'Bị từ chối'};

/// Tìm & phân loại thành viên theo tên / SĐT / email / ngành nghề (không cần gõ dấu).
class AdminMembersTab extends ConsumerStatefulWidget {
  const AdminMembersTab({super.key});
  @override
  ConsumerState<AdminMembersTab> createState() => _AdminMembersTabState();
}

class _AdminMembersTabState extends ConsumerState<AdminMembersTab> {
  final _q = TextEditingController();

  @override
  void dispose() {
    _q.dispose();
    super.dispose();
  }

  void _search(String v) => ref.read(_memberQueryProvider.notifier).state = v.trim();

  @override
  Widget build(BuildContext context) {
    final members = ref.watch(_membersProvider);
    final stats = ref.watch(_occStatsProvider);
    return RefreshIndicator(
      onRefresh: () async {
        ref.invalidate(_membersProvider);
        ref.invalidate(_occStatsProvider);
      },
      child: ListView(padding: const EdgeInsets.all(16), children: [
        TextField(
          controller: _q,
          textInputAction: TextInputAction.search,
          decoration: InputDecoration(
            labelText: 'Tìm theo tên, SĐT, email hoặc ngành nghề',
            hintText: 'VD: ep nhua, tai xe, ve so…',
            prefixIcon: const Icon(Icons.search),
            suffixIcon: IconButton(
              icon: const Icon(Icons.clear),
              onPressed: () {
                _q.clear();
                _search('');
              },
            ),
          ),
          onSubmitted: _search,
        ),
        const SectionTitle('Thống kê ngành nghề (bấm để lọc)'),
        AsyncView<List<Map<String, dynamic>>>(
          value: stats,
          data: (rows) => rows.isEmpty
              ? const EmptyHint('Chưa có dữ liệu ngành nghề.')
              : Wrap(spacing: 6, runSpacing: 6, children: [
                  for (final r in rows)
                    ActionChip(
                      label: Text('${r['occupation']} (${r['members']})'),
                      onPressed: () {
                        _q.text = r['occupation'] ?? '';
                        _search(_q.text);
                      },
                    ),
                ]),
        ),
        const SectionTitle('Thành viên'),
        AsyncView<List<Map<String, dynamic>>>(
          value: members,
          onRetry: () => ref.invalidate(_membersProvider),
          data: (rows) => rows.isEmpty
              ? const EmptyHint('Không tìm thấy thành viên phù hợp.')
              : Column(children: [
                  for (final m in rows)
                    Card(
                      margin: const EdgeInsets.only(bottom: 8),
                      child: Padding(
                        padding: const EdgeInsets.all(12),
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Row(children: [
                            Expanded(
                              child: Text(m['full_name'] ?? '(chưa có tên)',
                                  style: const TextStyle(fontWeight: FontWeight.w700)),
                            ),
                            Text(_kycLabel[m['kyc_status']] ?? '', style: const TextStyle(fontSize: 12)),
                          ]),
                          Text(m['contact'] ?? '', style: const TextStyle(color: Colors.black54)),
                          if ((m['group_names'] ?? '').toString().isNotEmpty) Text('Nhóm: ${m['group_names']}'),
                          const SizedBox(height: 6),
                          Wrap(spacing: 4, runSpacing: 4, children: [
                            for (final o in ((m['occupations'] as List?) ?? const []))
                              Chip(label: Text(o.toString()), visualDensity: VisualDensity.compact),
                          ]),
                        ]),
                      ),
                    ),
                ]),
        ),
      ]),
    );
  }
}
