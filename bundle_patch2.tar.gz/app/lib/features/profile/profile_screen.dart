import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'package:go_router/go_router.dart';

import '../../core/router/app_router.dart';
import '../../core/widgets/common.dart';
import '../../core/widgets/occupation_input.dart';
import '../feedback/feedback_screen.dart';
import '../auth/presentation/providers/auth_providers.dart';
import '../group/data/group_repository.dart';
import '../group/presentation/join_group_screen.dart';

/// Tài khoản: thông tin, tài khoản nhận tiền hỗ trợ, gia nhập nhóm khác, đăng xuất.
class ProfileScreen extends ConsumerStatefulWidget {
  const ProfileScreen({super.key});
  @override
  ConsumerState<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends ConsumerState<ProfileScreen> {
  final _form = GlobalKey<FormState>();
  final _bank = TextEditingController();
  final _no = TextEditingController();
  final _name = TextEditingController();
  bool _loaded = false;
  List<String>? _occupations;
  bool _savingOcc = false;

  @override
  void dispose() {
    _bank.dispose();
    _no.dispose();
    _name.dispose();
    super.dispose();
  }

  Future<void> _loadPayout() async {
    if (_loaded) return;
    _loaded = true;
    try {
      final id = ref.read(authRepositoryProvider).currentUserId;
      final row = await ref
          .read(supabaseClientProvider)
          .from('profiles')
          .select('payout_bank, payout_account_no, payout_account_name')
          .eq('id', id!)
          .single();
      _bank.text = row['payout_bank'] as String? ?? '';
      _no.text = row['payout_account_no'] as String? ?? '';
      _name.text = row['payout_account_name'] as String? ?? '';
      if (mounted) setState(() {});
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    _loadPayout();
    final u = ref.watch(currentUserProvider).valueOrNull;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Card(
          child: ListTile(
            leading: const CircleAvatar(child: Icon(Icons.person)),
            title: Text(u?.displayName ?? ''),
            subtitle: Text([
              u?.phone ?? u?.email ?? '',
              if (u?.nationalIdLast4 != null) 'CCCD ***${u!.nationalIdLast4}',
              if (u?.isAdmin == true) 'Quản trị viên',
            ].join(' · ')),
          ),
        ),
        const SectionTitle('Ngành nghề của tôi'),
        if (u != null)
          OccupationInput(
            key: ValueKey(u.occupations.join('|')),
            initial: u.occupations,
            onChanged: (v) => _occupations = v,
          ),
        const SizedBox(height: 8),
        OutlinedButton(
          onPressed: _savingOcc
              ? null
              : () async {
                  final list = _occupations ?? u?.occupations ?? const <String>[];
                  if (list.isEmpty) {
                    toast(context, 'Cần ít nhất một ngành nghề', error: true);
                    return;
                  }
                  setState(() => _savingOcc = true);
                  final ok = await runAction(
                    context,
                    () => ref.read(authRepositoryProvider).updateOccupations(list),
                    success: 'Đã lưu ngành nghề',
                  );
                  if (mounted) setState(() => _savingOcc = false);
                  if (ok) ref.invalidate(currentUserProvider);
                },
          child: Text(_savingOcc ? 'Đang lưu…' : 'Lưu ngành nghề'),
        ),
        const SectionTitle('Tài khoản nhận tiền hỗ trợ'),
        Form(
          key: _form,
          child: Column(children: [
            TextFormField(
              controller: _bank,
              decoration: const InputDecoration(labelText: 'Ngân hàng (vd: Vietcombank, MB, Techcombank)'),
              validator: (v) => (v ?? '').trim().isEmpty ? 'Nhập tên ngân hàng' : null,
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _no,
              keyboardType: TextInputType.number,
              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
              decoration: const InputDecoration(labelText: 'Số tài khoản'),
              validator: (v) => (v ?? '').length < 6 ? 'Số tài khoản không hợp lệ' : null,
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _name,
              textCapitalization: TextCapitalization.characters,
              decoration: const InputDecoration(labelText: 'Tên chủ tài khoản (không dấu)'),
              validator: (v) => (v ?? '').trim().length < 2 ? 'Nhập tên chủ tài khoản' : null,
            ),
            const SizedBox(height: 12),
            FilledButton(
              onPressed: () async {
                if (!_form.currentState!.validate()) return;
                await runAction(
                  context,
                  () => ref.read(groupRepositoryProvider).updatePayoutAccount(_bank.text, _no.text, _name.text),
                  success: 'Đã lưu tài khoản nhận tiền',
                );
              },
              child: const Text('Lưu tài khoản'),
            ),
          ]),
        ),
        const SectionTitle('Tìm hiểu & minh bạch'),
        Card(
          child: Column(children: [
            ListTile(
              leading: const Icon(Icons.favorite_outline),
              title: const Text('Giới thiệu Tương trợ'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => context.push(Routes.welcome),
            ),
            ListTile(
              leading: const Icon(Icons.route_outlined),
              title: const Text('Cách Tương trợ hoạt động'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => context.push(Routes.about),
            ),
            ListTile(
              leading: const Icon(Icons.gavel_outlined),
              title: const Text('Quy chế quỹ'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => context.push(Routes.rules),
            ),
            ListTile(
              leading: const Icon(Icons.verified_outlined),
              title: const Text('Pháp nhân và minh bạch pháp lý'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => context.push(Routes.legal),
            ),
            ListTile(
              leading: const Icon(Icons.support_agent_outlined),
              title: const Text('Phản ánh / khiếu nại'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.push(
                  context, MaterialPageRoute(builder: (_) => const FeedbackScreen())),
            ),
          ]),
        ),
        const SizedBox(height: 24),
        OutlinedButton.icon(
          icon: const Icon(Icons.group_add_outlined),
          label: const Text('Gia nhập thêm nhóm khác'),
          onPressed: () => Navigator.push(
              context, MaterialPageRoute(builder: (_) => const JoinGroupScreen())),
        ),
        const SizedBox(height: 12),
        TextButton.icon(
          icon: const Icon(Icons.logout),
          label: const Text('Đăng xuất'),
          onPressed: () async {
            if (await confirmDialog(context, 'Đăng xuất?', 'Bạn sẽ cần đăng nhập lại.')) {
              await ref.read(authControllerProvider.notifier).signOut();
            }
          },
        ),
        const SizedBox(height: 24),
        const Text('Tương trợ v0.2 · Kết nối sức mạnh, sẻ chia khó khăn',
            textAlign: TextAlign.center, style: TextStyle(color: Colors.black38, fontSize: 12)),
      ],
    );
  }
}
