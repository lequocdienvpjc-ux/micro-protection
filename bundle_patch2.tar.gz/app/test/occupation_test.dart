import 'package:flutter_test/flutter_test.dart';
import 'package:micro_protection/core/data/occupation_suggestions.dart';

void main() {
  test('bỏ dấu tiếng Việt để tìm gợi ý', () {
    expect(vnNorm('Tài Xế  Xe Ôm'), 'tai xe xe om');
    expect(vnNorm('Đồng nát'), 'dong nat');
  });

  test('danh sách gợi ý phong phú, không trùng', () {
    expect(occupationGroups.length, greaterThanOrEqualTo(25));
    expect(allOccupationSuggestions.length, greaterThan(250));
    expect(allOccupationSuggestions.toSet().length, allOccupationSuggestions.length);
  });
}
